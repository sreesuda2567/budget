(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common/http'), require('@angular/platform-browser'), require('@ionic/angular'), require('rxjs/operators'), require('pdf-lib'), require('@pdf-lib/fontkit'), require('pdfjs-dist'), require('@angular/common'), require('@angular/forms')) :
    typeof define === 'function' && define.amd ? define('pdf-annotator', ['exports', '@angular/core', '@angular/common/http', '@angular/platform-browser', '@ionic/angular', 'rxjs/operators', 'pdf-lib', '@pdf-lib/fontkit', 'pdfjs-dist', '@angular/common', '@angular/forms'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["pdf-annotator"] = {}, global.ng.core, global.ng.common.http, global.ng.platformBrowser, global.angular, global.rxjs.operators, global.pdfLib, global.fontkitModule, global.pdfjsLib, global.ng.common, global.ng.forms));
})(this, (function (exports, i0, i1, platformBrowser, angular, operators, pdfLib, fontkitModule, pdfjsLib, common, forms) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
    var fontkitModule__namespace = /*#__PURE__*/_interopNamespace(fontkitModule);
    var pdfjsLib__namespace = /*#__PURE__*/_interopNamespace(pdfjsLib);

    var PDF_ANNOTATOR_CONFIG = new i0.InjectionToken('PDF_ANNOTATOR_CONFIG');

    var PdfManagerService = /** @class */ (function () {
        function PdfManagerService(http, config) {
            var _a;
            this.http = http;
            this.base = (_a = config === null || config === void 0 ? void 0 : config.pdfApiUrl) !== null && _a !== void 0 ? _a : 'http://localhost:3500/api';
        }
        PdfManagerService.prototype.listDocuments = function (userId, search) {
            var params = new i1.HttpParams().set('userId', userId);
            if (search)
                params = params.set('search', search);
            return this.http.get(this.base + "/pdf/list", { params: params });
        };
        PdfManagerService.prototype.uploadDocument = function (file, userId, userName) {
            var form = new FormData();
            form.append('pdf', file);
            form.append('userId', userId);
            if (userName)
                form.append('userName', userName);
            return this.http.post(this.base + "/pdf/upload", form);
        };
        PdfManagerService.prototype.getPdfUrl = function (docId) {
            return this.base + "/pdf/" + docId;
        };
        PdfManagerService.prototype.saveAnnotatedPdf = function (docId, pdfBlob, userId, fileName, annotationSummary, userName) {
            var form = new FormData();
            form.append('pdf', pdfBlob, fileName);
            form.append('userId', userId);
            if (userName)
                form.append('userName', userName);
            if (annotationSummary)
                form.append('annotationSummary', JSON.stringify(annotationSummary));
            return this.http.post(this.base + "/pdf/" + docId + "/save", form);
        };
        PdfManagerService.prototype.getDocumentInfo = function (docId) {
            return this.http.get(this.base + "/pdf/" + docId + "/info");
        };
        PdfManagerService.prototype.deleteDocument = function (docId) {
            return this.http.delete(this.base + "/pdf/" + docId);
        };
        PdfManagerService.prototype.logAction = function (payload) {
            return this.http.post(this.base + "/history", payload);
        };
        PdfManagerService.prototype.getHistory = function (docId, limit, offset) {
            if (limit === void 0) { limit = 100; }
            if (offset === void 0) { offset = 0; }
            var params = new i1.HttpParams().set('limit', limit).set('offset', offset);
            return this.http.get(this.base + "/history/" + docId, { params: params });
        };
        PdfManagerService.prototype.getHistorySummary = function (docId) {
            return this.http.get(this.base + "/history/" + docId + "/summary");
        };
        PdfManagerService.prototype.getSignatures = function (userId) {
            return this.http.get(this.base + "/signatures/" + userId);
        };
        PdfManagerService.prototype.saveSignature = function (userId, signatureData, signatureName, isDefault) {
            return this.http.post(this.base + "/signatures", {
                userId: userId, signatureData: signatureData, signatureName: signatureName, isDefault: isDefault,
            });
        };
        PdfManagerService.prototype.setDefaultSignature = function (sigId) {
            return this.http.put(this.base + "/signatures/" + sigId + "/default", {});
        };
        PdfManagerService.prototype.deleteSignature = function (sigId) {
            return this.http.delete(this.base + "/signatures/" + sigId);
        };
        return PdfManagerService;
    }());
    PdfManagerService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function PdfManagerService_Factory() { return new PdfManagerService(i0__namespace.ɵɵinject(i1__namespace.HttpClient), i0__namespace.ɵɵinject(PDF_ANNOTATOR_CONFIG, 8)); }, token: PdfManagerService, providedIn: "root" });
    PdfManagerService.decorators = [
        { type: i0.Injectable, args: [{ providedIn: 'root' },] }
    ];
    PdfManagerService.ctorParameters = function () { return [
        { type: i1.HttpClient },
        { type: undefined, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [PDF_ANNOTATOR_CONFIG,] }] }
    ]; };

    /******************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise, SuppressedError, Symbol, Iterator */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
        function accept(f) { if (f !== void 0 && typeof f !== "function")
            throw new TypeError("Function expected"); return f; }
        var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
        var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
        var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
        var _, done = false;
        for (var i = decorators.length - 1; i >= 0; i--) {
            var context = {};
            for (var p in contextIn)
                context[p] = p === "access" ? {} : contextIn[p];
            for (var p in contextIn.access)
                context.access[p] = contextIn.access[p];
            context.addInitializer = function (f) { if (done)
                throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
            var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
            if (kind === "accessor") {
                if (result === void 0)
                    continue;
                if (result === null || typeof result !== "object")
                    throw new TypeError("Object expected");
                if (_ = accept(result.get))
                    descriptor.get = _;
                if (_ = accept(result.set))
                    descriptor.set = _;
                if (_ = accept(result.init))
                    initializers.unshift(_);
            }
            else if (_ = accept(result)) {
                if (kind === "field")
                    initializers.unshift(_);
                else
                    descriptor[key] = _;
            }
        }
        if (target)
            Object.defineProperty(target, contextIn.name, descriptor);
        done = true;
    }
    ;
    function __runInitializers(thisArg, initializers, value) {
        var useValue = arguments.length > 2;
        for (var i = 0; i < initializers.length; i++) {
            value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
        }
        return useValue ? value : void 0;
    }
    ;
    function __propKey(x) {
        return typeof x === "symbol" ? x : "".concat(x);
    }
    ;
    function __setFunctionName(f, name, prefix) {
        if (typeof name === "symbol")
            name = name.description ? "[".concat(name.description, "]") : "";
        return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
    }
    ;
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
        return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (g && (g = 0, op[0] && (_ = 0)), _)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
            desc = { enumerable: true, get: function () { return m[k]; } };
        }
        Object.defineProperty(o, k2, desc);
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2)
            for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                    if (!ar)
                        ar = Array.prototype.slice.call(from, 0, i);
                    ar[i] = from[i];
                }
            }
        return to.concat(ar || Array.prototype.slice.call(from));
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
        function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
        function verb(n, f) { if (g[n]) {
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); };
            if (f)
                i[n] = f(i[n]);
        } }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    var ownKeys = function (o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o)
                if (Object.prototype.hasOwnProperty.call(o, k))
                    ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k = ownKeys(mod), i = 0; i < k.length; i++)
                if (k[i] !== "default")
                    __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }
    function __classPrivateFieldIn(state, receiver) {
        if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function"))
            throw new TypeError("Cannot use 'in' operator on non-object");
        return typeof state === "function" ? receiver === state : state.has(receiver);
    }
    function __addDisposableResource(env, value, async) {
        if (value !== null && value !== void 0) {
            if (typeof value !== "object" && typeof value !== "function")
                throw new TypeError("Object expected.");
            var dispose, inner;
            if (async) {
                if (!Symbol.asyncDispose)
                    throw new TypeError("Symbol.asyncDispose is not defined.");
                dispose = value[Symbol.asyncDispose];
            }
            if (dispose === void 0) {
                if (!Symbol.dispose)
                    throw new TypeError("Symbol.dispose is not defined.");
                dispose = value[Symbol.dispose];
                if (async)
                    inner = dispose;
            }
            if (typeof dispose !== "function")
                throw new TypeError("Object not disposable.");
            if (inner)
                dispose = function () { try {
                    inner.call(this);
                }
                catch (e) {
                    return Promise.reject(e);
                } };
            env.stack.push({ value: value, dispose: dispose, async: async });
        }
        else if (async) {
            env.stack.push({ async: true });
        }
        return value;
    }
    var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
        var e = new Error(message);
        return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
    };
    function __disposeResources(env) {
        function fail(e) {
            env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        var r, s = 0;
        function next() {
            while (r = env.stack.pop()) {
                try {
                    if (!r.async && s === 1)
                        return s = 0, env.stack.push(r), Promise.resolve().then(next);
                    if (r.dispose) {
                        var result = r.dispose.call(r.value);
                        if (r.async)
                            return s |= 2, Promise.resolve(result).then(next, function (e) { fail(e); return next(); });
                    }
                    else
                        s |= 1;
                }
                catch (e) {
                    fail(e);
                }
            }
            if (s === 1)
                return env.hasError ? Promise.reject(env.error) : Promise.resolve();
            if (env.hasError)
                throw env.error;
        }
        return next();
    }
    function __rewriteRelativeImportExtension(path, preserveJsx) {
        if (typeof path === "string" && /^\.\.?\//.test(path)) {
            return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
                return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
            });
        }
        return path;
    }
    var tslib_es6 = {
        __extends: __extends,
        __assign: __assign,
        __rest: __rest,
        __decorate: __decorate,
        __param: __param,
        __esDecorate: __esDecorate,
        __runInitializers: __runInitializers,
        __propKey: __propKey,
        __setFunctionName: __setFunctionName,
        __metadata: __metadata,
        __awaiter: __awaiter,
        __generator: __generator,
        __createBinding: __createBinding,
        __exportStar: __exportStar,
        __values: __values,
        __read: __read,
        __spread: __spread,
        __spreadArrays: __spreadArrays,
        __spreadArray: __spreadArray,
        __await: __await,
        __asyncGenerator: __asyncGenerator,
        __asyncDelegator: __asyncDelegator,
        __asyncValues: __asyncValues,
        __makeTemplateObject: __makeTemplateObject,
        __importStar: __importStar,
        __importDefault: __importDefault,
        __classPrivateFieldGet: __classPrivateFieldGet,
        __classPrivateFieldSet: __classPrivateFieldSet,
        __classPrivateFieldIn: __classPrivateFieldIn,
        __addDisposableResource: __addDisposableResource,
        __disposeResources: __disposeResources,
        __rewriteRelativeImportExtension: __rewriteRelativeImportExtension,
    };

    var PdfAnnotatorModalComponent = /** @class */ (function () {
        function PdfAnnotatorModalComponent(modalCtrl, http, zone, toastCtrl, alertCtrl, cdr, sanitizer, pdfSvc, config) {
            var _a, _b, _c, _d, _e;
            this.modalCtrl = modalCtrl;
            this.http = http;
            this.zone = zone;
            this.toastCtrl = toastCtrl;
            this.alertCtrl = alertCtrl;
            this.cdr = cdr;
            this.sanitizer = sanitizer;
            this.pdfSvc = pdfSvc;
            this.canManageGuide = false;
            // Context Menu state
            this.contextMenu = {
                show: false,
                x: 0,
                y: 0,
                targetId: '',
                targetType: ''
            };
            // Tool modes
            this.toolMode = 'none';
            this.shapeType = 'rect';
            this.showShapeMenu = false;
            this.showShapeDropdown = false;
            this.shapeNoStroke = false;
            // Shape-specific color settings (separate from brush)
            this.shapeStrokeColor = '#000000';
            this.shapeFillColor = '#ffffff';
            this.shapeFillEnabled = false;
            this.shapeStrokeSize = 2;
            // Mac Preview-style color swatches
            this.shapeColorSwatches = [
                '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#ffffff',
                '#ff0000', '#ff4500', '#ff9900', '#ffcc00', '#00b050', '#00b0f0', '#0070c0', '#7030a0',
                '#ff00ff', '#ff69b4', '#4169e1', '#20b2aa', '#228b22', '#8b4513', '#a0522d', '#dc143c'
            ];
            this.shapeFillSwatches = [
                '#ffffff', '#f2f2f2', '#e6e6e6', '#d9d9d9', '#cccccc', '#b7b7b7', '#999999', '#000000',
                '#ffcccc', '#ffe5cc', '#fffacc', '#ccffcc', '#ccf5ff', '#cce0ff', '#e5ccff', '#ffccf2',
                '#ff9999', '#ffcc99', '#ffff99', '#99ff99', '#99f2ff', '#99bbff', '#cc99ff', '#ff99ee'
            ];
            this.brushColor = '#0000FF';
            this.brushSize = 3;
            this.highlightColor = '#ffff00';
            this.highlightSize = 20;
            this.eraserSize = 20;
            this.pageNo = 1;
            this.pageCount = 0;
            this.pagesPerChunk = 10;
            this.loadedUntilPage = 0;
            this.isLoadingChunk = false;
            this.zoom = 1; // 0.5 - 3
            this.viewMode = 'single';
            this.pages = []; // Array [1, 2, ..., pageCount]
            this.isLoading = false;
            this.loadingMessage = '';
            this.saveProgress = 0;
            this.renderingPages = new Set();
            this.renderedPages = new Set();
            this.textBoxes = [];
            this.imageStamps = [];
            this.shapeStamps = [];
            this.signatureStamps = [];
            this.dateStamps = [];
            this.pdfFormFields = [];
            this.formFieldCounter = 0;
            this.activeFormFieldId = null;
            // Modal & Preview States
            this.showSignaturePad = false;
            this.showSignaturePicker = false;
            this.showPreviewOverlay = false;
            this.previewUrl = null;
            this.previewPages = []; // Array of base64 image URLs for preview
            this.previewIsFiltered = false; // true when showing annotated-pages-only preview
            this.previewTotalPages = 0;
            this.isLoadingAllPreview = false;
            this.pageThumbnails = []; // Array of base64 thumbnail images
            this.showThumbnails = true; // Toggle for thumbnails sidebar
            this.lastSavedBlob = null;
            this.lastSavedFileName = '';
            this.signatureCtx = null;
            this.isDrawingSignature = false;
            this.signaturePoints = [];
            this.signatureStrokes = [];
            this.bufferCanvas = null;
            // Signature pen settings
            this.signaturePenColor = '#000000';
            this.signaturePenSize = 2.5;
            // Stamp Picker
            this.showStampPickerModal = false;
            this.showStampGenerator = false;
            this.savedStamps = [];
            this.stampGenType = 'receive';
            this.stampGenText1 = '';
            this.stampGenText2 = '';
            this.stampGenText3 = '';
            this.stampGenDocNo = '';
            this.stampGenDate = '';
            this.stampGenTime = '';
            this.stampGenShowDocNo = true;
            this.stampGenShowDate = true;
            this.stampGenShowTime = true;
            this.stampGenNoBorder = false;
            this.stampGenColor = '#ef4444';
            this.stampEditingId = null;
            this.stampEditingName = '';
            this.pendingStamp = null;
            this.stampGhostX = 0;
            this.stampGhostY = 0;
            this.stampGhostPage = 0;
            // Signature mode (draw vs type)
            this.sigMode = 'draw';
            this.typedText = '';
            this.typedFontIndex = 0;
            this.typedFontOptions = [
                { family: 'THSarabunNew, sans-serif', weight: '400', style: 'normal', label: 'ธรรมดา' },
                { family: 'THSarabunNew, sans-serif', weight: '700', style: 'normal', label: 'ตัวหนา' },
                { family: 'THSarabunNew, sans-serif', weight: '400', style: 'italic', label: 'เอียง' },
                { family: 'THSarabunNew, sans-serif', weight: '700', style: 'italic', label: 'หนา+เอียง' },
                { family: 'Georgia, serif', weight: '400', style: 'italic', label: 'Serif' },
            ];
            // Quick Mark Stamp settings
            this.markType = 'check';
            this.formFieldType = 'checkbox';
            this.markColor = '#000000';
            this.markSize = 32; // px at 100% zoom (will be scaled)
            this.showMarkOptions = false;
            // Date Stamp Settings
            this.dateColor = '#000000';
            this.dateFontSize = 16;
            this.showDateOptions = false;
            // Saved Signatures (from database)
            this.savedSignatures = [];
            this.isLoadingSignatures = false;
            this.userId = '';
            this.userName = '';
            this.documentId = null;
            this.detailId = '';
            this.edocId = '';
            this.isCancelMode = false;
            // Digital ID settings
            this.showDigitalId = true;
            // Thumbnail sidebar state
            this.thumbInsertIndex = -1; // -1 = closed; 0 = before page 1; i = after page i
            this.thumbDropdownTargetIndex = -1;
            // ------------------------------------
            // User Guide Modal State
            // ------------------------------------
            this.showUserGuidePanel = false;
            this.isLoadingGuide = false;
            this.isEditingGuide = false;
            this.userGuideContent = '';
            this.tempGuideContent = '';
            this.thumbDropdownTop = 0; // Fixed-position Y coord for insert dropdown
            this.thumbInsertAtIndex = -1; // the slot index where file upload was triggered
            // ── History Panel ────────────────────────────────────────────────────────
            this.showHistoryPanel = false;
            this.historyEntries = [];
            this.isLoadingHistory = false;
            // ── Page Flip (90° increments) ───────────────────────────────────────────
            // Visual rotation is applied as a CSS transform on each .page-container; the
            // angle is baked into the PDF (via setRotation) inside saveDocument().
            this.pageFlips = {}; // 0, 90, 180, 270
            this.showFlipPanel = false;
            this.flipScope = 'current';
            // ============== Deskew (Page Straightening) ==============
            this.pageRotations = {}; // fine-angle deskew, degrees
            this.showDeskewPanel = false;
            // ============== Split PDF (export selected pages) ==============
            this.showSplitPanel = false;
            this.splitPageRange = '';
            // ============== Watermark ==============
            this.showWatermarkPanel = false;
            this.watermark = {
                enabled: false,
                type: 'text',
                text: 'สำเนา',
                fontFamily: 'TH Sarabun New',
                fontSize: 40,
                color: '#999999',
                opacity: 30,
                rotation: 45,
                mode: 'tiled',
                spacingX: 200,
                spacingY: 150,
                scope: 'all',
                imageDataUrl: '' // for image watermark
            };
            // ============== Page Numbers ==============
            this.showPageNumberPanel = false;
            this.pageNumber = {
                enabled: false,
                format: 'arabic',
                position: 'bottom-right',
                mirror: false,
                showPrefix: true,
                prefixText: 'หน้า ',
                suffixText: '',
                fontFamily: 'TH Sarabun New',
                fontSize: 14,
                color: '#000000',
                startFrom: 1,
                startAtPage: 1,
                skipFirstPage: false,
                pageScope: 'all',
                customPages: '',
                // ── Header / Footer ──────────────────────
                headerText: '',
                headerPosition: 'top-center',
                footerText: '',
                footerPosition: 'bottom-center',
            };
            // Insert blank page
            this.showInsertMenu = false;
            this.showThumbInsertMenu = false;
            this.insertOrientation = 'portrait';
            // Page-operation undo stack (insert / delete page)
            this.pageHistoryStack = [];
            this.strokes = {};
            this.shapes = {};
            this.redoStack = {};
            this.activeStroke = null;
            this.activeShape = null;
            this.activeCanvasRect = null;
            this.activePointerId = null;
            this.activeObjectId = null;
            this.activeObjectType = null;
            this.activePointerType = '';
            this.renderRequested = false;
            this.isRenderingAll = false;
            this.renderDebounceTimer = null;
            this.isDragging = false;
            this.dragTextBoxId = null;
            this.dragOffsetX = 0;
            this.dragOffsetY = 0;
            // Resize state
            this.isResizing = false;
            this.resizeTextBoxId = null;
            // Image drag state
            this.isDraggingImage = false;
            this.dragImageId = null;
            this.isResizingImage = false;
            this.resizeImageId = null;
            // ShapeStamp drag/resize state
            this.isDraggingShape = false;
            this.dragShapeId = null;
            this.isResizingShape = false;
            this.resizeShapeId = null;
            this.resizeObserver = null;
            this.isScrollNavigating = false;
            this.basePdfBytes = null;
            /** PDF page aspect ratios (width/height) per page number, populated at load time */
            this.pdfPageAspects = new Map();
            /** PDF page rotations (0/90/180/270) per page number, populated at load time from pdf-lib */
            this.pdfPageRotations = new Map();
            this.revNo = 1;
            this.pdfDocProxy = null;
            this.currentViewport = null;
            // default text style
            this.textColor = '#0000FF';
            this.textFontSize = 16;
            this.tbDefaultFontFamily = 'THSarabunNew';
            this.tbDefaultBold = true;
            this.tbDefaultItalic = false;
            this.tbDefaultAlign = 'left';
            this.tbDefaultLetterSpacing = 0;
            this.tbDefaultLineHeight = 1.4;
            this.pendingSignatureDataUrl = null;
            this.activeTextBoxId = null;
            this.lsDropOpenId = null;
            this.lsPresets = [-3, -2, -1, 0, 1, 2, 3, 5, 8, 10];
            // ── Outputs (for inline / non-modal usage) ───────────────────────────────
            // These fire alongside the legacy ModalController.dismiss(), so the component
            // works both as an Ionic modal and embedded directly in a host template.
            this.closed = new i0.EventEmitter();
            this.saved = new i0.EventEmitter();
            this.loadError = new i0.EventEmitter();
            this.SETTINGS_KEY = 'esign_pdf_annotator_settings';
            // ── Drag-to-reorder state ──────────────────────────────────────────
            this.thumbDragFromIndex = null;
            this.thumbDragOverIndex = null;
            /* ================= Zoom & Resize ================= */
            this.lastParentWidth = 0;
            this.lastFitPageNo = -1;
            this.signaturesApiUrl = (_a = config === null || config === void 0 ? void 0 : config.signaturesApiUrl) !== null && _a !== void 0 ? _a : 'http://localhost:3500/api/signatures';
            this.stampsApiUrl = (_b = config === null || config === void 0 ? void 0 : config.stampsApiUrl) !== null && _b !== void 0 ? _b : 'http://localhost:3500/api/stamps';
            this.pdfWorkerSrc = (_c = config === null || config === void 0 ? void 0 : config.pdfWorkerSrc) !== null && _c !== void 0 ? _c : '/assets/pdf.worker.min.mjs';
            this.fontUrl = (_d = config === null || config === void 0 ? void 0 : config.fontUrl) !== null && _d !== void 0 ? _d : '/assets/fonts/THSarabunNew.ttf';
            this.fontBoldUrl = (_e = config === null || config === void 0 ? void 0 : config.fontBoldUrl) !== null && _e !== void 0 ? _e : '/assets/fonts/THSarabunNew Bold.ttf';
        }
        PdfAnnotatorModalComponent.prototype.toggleDateOptions = function () {
            this.showDateOptions = !this.showDateOptions;
        };
        PdfAnnotatorModalComponent.prototype.addDateStampAndShowOptions = function () {
            this.addDateStamp();
            this.showDateOptions = true;
        };
        PdfAnnotatorModalComponent.prototype.setDateColor = function (color) {
            this.dateColor = color;
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.changeDateFontSize = function (delta) {
            var newSize = this.dateFontSize + delta;
            if (newSize >= 8 && newSize <= 100) {
                this.dateFontSize = newSize;
                this.saveSettings();
            }
        };
        /** Log an action to the ruts-pdf history API (fire-and-forget) */
        PdfAnnotatorModalComponent.prototype.logHistory = function (actionType, detail, pageNumber) {
            if (detail === void 0) { detail = {}; }
            if (!this.documentId || !this.userId)
                return;
            this.pdfSvc.logAction({
                documentId: this.documentId,
                userId: this.userId,
                actionType: actionType,
                actionDetail: detail,
                pageNumber: pageNumber !== null && pageNumber !== void 0 ? pageNumber : this.pageNo,
                userName: this.userName,
            }).subscribe();
            // Also add to local panel immediately
            this.historyEntries.unshift({
                id: Date.now(),
                document_id: this.documentId,
                user_id: this.userId,
                action_type: actionType,
                action_detail: detail,
                page_number: pageNumber !== null && pageNumber !== void 0 ? pageNumber : this.pageNo,
                user_name: this.userName,
                user_position: '',
                ip_address: '',
                created_at: new Date().toISOString(),
            });
        };
        PdfAnnotatorModalComponent.prototype.toggleHistoryPanel = function () {
            this.showHistoryPanel = !this.showHistoryPanel;
            if (this.showHistoryPanel && this.documentId && this.historyEntries.length === 0) {
                this.loadHistoryFromApi();
            }
        };
        /** Close all floating tool panels so only one is visible at a time */
        PdfAnnotatorModalComponent.prototype.closeAllPanels = function (except) {
            if (except !== 'flip')
                this.showFlipPanel = false;
            if (except !== 'watermark')
                this.showWatermarkPanel = false;
            if (except !== 'pageNumber')
                this.showPageNumberPanel = false;
            if (except !== 'deskew')
                this.showDeskewPanel = false;
            if (except !== 'split')
                this.showSplitPanel = false;
        };
        PdfAnnotatorModalComponent.prototype.toggleFlipPanel = function () {
            this.showFlipPanel = !this.showFlipPanel;
            if (this.showFlipPanel) {
                this.closeAllPanels('flip');
                this.showFlipPanel = true;
                this.toolMode = 'none';
                this.updateCursor();
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.closeFlipPanel = function () {
            this.showFlipPanel = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.getPageFlip = function (p) {
            return this.pageFlips[p] || 0;
        };
        /** Rotate target page(s) by +90° (clockwise) */
        PdfAnnotatorModalComponent.prototype.flipPageCW = function () {
            this.applyFlipDelta(90);
        };
        /** Rotate target page(s) by -90° (counter-clockwise) */
        PdfAnnotatorModalComponent.prototype.flipPageCCW = function () {
            this.applyFlipDelta(270);
        };
        PdfAnnotatorModalComponent.prototype.applyFlipDelta = function (delta) {
            var e_1, _j;
            if (this.flipScope === 'all') {
                try {
                    for (var _k = __values(this.pages), _l = _k.next(); !_l.done; _l = _k.next()) {
                        var p = _l.value;
                        this.pageFlips[p] = ((this.pageFlips[p] || 0) + delta) % 360;
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            else {
                this.pageFlips[this.pageNo] = ((this.pageFlips[this.pageNo] || 0) + delta) % 360;
            }
            this.cdr.detectChanges();
        };
        /** Set an absolute rotation angle (0/90/180/270) */
        PdfAnnotatorModalComponent.prototype.setFlipAngle = function (angle) {
            var e_2, _j;
            if (this.flipScope === 'all') {
                try {
                    for (var _k = __values(this.pages), _l = _k.next(); !_l.done; _l = _k.next()) {
                        var p = _l.value;
                        this.pageFlips[p] = angle;
                    }
                }
                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                finally {
                    try {
                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                    }
                    finally { if (e_2) throw e_2.error; }
                }
            }
            else {
                this.pageFlips[this.pageNo] = angle;
            }
            this.cdr.detectChanges();
        };
        /** Combined visual rotation = deskew + flip (used by the page-container CSS transform) */
        PdfAnnotatorModalComponent.prototype.getPageRotation = function (p) {
            return (this.pageRotations[p] || 0) + (this.pageFlips[p] || 0);
        };
        PdfAnnotatorModalComponent.prototype.setPageRotation = function (p, angle) {
            this.pageRotations[p] = angle;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.resetPageRotation = function (p) {
            this.pageRotations[p] = 0;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.toggleDeskewPanel = function () {
            this.showDeskewPanel = !this.showDeskewPanel;
            if (this.showDeskewPanel) {
                this.closeAllPanels('deskew');
                this.showDeskewPanel = true;
                this.toolMode = 'none';
                this.activeTextBoxId = null;
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.closeDeskewPanel = function () {
            this.showDeskewPanel = false;
            this.cdr.detectChanges();
        };
        /**
         * Bake the in-progress deskew (pageRotations) into basePdfBytes immediately and
         * reload the viewer, so the user sees straightened content. 90° multiples use
         * setRotation; fine angles embed the page rotated (content tilts, annotations stay upright).
         */
        PdfAnnotatorModalComponent.prototype.applyDeskew = function () {
            return __awaiter(this, void 0, void 0, function () {
                var pdfDoc, modified, totalPages, i, pNum, rot, oldPage, _j, width, height, embeddedPage, newPage, cropBox, rad, cosVal, sinVal, dx, dy, outBytes, loadingTask, _k, tmpDoc, e_3;
                var _this = this;
                return __generator(this, function (_l) {
                    switch (_l.label) {
                        case 0:
                            if (!this.basePdfBytes)
                                return [2 /*return*/];
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังปรับหน้ากระดาษให้ตรง...';
                            _l.label = 1;
                        case 1:
                            _l.trys.push([1, 14, 15, 16]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 2:
                            pdfDoc = _l.sent();
                            modified = false;
                            totalPages = pdfDoc.getPageCount();
                            i = totalPages - 1;
                            _l.label = 3;
                        case 3:
                            if (!(i >= 0)) return [3 /*break*/, 8];
                            pNum = i + 1;
                            rot = this.pageRotations[pNum];
                            if (!(rot && rot !== 0)) return [3 /*break*/, 7];
                            modified = true;
                            oldPage = pdfDoc.getPage(i);
                            if (!(rot % 90 === 0)) return [3 /*break*/, 4];
                            oldPage.setRotation(pdfLib.degrees(oldPage.getRotation().angle + rot));
                            return [3 /*break*/, 6];
                        case 4:
                            _j = oldPage.getSize(), width = _j.width, height = _j.height;
                            return [4 /*yield*/, pdfDoc.embedPage(oldPage)];
                        case 5:
                            embeddedPage = _l.sent();
                            newPage = pdfDoc.insertPage(i + 1, [width, height]);
                            cropBox = oldPage.getCropBox();
                            if (cropBox)
                                newPage.setCropBox(cropBox.x, cropBox.y, cropBox.width, cropBox.height);
                            rad = (rot * Math.PI) / 180;
                            cosVal = Math.cos(rad);
                            sinVal = Math.sin(rad);
                            dx = (-width / 2) * cosVal - (-height / 2) * sinVal;
                            dy = (-width / 2) * sinVal + (-height / 2) * cosVal;
                            newPage.drawPage(embeddedPage, { x: (width / 2) + dx, y: (height / 2) + dy, rotate: pdfLib.degrees(rot) });
                            pdfDoc.removePage(i);
                            _l.label = 6;
                        case 6:
                            this.pageRotations[pNum] = 0;
                            _l.label = 7;
                        case 7:
                            i--;
                            return [3 /*break*/, 3];
                        case 8:
                            if (!modified) return [3 /*break*/, 13];
                            return [4 /*yield*/, pdfDoc.save()];
                        case 9:
                            outBytes = _l.sent();
                            this.basePdfBytes = outBytes.buffer.slice(outBytes.byteOffset, outBytes.byteOffset + outBytes.byteLength);
                            loadingTask = pdfjsLib__namespace.getDocument({ data: this.basePdfBytes.slice(0) });
                            _k = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 10:
                            _k.pdfDocProxy = _l.sent();
                            this.pageCount = this.pdfDocProxy.numPages || 1;
                            this.pages = Array.from({ length: this.pageCount }, function (_, idx) { return idx + 1; });
                            this.pages.forEach(function (p) { return _this.ensurePage(p); });
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 11:
                            tmpDoc = _l.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                                var cropBox = pg.getCropBox();
                                var mediaBox = pg.getMediaBox();
                                var effectiveBox = (cropBox.width > 0 && cropBox.height > 0 &&
                                    (cropBox.x !== mediaBox.x || cropBox.y !== mediaBox.y ||
                                        cropBox.width !== mediaBox.width || cropBox.height !== mediaBox.height))
                                    ? cropBox : mediaBox;
                                _this.pdfPageAspects.set(idx + 1, effectiveBox.width / effectiveBox.height);
                            });
                            this.renderedPages.clear();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 12:
                            _l.sent();
                            _l.label = 13;
                        case 13: return [3 /*break*/, 16];
                        case 14:
                            e_3 = _l.sent();
                            console.error('Error deskewing', e_3);
                            return [3 /*break*/, 16];
                        case 15:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.closeDeskewPanel();
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 16: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.toggleSplitPanel = function () {
            this.showSplitPanel = !this.showSplitPanel;
            if (this.showSplitPanel) {
                this.closeAllPanels('split');
                this.showSplitPanel = true;
                this.splitPageRange = "1-" + this.pageCount;
            }
            this.cdr.detectChanges();
        };
        /** Export the pages listed in splitPageRange (e.g. "1, 3, 5-10") as a new PDF download */
        PdfAnnotatorModalComponent.prototype.executeSplitPdf = function () {
            return __awaiter(this, void 0, void 0, function () {
                var pagesToKeep, parts, parts_1, parts_1_1, p, trimmed, _j, startStr, endStr, start, end, tmp, i, page, toast, sourceDoc, newDoc_1, sortedPages, indicesToCopy, copiedPages, splitBytes, blob, url, a, toast, e_4, toast;
                var e_5, _k;
                return __generator(this, function (_l) {
                    switch (_l.label) {
                        case 0:
                            if (!this.basePdfBytes || !this.splitPageRange.trim())
                                return [2 /*return*/];
                            pagesToKeep = new Set();
                            parts = this.splitPageRange.split(',');
                            try {
                                for (parts_1 = __values(parts), parts_1_1 = parts_1.next(); !parts_1_1.done; parts_1_1 = parts_1.next()) {
                                    p = parts_1_1.value;
                                    trimmed = p.trim();
                                    if (!trimmed)
                                        continue;
                                    if (trimmed.includes('-')) {
                                        _j = __read(trimmed.split('-'), 2), startStr = _j[0], endStr = _j[1];
                                        start = parseInt(startStr, 10);
                                        end = parseInt(endStr, 10);
                                        if (!isNaN(start) && !isNaN(end)) {
                                            if (start > end) {
                                                tmp = start;
                                                start = end;
                                                end = tmp;
                                            }
                                            start = Math.max(1, start);
                                            end = Math.min(this.pageCount, end);
                                            for (i = start; i <= end; i++)
                                                pagesToKeep.add(i);
                                        }
                                    }
                                    else {
                                        page = parseInt(trimmed, 10);
                                        if (!isNaN(page) && page >= 1 && page <= this.pageCount)
                                            pagesToKeep.add(page);
                                    }
                                }
                            }
                            catch (e_5_1) { e_5 = { error: e_5_1 }; }
                            finally {
                                try {
                                    if (parts_1_1 && !parts_1_1.done && (_k = parts_1.return)) _k.call(parts_1);
                                }
                                finally { if (e_5) throw e_5.error; }
                            }
                            if (!(pagesToKeep.size === 0)) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.toastCtrl.create({ message: 'รูปแบบหน้าไม่ถูกต้อง', duration: 2000, color: 'danger' })];
                        case 1:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 2:
                            _l.sent();
                            return [2 /*return*/];
                        case 3:
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังแยกเอกสาร PDF...';
                            _l.label = 4;
                        case 4:
                            _l.trys.push([4, 11, 14, 15]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 5:
                            sourceDoc = _l.sent();
                            return [4 /*yield*/, pdfLib.PDFDocument.create()];
                        case 6:
                            newDoc_1 = _l.sent();
                            sortedPages = Array.from(pagesToKeep).sort(function (a, b) { return a - b; });
                            indicesToCopy = sortedPages.map(function (p) { return p - 1; });
                            return [4 /*yield*/, newDoc_1.copyPages(sourceDoc, indicesToCopy)];
                        case 7:
                            copiedPages = _l.sent();
                            copiedPages.forEach(function (p) { return newDoc_1.addPage(p); });
                            return [4 /*yield*/, newDoc_1.save()];
                        case 8:
                            splitBytes = _l.sent();
                            blob = new Blob([splitBytes], { type: 'application/pdf' });
                            url = window.URL.createObjectURL(blob);
                            a = document.createElement('a');
                            a.href = url;
                            a.download = "split_" + (this.fileName || 'document');
                            document.body.appendChild(a);
                            a.click();
                            window.URL.revokeObjectURL(url);
                            document.body.removeChild(a);
                            this.showSplitPanel = false;
                            return [4 /*yield*/, this.toastCtrl.create({ message: "\u0E41\u0E22\u0E01\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E2A\u0E33\u0E40\u0E23\u0E47\u0E08 (" + sortedPages.length + " \u0E2B\u0E19\u0E49\u0E32)", duration: 2000, color: 'success' })];
                        case 9:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 10:
                            _l.sent();
                            return [3 /*break*/, 15];
                        case 11:
                            e_4 = _l.sent();
                            console.error('Split PDF failed', e_4);
                            return [4 /*yield*/, this.toastCtrl.create({ message: 'เกิดข้อผิดพลาดในการแยก PDF', duration: 3000, color: 'danger' })];
                        case 12:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 13:
                            _l.sent();
                            return [3 /*break*/, 15];
                        case 14:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 15: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.toggleWatermarkPanel = function () {
            this.showWatermarkPanel = !this.showWatermarkPanel;
            if (this.showWatermarkPanel) {
                this.closeAllPanels('watermark');
                this.showWatermarkPanel = true;
                this.toolMode = 'none';
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.closeWatermarkPanel = function () {
            this.showWatermarkPanel = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.applyWatermark = function () {
            this.watermark.enabled = true;
            this.showWatermarkPanel = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.removeWatermark = function () {
            this.watermark.enabled = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.onWatermarkImageSelected = function (event) {
            var _this = this;
            var _a;
            var input = event.target;
            if (!((_a = input.files) === null || _a === void 0 ? void 0 : _a.length))
                return;
            var file = input.files[0];
            var reader = new FileReader();
            reader.onload = function () {
                _this.watermark.imageDataUrl = reader.result;
                _this.watermark.type = 'image';
                _this.cdr.detectChanges();
            };
            reader.readAsDataURL(file);
        };
        PdfAnnotatorModalComponent.prototype.getWatermarkPreviewStyle = function (pageNum) {
            if (!this.watermark.enabled)
                return { display: 'none' };
            if (this.watermark.scope === 'current' && pageNum !== this.pageNo)
                return { display: 'none' };
            return { display: 'block' };
        };
        /** Parse custom page range like "1,3,5-10" into a Set */
        PdfAnnotatorModalComponent.prototype.parseCustomPageSet = function (input, maxPage) {
            var e_6, _j;
            var pages = new Set();
            if (!input || !input.trim())
                return pages;
            var parts = input.split(',');
            try {
                for (var parts_2 = __values(parts), parts_2_1 = parts_2.next(); !parts_2_1.done; parts_2_1 = parts_2.next()) {
                    var part = parts_2_1.value;
                    var trimmed = part.trim();
                    if (!trimmed)
                        continue;
                    if (trimmed.includes('-')) {
                        var _k = __read(trimmed.split('-'), 2), s = _k[0], e = _k[1];
                        var start = parseInt(s.trim(), 10);
                        var end = parseInt(e.trim(), 10);
                        if (!isNaN(start) && !isNaN(end) && start >= 1 && end <= maxPage && start <= end) {
                            for (var i = start; i <= end; i++)
                                pages.add(i);
                        }
                    }
                    else {
                        var num = parseInt(trimmed, 10);
                        if (!isNaN(num) && num >= 1 && num <= maxPage)
                            pages.add(num);
                    }
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (parts_2_1 && !parts_2_1.done && (_j = parts_2.return)) _j.call(parts_2);
                }
                finally { if (e_6) throw e_6.error; }
            }
            return pages;
        };
        /** ตรวจสอบว่าหน้านี้ควรแสดงเลขหน้าหรือไม่ (p = physical page 1-based) */
        PdfAnnotatorModalComponent.prototype.shouldShowPageNum = function (p) {
            if (!this.pageNumber.enabled)
                return false;
            var startAt = Number(this.pageNumber.startAtPage) || 1;
            var startFrom = Number(this.pageNumber.startFrom) || 1;
            if (p < startAt)
                return false;
            if (this.pageNumber.skipFirstPage && p === startAt)
                return false;
            var logicalPage = p - startAt + startFrom;
            switch (this.pageNumber.pageScope) {
                case 'odd': return logicalPage % 2 !== 0;
                case 'even': return logicalPage % 2 === 0;
                case 'custom': {
                    var customSet = this.parseCustomPageSet(this.pageNumber.customPages, this.pageCount);
                    return customSet.has(p);
                }
                default: return true;
            }
        };
        PdfAnnotatorModalComponent.prototype.toRoman = function (n, upper) {
            if (n <= 0 || n > 3999)
                return String(n);
            var vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
            var romUp = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I'];
            var romLo = ['m', 'cm', 'd', 'cd', 'c', 'xc', 'l', 'xl', 'x', 'ix', 'v', 'iv', 'i'];
            var syms = upper ? romUp : romLo;
            var result = '';
            for (var i = 0; i < vals.length; i++) {
                while (n >= vals[i]) {
                    result += syms[i];
                    n -= vals[i];
                }
            }
            return result;
        };
        PdfAnnotatorModalComponent.prototype.toThaiNumber = function (n) {
            var thaiDigits = ['๐', '๑', '๒', '๓', '๔', '๕', '๖', '๗', '๘', '๙'];
            return String(n).split('').map(function (d) { return thaiDigits[parseInt(d)] || d; }).join('');
        };
        PdfAnnotatorModalComponent.prototype.formatPageNum = function (p) {
            var startAt = Number(this.pageNumber.startAtPage) || 1;
            var startFrom = Number(this.pageNumber.startFrom) || 1;
            var num = p - startAt + startFrom;
            var numStr;
            switch (this.pageNumber.format) {
                case 'thai':
                    numStr = this.toThaiNumber(num);
                    break;
                case 'roman':
                    numStr = this.toRoman(num, false);
                    break;
                case 'roman-upper':
                    numStr = this.toRoman(num, true);
                    break;
                default: numStr = String(num);
            }
            var prefix = this.pageNumber.showPrefix ? (this.pageNumber.prefixText || '') : '';
            var suffix = this.pageNumber.suffixText || '';
            return prefix + numStr + suffix;
        };
        /** คำนวณตำแหน่ง — รองรับ mirror (สลับซ้าย-ขวาตามคี่/คู่) */
        PdfAnnotatorModalComponent.prototype.getEffectivePosition = function (p) {
            var pos = this.pageNumber.position;
            if (this.pageNumber.mirror) {
                var startAt = Number(this.pageNumber.startAtPage) || 1;
                var startFrom = Number(this.pageNumber.startFrom) || 1;
                var logicalPage = p - startAt + startFrom;
                var isEven = logicalPage % 2 === 0;
                if (isEven) {
                    if (pos.endsWith('right'))
                        pos = pos.replace('right', 'left');
                    else if (pos.endsWith('left'))
                        pos = pos.replace('left', 'right');
                }
            }
            return pos;
        };
        PdfAnnotatorModalComponent.prototype.togglePageNumberPanel = function () {
            this.showPageNumberPanel = !this.showPageNumberPanel;
            if (this.showPageNumberPanel) {
                this.closeAllPanels('pageNumber');
                this.showPageNumberPanel = true;
                this.toolMode = 'none';
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.closePageNumberPanel = function () {
            this.showPageNumberPanel = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.applyPageNumbers = function () {
            this.pageNumber.enabled = true;
            this.showPageNumberPanel = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.removePageNumbers = function () {
            this.pageNumber.enabled = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.getPageNumPositionStyle = function (page) {
            var pos = page ? this.getEffectivePosition(page) : this.pageNumber.position;
            var style = { position: 'absolute', padding: '8px 14px', zIndex: 6, pointerEvents: 'none' };
            if (pos.startsWith('top'))
                style.top = '0';
            if (pos.startsWith('bottom'))
                style.bottom = '0';
            if (pos.endsWith('left')) {
                style.left = '0';
                style.textAlign = 'left';
            }
            if (pos.endsWith('center')) {
                style.left = '0';
                style.right = '0';
                style.textAlign = 'center';
            }
            if (pos.endsWith('right')) {
                style.right = '0';
                style.textAlign = 'right';
            }
            return style;
        };
        PdfAnnotatorModalComponent.prototype.loadHistoryFromApi = function () {
            var _this = this;
            if (!this.documentId)
                return;
            this.isLoadingHistory = true;
            this.pdfSvc.getHistory(this.documentId, 100).subscribe({
                next: function (res) {
                    _this.historyEntries = res.data;
                    _this.isLoadingHistory = false;
                },
                error: function () { _this.isLoadingHistory = false; },
            });
        };
        PdfAnnotatorModalComponent.prototype.getHistoryActionIcon = function (type) {
            var map = {
                sign: 'finger-print', text: 'text', draw: 'brush',
                highlight: 'color-fill-outline', shape: 'shapes-outline', image: 'image-outline',
                page_insert: 'add-circle-outline', page_delete: 'trash-outline',
                date_stamp: 'calendar', save: 'save-outline', upload: 'cloud-upload-outline', open: 'open-outline',
            };
            return map[type] || 'ellipse-outline';
        };
        PdfAnnotatorModalComponent.prototype.getHistoryActionLabel = function (type) {
            var map = {
                sign: 'ลงลายเซ็น', text: 'เพิ่มข้อความ', draw: 'วาด', highlight: 'ไฮไลท์',
                shape: 'รูปทรง', image: 'รูปภาพ', page_insert: 'แทรกหน้า', page_delete: 'ลบหน้า',
                date_stamp: 'วันที่', save: 'บันทึก', upload: 'นำเข้า', open: 'เปิดเอกสาร',
            };
            return map[type] || type;
        };
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "canUndoPageOp", {
            get: function () { return this.pageHistoryStack.length > 0; },
            enumerable: false,
            configurable: true
        });
        PdfAnnotatorModalComponent.prototype.savePageSnapshot = function () {
            if (!this.basePdfBytes)
                return;
            // Deep-clone annotation arrays and records so mutations don't affect snapshot
            var cloneArr = function (a) { return a.map(function (x) { return (Object.assign({}, x)); }); };
            var cloneRec = function (r) {
                var e_7, _j;
                var out = {};
                try {
                    for (var _k = __values(Object.keys(r)), _l = _k.next(); !_l.done; _l = _k.next()) {
                        var k = _l.value;
                        out[Number(k)] = __spreadArray([], __read(r[Number(k)]));
                    }
                }
                catch (e_7_1) { e_7 = { error: e_7_1 }; }
                finally {
                    try {
                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                    }
                    finally { if (e_7) throw e_7.error; }
                }
                return out;
            };
            this.pageHistoryStack.push({
                bytes: this.basePdfBytes.slice(0),
                pageNo: this.pageNo,
                textBoxes: cloneArr(this.textBoxes),
                imageStamps: cloneArr(this.imageStamps),
                shapeStamps: cloneArr(this.shapeStamps),
                signatureStamps: cloneArr(this.signatureStamps),
                dateStamps: cloneArr(this.dateStamps),
                pdfFormFields: cloneArr(this.pdfFormFields),
                strokes: cloneRec(this.strokes),
                shapes: cloneRec(this.shapes),
                redoStack: cloneRec(this.redoStack),
            });
            // Keep last 20 snapshots
            if (this.pageHistoryStack.length > 20)
                this.pageHistoryStack.shift();
        };
        PdfAnnotatorModalComponent.prototype.undoPageOp = function () {
            return __awaiter(this, void 0, void 0, function () {
                var snapshot, copy, loadingTask, _j, prevCount, tmpDoc, _1, toast, err_1;
                var _this = this;
                return __generator(this, function (_k) {
                    switch (_k.label) {
                        case 0:
                            snapshot = this.pageHistoryStack.pop();
                            if (!snapshot)
                                return [2 /*return*/];
                            this.showInsertMenu = false;
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังย้อนกลับ...';
                            this.cdr.detectChanges();
                            _k.label = 1;
                        case 1:
                            _k.trys.push([1, 11, 12, 13]);
                            this.basePdfBytes = snapshot.bytes;
                            this.textBoxes = snapshot.textBoxes;
                            this.imageStamps = snapshot.imageStamps;
                            this.shapeStamps = snapshot.shapeStamps;
                            this.signatureStamps = snapshot.signatureStamps;
                            this.dateStamps = snapshot.dateStamps;
                            this.pdfFormFields = snapshot.pdfFormFields || [];
                            this.strokes = snapshot.strokes;
                            this.shapes = snapshot.shapes;
                            this.redoStack = snapshot.redoStack;
                            copy = this.basePdfBytes.slice(0);
                            if (this.pdfDocProxy) {
                                this.pdfDocProxy.destroy();
                                this.pdfDocProxy = null;
                            }
                            loadingTask = pdfjsLib__namespace.getDocument({ data: copy.slice(0) });
                            _j = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 2:
                            _j.pdfDocProxy = _k.sent();
                            prevCount = this.pageCount;
                            this.pageCount = this.pdfDocProxy.numPages;
                            this.syncLoadedWindow(prevCount);
                            this.pdfPageAspects.clear();
                            this.pdfPageRotations.clear();
                            _k.label = 3;
                        case 3:
                            _k.trys.push([3, 5, , 6]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(copy)];
                        case 4:
                            tmpDoc = _k.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), width = _j.width, height = _j.height;
                                _this.pdfPageAspects.set(idx + 1, width / height);
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            return [3 /*break*/, 6];
                        case 5:
                            _1 = _k.sent();
                            return [3 /*break*/, 6];
                        case 6:
                            this.pageNo = Math.min(snapshot.pageNo, this.pageCount);
                            this.renderedPages.clear();
                            this.renderingPages.clear();
                            return [4 /*yield*/, this.generateThumbnails()];
                        case 7:
                            _k.sent();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 8:
                            _k.sent();
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: 'ย้อนกลับเรียบร้อยแล้ว',
                                    duration: 2000,
                                    color: 'success',
                                    position: 'bottom'
                                })];
                        case 9:
                            toast = _k.sent();
                            return [4 /*yield*/, toast.present()];
                        case 10:
                            _k.sent();
                            return [3 /*break*/, 13];
                        case 11:
                            err_1 = _k.sent();
                            console.error('undoPageOp error:', err_1);
                            return [3 /*break*/, 13];
                        case 12:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 13: return [2 /*return*/];
                    }
                });
            });
        };
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "activeTextBox", {
            get: function () {
                var _this = this;
                return this.textBoxes.find(function (t) { return t.id === _this.activeTextBoxId; }) || null;
            },
            enumerable: false,
            configurable: true
        });
        PdfAnnotatorModalComponent.prototype.close = function () {
            this.unlockOrientation();
            this.closed.emit();
            this.dismissModal();
        };
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "drawMode", {
            get: function () { return this.toolMode === 'draw' || (this.toolMode === 'none' && this.activeObjectType === 'signature'); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "eraserMode", {
            get: function () { return this.toolMode === 'eraser'; },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "highlightMode", {
            get: function () { return this.toolMode === 'highlight'; },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "shapeMode", {
            get: function () { return this.toolMode === 'shape' || (this.toolMode === 'none' && this.activeObjectType === 'shape'); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "textPlaceMode", {
            get: function () { return this.toolMode === 'text' || (this.toolMode === 'none' && this.activeObjectType === 'text'); },
            enumerable: false,
            configurable: true
        });
        /** Dismiss the host Ionic modal if present; never throws when used inline. */
        PdfAnnotatorModalComponent.prototype.dismissModal = function (data) {
            this.modalCtrl.dismiss(data).catch(function () { });
        };
        PdfAnnotatorModalComponent.prototype.ngOnInit = function () {
            this.strokes = {};
            this.shapes = {};
            this.redoStack = {};
            this.textBoxes = [];
            this.imageStamps = [];
            this.shapeStamps = [];
            this.signatureStamps = [];
            this.dateStamps = [];
            this.activeStroke = null;
            this.activeShape = null;
            this.activeTextBoxId = null;
            this.activeObjectId = null;
            this.activeObjectType = null;
            this.pendingSignatureDataUrl = null;
            this.toolMode = 'none';
            this.pageNo = 1;
            this.zoom = 1;
            this.savedSignatures = [];
            this.showSignaturePad = false;
            this.showSignaturePicker = false;
            this.showPreviewOverlay = false;
            this.previewUrl = null;
            this.lastSavedBlob = null;
            this.lastSavedFileName = '';
            this.isDrawingSignature = false;
            this.signaturePoints = [];
            this.signatureStrokes = [];
            this.isLoadingSignatures = false;
            this.isDragging = false;
            this.dragTextBoxId = null;
            this.isResizing = false;
            this.resizeTextBoxId = null;
            this.isDraggingImage = false;
            this.dragImageId = null;
            this.isResizingImage = false;
            this.resizeImageId = null;
            this.contextMenu.show = false;
            this.showShapeMenu = false;
            this.loadSettings(); // Restore user preferences
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.saveSettings = function () {
            var settings = {
                brushColor: this.brushColor,
                brushSize: this.brushSize,
                highlightColor: this.highlightColor,
                highlightSize: this.highlightSize,
                eraserSize: this.eraserSize,
                textColor: this.textColor,
                textFontSize: this.textFontSize,
                dateColor: this.dateColor,
                dateFontSize: this.dateFontSize,
                shapeType: this.shapeType,
                shapeStrokeColor: this.shapeStrokeColor,
                shapeFillColor: this.shapeFillColor,
                shapeFillEnabled: this.shapeFillEnabled,
                shapeStrokeSize: this.shapeStrokeSize,
                shapeNoStroke: this.shapeNoStroke,
                pagesPerChunk: this.pagesPerChunk,
                tbDefaultFontFamily: this.tbDefaultFontFamily,
                tbDefaultBold: this.tbDefaultBold,
                tbDefaultItalic: this.tbDefaultItalic,
                tbDefaultAlign: this.tbDefaultAlign,
                tbDefaultLetterSpacing: this.tbDefaultLetterSpacing,
                tbDefaultLineHeight: this.tbDefaultLineHeight,
            };
            localStorage.setItem(this.SETTINGS_KEY, JSON.stringify(settings));
        };
        PdfAnnotatorModalComponent.prototype.loadSettings = function () {
            try {
                var saved = localStorage.getItem(this.SETTINGS_KEY);
                if (saved) {
                    var settings = JSON.parse(saved);
                    if (settings.brushColor)
                        this.brushColor = settings.brushColor;
                    if (settings.brushSize)
                        this.brushSize = settings.brushSize;
                    if (settings.highlightColor)
                        this.highlightColor = settings.highlightColor;
                    if (settings.highlightSize)
                        this.highlightSize = settings.highlightSize;
                    if (settings.eraserSize)
                        this.eraserSize = settings.eraserSize;
                    if (settings.textColor)
                        this.textColor = settings.textColor;
                    if (settings.textFontSize)
                        this.textFontSize = settings.textFontSize;
                    if (settings.dateColor)
                        this.dateColor = settings.dateColor;
                    if (settings.dateFontSize)
                        this.dateFontSize = settings.dateFontSize;
                    if (settings.shapeType)
                        this.shapeType = settings.shapeType;
                    if (settings.shapeStrokeColor)
                        this.shapeStrokeColor = settings.shapeStrokeColor;
                    if (settings.shapeFillColor)
                        this.shapeFillColor = settings.shapeFillColor;
                    if (settings.shapeFillEnabled !== undefined)
                        this.shapeFillEnabled = settings.shapeFillEnabled;
                    if (settings.shapeStrokeSize)
                        this.shapeStrokeSize = settings.shapeStrokeSize;
                    if (settings.shapeNoStroke !== undefined)
                        this.shapeNoStroke = settings.shapeNoStroke;
                    if (settings.pagesPerChunk)
                        this.pagesPerChunk = settings.pagesPerChunk;
                    if (settings.tbDefaultFontFamily)
                        this.tbDefaultFontFamily = settings.tbDefaultFontFamily;
                    if (settings.tbDefaultBold !== undefined)
                        this.tbDefaultBold = settings.tbDefaultBold;
                    if (settings.tbDefaultItalic !== undefined)
                        this.tbDefaultItalic = settings.tbDefaultItalic;
                    if (settings.tbDefaultAlign)
                        this.tbDefaultAlign = settings.tbDefaultAlign;
                    if (settings.tbDefaultLetterSpacing !== undefined)
                        this.tbDefaultLetterSpacing = settings.tbDefaultLetterSpacing;
                    if (settings.tbDefaultLineHeight !== undefined)
                        this.tbDefaultLineHeight = settings.tbDefaultLineHeight;
                }
            }
            catch (e) {
                console.warn('Failed to load settings from localStorage', e);
            }
        };
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "visibleTextBoxes", {
            get: function () { return this.getTextBoxesForPage(this.pageNo); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "visibleImageStamps", {
            get: function () { return this.getImageStampsForPage(this.pageNo); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "visibleSignatures", {
            get: function () { return this.getSignatureStampsForPage(this.pageNo); },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(PdfAnnotatorModalComponent.prototype, "visibleDateStamps", {
            get: function () { return this.getDateStampsForPage(this.pageNo); },
            enumerable: false,
            configurable: true
        });
        PdfAnnotatorModalComponent.prototype.getTextBoxesForPage = function (p) { return this.textBoxes.filter(function (t) { return t.page === p; }); };
        PdfAnnotatorModalComponent.prototype.getImageStampsForPage = function (p) { return this.imageStamps.filter(function (i) { return i.page === p; }); };
        PdfAnnotatorModalComponent.prototype.getRegularImageStampsForPage = function (p) { return this.imageStamps.filter(function (i) { return i.page === p && !i.id.startsWith('mark_'); }); };
        PdfAnnotatorModalComponent.prototype.getMarkStampsForPage = function (p) { return this.imageStamps.filter(function (i) { return i.page === p && i.id.startsWith('mark_'); }); };
        PdfAnnotatorModalComponent.prototype.getShapeStampsForPage = function (p) { return this.shapeStamps.filter(function (s) { return s.page === p; }); };
        PdfAnnotatorModalComponent.prototype.getSignatureStampsForPage = function (p) { return this.signatureStamps.filter(function (s) { return s.page === p; }); };
        PdfAnnotatorModalComponent.prototype.getDateStampsForPage = function (p) { return this.dateStamps.filter(function (d) { return d.page === p; }); };
        PdfAnnotatorModalComponent.prototype.getMarkSvgContent = function (markType, color) {
            var c = color || '#000000';
            if (markType === 'check') {
                return "<polyline points=\"12,52 42,82 88,18\" stroke=\"" + c + "\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" fill=\"none\"/>";
            }
            else if (markType === 'cross') {
                return "<line x1=\"15\" y1=\"15\" x2=\"85\" y2=\"85\" stroke=\"" + c + "\" stroke-width=\"10\" stroke-linecap=\"round\"/>" +
                    ("<line x1=\"85\" y1=\"15\" x2=\"15\" y2=\"85\" stroke=\"" + c + "\" stroke-width=\"10\" stroke-linecap=\"round\"/>");
            }
            else {
                return "<circle cx=\"50\" cy=\"50\" r=\"38\" fill=\"" + c + "\"/>";
            }
        };
        /** Lock screen orientation to portrait while annotating */
        PdfAnnotatorModalComponent.prototype.lockOrientation = function () {
            return __awaiter(this, void 0, void 0, function () {
                var orientation, _2;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            _j.trys.push([0, 3, , 4]);
                            orientation = screen.orientation;
                            if (!(orientation && orientation.lock)) return [3 /*break*/, 2];
                            return [4 /*yield*/, orientation.lock('portrait-primary')];
                        case 1:
                            _j.sent();
                            _j.label = 2;
                        case 2: return [3 /*break*/, 4];
                        case 3:
                            _2 = _j.sent();
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        /** Unlock screen orientation when leaving the annotator */
        PdfAnnotatorModalComponent.prototype.unlockOrientation = function () {
            try {
                var orientation = screen.orientation;
                if (orientation && orientation.unlock) {
                    orientation.unlock();
                }
            }
            catch (_) { /* ignore */ }
        };
        PdfAnnotatorModalComponent.prototype.ngAfterViewInit = function () {
            var _a, _b;
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            pdfjsLib__namespace.GlobalWorkerOptions.workerSrc = this.pdfWorkerSrc;
                            // Lock orientation to portrait so the PDF doesn't rotate during annotation
                            this.lockOrientation();
                            // Clear and reset canvases before loading new PDF
                            (_a = this.pdfCanvases) === null || _a === void 0 ? void 0 : _a.forEach(function (ref) {
                                var canvas = ref.nativeElement;
                                var ctx = canvas.getContext('2d');
                                if (ctx) {
                                    canvas.width = 0;
                                    canvas.height = 0;
                                    canvas.style.width = '0px';
                                    canvas.style.height = '0px';
                                }
                            });
                            (_b = this.annotCanvases) === null || _b === void 0 ? void 0 : _b.forEach(function (ref) {
                                var canvas = ref.nativeElement;
                                var ctx = canvas.getContext('2d');
                                if (ctx) {
                                    canvas.width = 0;
                                    canvas.height = 0;
                                    canvas.style.width = '0px';
                                    canvas.style.height = '0px';
                                }
                            });
                            // Ensure state is clean
                            this.strokes = {};
                            this.shapes = {};
                            this.redoStack = {};
                            this.activeStroke = null;
                            this.activeShape = null;
                            this.activeObjectId = null;
                            this.activeObjectType = null;
                            return [4 /*yield*/, this.loadPdfBytesAndInitPdfjs()];
                        case 1:
                            _j.sent();
                            this.zone.runOutsideAngular(function () {
                                _this.setupResizeAutoRender();
                            });
                            return [4 /*yield*/, this.fitWidth()];
                        case 2:
                            _j.sent();
                            this.syncToolModeStyles();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.syncToolModeStyles = function () {
            var _this = this;
            // Set touch-action: none for ALL active tool modes to prevent iPad scroll
            var hasActiveTool = this.toolMode !== 'none';
            this.pages.forEach(function (p) {
                var canvas = _this.getAnnotCanvas(p);
                if (canvas) {
                    canvas.style.touchAction = hasActiveTool ? 'none' : 'auto';
                }
            });
            this.updateCursor();
        };
        PdfAnnotatorModalComponent.prototype.ngOnDestroy = function () {
            var _this = this;
            if (this.resizeObserver)
                this.resizeObserver.disconnect();
            // Cleanup PDF.js document to free memory
            if (this.pdfDocProxy) {
                this.pdfDocProxy.destroy();
                this.pdfDocProxy = null;
            }
            // Clear all canvases to release memory
            this.pages.forEach(function (p) {
                var pdfCanvas = _this.getPdfCanvas(p);
                var annotCanvas = _this.getAnnotCanvas(p);
                if (pdfCanvas) {
                    var ctx = pdfCanvas.getContext('2d');
                    if (ctx)
                        ctx.clearRect(0, 0, pdfCanvas.width, pdfCanvas.height);
                    pdfCanvas.width = 0;
                    pdfCanvas.height = 0;
                }
                if (annotCanvas) {
                    var ctx = annotCanvas.getContext('2d');
                    if (ctx)
                        ctx.clearRect(0, 0, annotCanvas.width, annotCanvas.height);
                    annotCanvas.width = 0;
                    annotCanvas.height = 0;
                }
            });
            // Clear data arrays
            this.pageThumbnails = [];
            this.basePdfBytes = null;
            this.strokes = {};
            this.shapes = {};
            this.textBoxes = [];
            this.imageStamps = [];
            this.shapeStamps = [];
            this.signatureStamps = [];
            this.dateStamps = [];
        };
        /* ================= Keyboard Shortcuts ================= */
        PdfAnnotatorModalComponent.prototype.onDocumentPointerDown = function (event) {
            var _this = this;
            if (this.contextMenu.show) {
                var target = event.target;
                if (!target.closest('.custom-context-menu')) {
                    this.zone.run(function () {
                        _this.closeContextMenu();
                        _this.cdr.detectChanges();
                    });
                }
            }
        };
        PdfAnnotatorModalComponent.prototype.handleKeyboard = function (event) {
            // Undo: Ctrl+Z or Cmd+Z
            if ((event.ctrlKey || event.metaKey) && event.key === 'z' && !event.shiftKey) {
                event.preventDefault();
                this.undo();
                return;
            }
            // Redo: Ctrl+Y or Ctrl+Shift+Z or Cmd+Shift+Z
            if ((event.ctrlKey || event.metaKey) && (event.key === 'y' || (event.key === 'z' && event.shiftKey))) {
                event.preventDefault();
                this.redo();
                return;
            }
            // Escape: exit modes
            if (event.key === 'Escape') {
                this.exitAllModes();
                return;
            }
            // Delete: remove active object
            if (event.key === 'Delete' || event.key === 'Backspace') {
                var activeEl = document.activeElement;
                // Don't delete if user is typing in a textarea or input
                if ((activeEl === null || activeEl === void 0 ? void 0 : activeEl.tagName) === 'TEXTAREA' || (activeEl === null || activeEl === void 0 ? void 0 : activeEl.tagName) === 'INPUT') {
                    return;
                }
                if (this.activeObjectId && this.activeObjectType) {
                    if (this.activeObjectType === 'text')
                        this.removeTextBox(this.activeObjectId);
                    else if (this.activeObjectType === 'shape')
                        this.removeShapeStamp(this.activeObjectId);
                    else if (this.activeObjectType === 'image')
                        this.removeImage(this.activeObjectId);
                    else if (this.activeObjectType === 'signature')
                        this.removeSignature(this.activeObjectId);
                    else if (this.activeObjectType === 'date')
                        this.removeDateStamp(this.activeObjectId);
                    this.activeObjectId = null;
                    this.activeObjectType = null;
                }
            }
        };
        PdfAnnotatorModalComponent.prototype.exitAllModes = function () {
            this.toolMode = 'none';
            this.showShapeMenu = false;
            this.activeTextBoxId = null;
            this.activeObjectId = null;
            this.activeObjectType = null;
            this.pendingSignatureDataUrl = null;
            this.closeContextMenu();
            this.syncToolModeStyles(); // Reset touch-action so iPad can scroll/pan PDF again
            this.updateCursor();
        };
        /* ================= User Guide Methods ================= */
        PdfAnnotatorModalComponent.prototype.toggleUserGuide = function (e) {
            if (e) {
                e.stopPropagation();
                e.preventDefault();
            }
            this.showUserGuidePanel = !this.showUserGuidePanel;
            if (this.showUserGuidePanel) {
                this.isEditingGuide = false;
                this.fetchGuideData();
            }
        };
        PdfAnnotatorModalComponent.prototype.fetchGuideData = function () {
            var _this = this;
            // Simulate API fetch
            this.isLoadingGuide = true;
            setTimeout(function () {
                // Logic for actual API fetch goes here (e.g. this.accessProviders.postData(...))
                _this.isLoadingGuide = false;
            }, 500);
        };
        PdfAnnotatorModalComponent.prototype.editGuide = function () {
            if (!this.canManageGuide)
                return;
            this.tempGuideContent = this.userGuideContent;
            this.isEditingGuide = true;
        };
        PdfAnnotatorModalComponent.prototype.cancelEditGuide = function () {
            this.isEditingGuide = false;
            this.tempGuideContent = '';
        };
        PdfAnnotatorModalComponent.prototype.saveGuide = function () {
            // Simulate API save
            this.userGuideContent = this.tempGuideContent;
            this.isEditingGuide = false;
            // Call API here to save permanently
            // e.g. this.accessProviders.postData({ content: this.userGuideContent }, 'save_guide.php')...
        };
        /* ================= Context Menu Methods ================= */
        PdfAnnotatorModalComponent.prototype.closeContextMenu = function () {
            if (this.contextMenu.show) {
                this.contextMenu.show = false;
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.onContextMenu = function (e, id, type) {
            e.preventDefault();
            e.stopPropagation();
            // Auto-switch to select mode when right clicking to ensure smooth UX
            if (this.toolMode !== 'none') {
                this.setToolMode('none');
            }
            // Position menu exactly at mouse
            this.contextMenu.x = e.clientX;
            this.contextMenu.y = e.clientY;
            this.contextMenu.targetId = id;
            this.contextMenu.targetType = type;
            this.contextMenu.show = true;
            // Force UI update immediately to prevent "slow" feeling
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.getContextTargetObject = function () {
            var id = this.contextMenu.targetId;
            switch (this.contextMenu.targetType) {
                case 'text': return this.textBoxes.find(function (t) { return t.id === id; });
                case 'shape': return this.shapeStamps.find(function (s) { return s.id === id; });
                case 'image': return this.imageStamps.find(function (i) { return i.id === id; });
                case 'signature': return this.signatureStamps.find(function (s) { return s.id === id; });
                case 'date': return this.dateStamps.find(function (d) { return d.id === id; });
            }
            return null;
        };
        PdfAnnotatorModalComponent.prototype.getAllAnnotationsZIndices = function () {
            var all = __spreadArray(__spreadArray(__spreadArray(__spreadArray(__spreadArray([], __read(this.textBoxes)), __read(this.shapeStamps)), __read(this.imageStamps)), __read(this.signatureStamps)), __read(this.dateStamps));
            return all.map(function (a) { return a.zIndex || 10; });
        };
        PdfAnnotatorModalComponent.prototype.contextBringToFront = function () {
            var obj = this.getContextTargetObject();
            if (obj) {
                var zs = this.getAllAnnotationsZIndices();
                var maxZ = zs.length ? Math.max.apply(Math, __spreadArray([], __read(zs))) : 10;
                obj.zIndex = maxZ + 1;
                this.closeContextMenu();
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.contextBringForward = function () {
            var obj = this.getContextTargetObject();
            if (obj) {
                obj.zIndex = (obj.zIndex || 10) + 1;
                this.closeContextMenu();
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.contextSendBackward = function () {
            var obj = this.getContextTargetObject();
            if (obj) {
                obj.zIndex = (obj.zIndex || 10) - 1;
                this.closeContextMenu();
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.contextSendToBack = function () {
            var obj = this.getContextTargetObject();
            if (obj) {
                var zs = this.getAllAnnotationsZIndices();
                var minZ = zs.length ? Math.min.apply(Math, __spreadArray([], __read(zs))) : 10;
                obj.zIndex = Math.max(1, minZ - 1);
                this.closeContextMenu();
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.deleteContextMenuTarget = function () {
            var id = this.contextMenu.targetId;
            switch (this.contextMenu.targetType) {
                case 'text':
                    this.removeTextBox(id);
                    break;
                case 'shape':
                    this.removeShapeStamp(id);
                    break;
                case 'image':
                    this.removeImage(id);
                    break;
                case 'signature':
                    this.removeSignature(id);
                    break;
                case 'date':
                    this.removeDateStamp(id);
                    break;
            }
            this.closeContextMenu();
        };
        /* ================= PDF load ================= */
        PdfAnnotatorModalComponent.prototype.loadPdfBytesAndInitPdfjs = function () {
            return __awaiter(this, void 0, void 0, function () {
                var buffer, loadingTask, _j, p, tmpDoc, _3, error_1, isTimeout, isNetwork, is404, msg, toast;
                var _this = this;
                return __generator(this, function (_k) {
                    switch (_k.label) {
                        case 0:
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังโหลด PDF...';
                            _k.label = 1;
                        case 1:
                            _k.trys.push([1, 9, 12, 13]);
                            return [4 /*yield*/, this.http
                                    .get(this.pdfUrl, { responseType: 'arraybuffer' })
                                    .pipe(operators.timeout(60000), operators.retry(2))
                                    .toPromise()];
                        case 2:
                            buffer = _k.sent();
                            if (!buffer) {
                                throw new Error('ไม่สามารถโหลดไฟล์ PDF ได้');
                            }
                            this.basePdfBytes = buffer;
                            loadingTask = pdfjsLib__namespace.getDocument({ data: buffer.slice(0) });
                            _j = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 3:
                            _j.pdfDocProxy = _k.sent();
                            this.pageCount = this.pdfDocProxy.numPages || 1;
                            // Initialize annotation data for ALL pages upfront
                            for (p = 1; p <= this.pageCount; p++)
                                this.ensurePage(p);
                            // Only render first chunk in the DOM
                            this.loadedUntilPage = Math.min(this.pagesPerChunk, this.pageCount);
                            this.pages = Array.from({ length: this.loadedUntilPage }, function (_, i) { return i + 1; });
                            _k.label = 4;
                        case 4:
                            _k.trys.push([4, 6, , 7]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(buffer)];
                        case 5:
                            tmpDoc = _k.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), width = _j.width, height = _j.height;
                                _this.pdfPageAspects.set(idx + 1, width / height);
                                // Store rotation so renderPage can force correct landscape/portrait viewport
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            return [3 /*break*/, 7];
                        case 6:
                            _3 = _k.sent();
                            return [3 /*break*/, 7];
                        case 7: 
                        // Generate thumbnails after loading PDF
                        return [4 /*yield*/, this.generateThumbnails()];
                        case 8:
                            // Generate thumbnails after loading PDF
                            _k.sent();
                            return [3 /*break*/, 13];
                        case 9:
                            error_1 = _k.sent();
                            console.error('Error loading PDF:', error_1);
                            isTimeout = (error_1 === null || error_1 === void 0 ? void 0 : error_1.name) === 'TimeoutError';
                            isNetwork = (error_1 === null || error_1 === void 0 ? void 0 : error_1.status) === 0;
                            is404 = (error_1 === null || error_1 === void 0 ? void 0 : error_1.status) === 404;
                            msg = 'ไม่สามารถโหลด PDF ได้ กรุณาลองใหม่อีกครั้ง';
                            if (isTimeout)
                                msg = 'โหลด PDF หมดเวลา (Timeout) กรุณาตรวจสอบการเชื่อมต่อ';
                            else if (isNetwork)
                                msg = 'ไม่สามารถเชื่อมต่อ Server ได้ กรุณาตรวจสอบเครือข่าย';
                            else if (is404)
                                msg = 'ไม่พบไฟล์ PDF บน Server กรุณาติดต่อผู้ดูแลระบบ';
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: msg,
                                    duration: 4000,
                                    color: 'danger',
                                    position: 'middle'
                                })];
                        case 10:
                            toast = _k.sent();
                            return [4 /*yield*/, toast.present()];
                        case 11:
                            _k.sent();
                            this.unlockOrientation();
                            this.loadError.emit({ message: msg });
                            this.dismissModal({ error: true, message: msg });
                            return [3 /*break*/, 13];
                        case 12:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            return [7 /*endfinally*/];
                        case 13: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.generateThumbnails = function () {
            return __awaiter(this, void 0, void 0, function () {
                var wasLoadingChunk;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.pdfDocProxy)
                                return [2 /*return*/];
                            wasLoadingChunk = this.isLoadingChunk;
                            this.isLoadingChunk = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, , 3, 4]);
                            this.pageThumbnails = [];
                            return [4 /*yield*/, this.generateThumbnailsRange(1, this.loadedUntilPage)];
                        case 2:
                            _j.sent();
                            return [3 /*break*/, 4];
                        case 3:
                            this.isLoadingChunk = wasLoadingChunk;
                            return [7 /*endfinally*/];
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.generateThumbnailsRange = function (from, to) {
            return __awaiter(this, void 0, void 0, function () {
                var scale, i, page, viewport, canvas, ctx;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.pdfDocProxy)
                                return [2 /*return*/];
                            scale = 0.2;
                            i = from;
                            _j.label = 1;
                        case 1:
                            if (!(i <= to)) return [3 /*break*/, 5];
                            return [4 /*yield*/, this.pdfDocProxy.getPage(i)];
                        case 2:
                            page = _j.sent();
                            viewport = page.getViewport({ scale: scale });
                            canvas = document.createElement('canvas');
                            ctx = canvas.getContext('2d');
                            canvas.width = viewport.width;
                            canvas.height = viewport.height;
                            return [4 /*yield*/, page.render({ canvasContext: ctx, viewport: viewport }).promise];
                        case 3:
                            _j.sent();
                            this.pageThumbnails.push(canvas.toDataURL('image/png'));
                            _j.label = 4;
                        case 4:
                            i++;
                            return [3 /*break*/, 1];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        /**
         * ปรับขอบเขตหน้าที่โหลด (loadedUntilPage) หลังจำนวนหน้าเปลี่ยน (แทรก/ลบ)
         * ขยับ window ตาม delta เพื่อให้หน้าที่แทรกใหม่อยู่ในช่วงที่แสดง และครอบคลุมหน้าปัจจุบันเสมอ
         * แต่ "จำกัดไม่ให้ขยายเกิน 1 chunk เหนือหน้าปัจจุบัน" — ไม่งั้นการแทรกไฟล์ใหญ่ (หลายสิบหน้า)
         * จะทำให้ renderAllPages เรนเดอร์ทุกหน้าพร้อมกันจนค้าง หน้าที่เหลือจะ lazy-load ตอนเลื่อน
         * แล้วสร้าง DOM ของหน้าใหม่ก่อน (detectChanges) เพื่อให้ renderAllPages หา canvas เจอ
         */
        PdfAnnotatorModalComponent.prototype.syncLoadedWindow = function (prevCount) {
            var _this = this;
            var delta = this.pageCount - prevCount;
            var next = this.loadedUntilPage + delta;
            next = Math.min(next, this.pageCount);
            next = Math.max(next, Math.min(this.pageNo, this.pageCount), 1);
            // เพดาน: หน้าปัจจุบัน + 1 chunk (เมื่อเลือก "ทั้งหมด" pagesPerChunk = pageCount จึงโหลดครบตามตั้งใจ)
            var cap = Math.min(this.pageCount, Math.max(this.pageNo, 1) + this.pagesPerChunk);
            next = Math.min(next, cap);
            this.loadedUntilPage = next;
            this.pages = Array.from({ length: this.loadedUntilPage }, function (_, i) { return i + 1; });
            this.pages.forEach(function (p) { return _this.ensurePage(p); });
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.setPagesPerChunk = function (n) {
            return __awaiter(this, void 0, void 0, function () {
                var newEnd, prevEnd, p, p;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.isLoadingChunk || !this.pdfDocProxy)
                                return [2 /*return*/];
                            this.pagesPerChunk = n === 0 ? this.pageCount : n;
                            this.isLoadingChunk = true;
                            newEnd = Math.min(this.pagesPerChunk, this.pageCount);
                            prevEnd = this.loadedUntilPage;
                            if (!(newEnd > prevEnd)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.generateThumbnailsRange(prevEnd + 1, newEnd)];
                        case 1:
                            _j.sent();
                            for (p = prevEnd + 1; p <= newEnd; p++)
                                this.pages.push(p);
                            return [3 /*break*/, 3];
                        case 2:
                            if (newEnd < prevEnd) {
                                this.pages = Array.from({ length: newEnd }, function (_, i) { return i + 1; });
                                this.renderedPages = new Set(__spreadArray([], __read(this.renderedPages)).filter(function (p) { return p <= newEnd; }));
                            }
                            _j.label = 3;
                        case 3:
                            this.loadedUntilPage = newEnd;
                            this.isLoadingChunk = false;
                            this.saveSettings();
                            this.cdr.detectChanges();
                            p = Math.max(prevEnd + 1, 1);
                            _j.label = 4;
                        case 4:
                            if (!(p <= newEnd)) return [3 /*break*/, 7];
                            return [4 /*yield*/, this.renderPage(p)];
                        case 5:
                            _j.sent();
                            _j.label = 6;
                        case 6:
                            p++;
                            return [3 /*break*/, 4];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.loadNextChunk = function () {
            return __awaiter(this, void 0, void 0, function () {
                var newEnd, prevEnd, p, p;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            // หยุดโหลด chunk ระหว่างมี page operation ค้างอยู่ (แทรก/ลบ/ย้อนกลับ/สลับหน้า) — กัน race กับ rebuild thumbnail
                            if (this.isLoadingChunk || this.isLoading || this.loadedUntilPage >= this.pageCount)
                                return [2 /*return*/];
                            this.isLoadingChunk = true;
                            newEnd = Math.min(this.loadedUntilPage + this.pagesPerChunk, this.pageCount);
                            prevEnd = this.loadedUntilPage;
                            return [4 /*yield*/, this.generateThumbnailsRange(prevEnd + 1, newEnd)];
                        case 1:
                            _j.sent();
                            for (p = prevEnd + 1; p <= newEnd; p++)
                                this.pages.push(p);
                            this.loadedUntilPage = newEnd;
                            this.cdr.detectChanges();
                            return [4 /*yield*/, new Promise(function (r) { return setTimeout(r, 50); })];
                        case 2:
                            _j.sent();
                            p = prevEnd + 1;
                            _j.label = 3;
                        case 3:
                            if (!(p <= newEnd)) return [3 /*break*/, 6];
                            return [4 /*yield*/, this.renderPage(p)];
                        case 4:
                            _j.sent();
                            _j.label = 5;
                        case 5:
                            p++;
                            return [3 /*break*/, 3];
                        case 6:
                            this.isLoadingChunk = false;
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.goToPage = function (pageNum) {
            if (pageNum < 1 || pageNum > this.pageCount)
                return;
            this.pageNo = pageNum;
            this.scrollToPage(this.pageNo);
            // Re-fit width in case new page has different orientation (landscape vs portrait)
            this.fitWidth();
        };
        PdfAnnotatorModalComponent.prototype.toggleThumbnails = function () {
            this.showThumbnails = !this.showThumbnails;
            this.cdr.detectChanges();
        };
        /* ================= Insert Blank Page ================= */
        PdfAnnotatorModalComponent.prototype.insertBlankPage = function (where) {
            return __awaiter(this, void 0, void 0, function () {
                var pdfDoc, pages, refPage, _j, width, height, pageW, pageH, insertIndex, newBytes, shiftPage_1, shiftAnnotations, shiftRecord, copy, loadingTask, _k, prevCount, tmpDoc, _4, toast, err_2, toast;
                var _this = this;
                return __generator(this, function (_l) {
                    switch (_l.label) {
                        case 0:
                            if (!this.basePdfBytes)
                                return [2 /*return*/];
                            this.showInsertMenu = false;
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังแทรกหน้าเปล่า...';
                            this.savePageSnapshot(); // บันทึก snapshot ก่อนแก้ไข
                            this.cdr.detectChanges();
                            _l.label = 1;
                        case 1:
                            _l.trys.push([1, 13, 16, 17]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 2:
                            pdfDoc = _l.sent();
                            pages = pdfDoc.getPages();
                            refPage = pages[this.pageNo - 1];
                            _j = refPage.getSize(), width = _j.width, height = _j.height;
                            pageW = void 0;
                            pageH = void 0;
                            if (this.insertOrientation === 'landscape') {
                                pageW = Math.max(width, height);
                                pageH = Math.min(width, height);
                            }
                            else {
                                pageW = Math.min(width, height);
                                pageH = Math.max(width, height);
                            }
                            insertIndex = where === 'before' ? this.pageNo - 1 : this.pageNo;
                            pdfDoc.insertPage(insertIndex, [pageW, pageH]);
                            return [4 /*yield*/, pdfDoc.save()];
                        case 3:
                            newBytes = _l.sent();
                            this.basePdfBytes = newBytes.buffer;
                            shiftPage_1 = insertIndex + 1;
                            shiftAnnotations = function (arr) { return arr.map(function (a) { return a.page >= shiftPage_1 ? Object.assign(Object.assign({}, a), { page: a.page + 1 }) : a; }); };
                            this.textBoxes = shiftAnnotations(this.textBoxes);
                            this.imageStamps = shiftAnnotations(this.imageStamps);
                            this.shapeStamps = shiftAnnotations(this.shapeStamps);
                            this.signatureStamps = shiftAnnotations(this.signatureStamps);
                            this.dateStamps = shiftAnnotations(this.dateStamps);
                            this.pdfFormFields = shiftAnnotations(this.pdfFormFields);
                            shiftRecord = function (rec) {
                                var e_8, _j;
                                var next = {};
                                try {
                                    for (var _k = __values(Object.keys(rec)), _l = _k.next(); !_l.done; _l = _k.next()) {
                                        var key = _l.value;
                                        var p = Number(key);
                                        next[p >= shiftPage_1 ? p + 1 : p] = rec[p];
                                    }
                                }
                                catch (e_8_1) { e_8 = { error: e_8_1 }; }
                                finally {
                                    try {
                                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                                    }
                                    finally { if (e_8) throw e_8.error; }
                                }
                                return next;
                            };
                            this.strokes = shiftRecord(this.strokes);
                            this.shapes = shiftRecord(this.shapes);
                            this.redoStack = shiftRecord(this.redoStack);
                            copy = this.basePdfBytes.slice(0);
                            if (this.pdfDocProxy) {
                                this.pdfDocProxy.destroy();
                                this.pdfDocProxy = null;
                            }
                            loadingTask = pdfjsLib__namespace.getDocument({ data: copy.slice(0) });
                            _k = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 4:
                            _k.pdfDocProxy = _l.sent();
                            prevCount = this.pageCount;
                            this.pageCount = this.pdfDocProxy.numPages;
                            this.syncLoadedWindow(prevCount);
                            // Refresh aspect ratios & rotations
                            this.pdfPageAspects.clear();
                            this.pdfPageRotations.clear();
                            _l.label = 5;
                        case 5:
                            _l.trys.push([5, 7, , 8]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(copy)];
                        case 6:
                            tmpDoc = _l.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), w = _j.width, h = _j.height;
                                _this.pdfPageAspects.set(idx + 1, w / h);
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            return [3 /*break*/, 8];
                        case 7:
                            _4 = _l.sent();
                            return [3 /*break*/, 8];
                        case 8:
                            // Navigate to the new blank page
                            this.pageNo = insertIndex + 1;
                            this.renderedPages.clear();
                            this.renderingPages.clear();
                            return [4 /*yield*/, this.generateThumbnails()];
                        case 9:
                            _l.sent();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 10:
                            _l.sent();
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: "\u0E41\u0E17\u0E23\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E48\u0E32" + (this.insertOrientation === 'portrait' ? 'แนวตั้ง' : 'แนวนอน') + "\u0E17\u0E35\u0E48\u0E2B\u0E19\u0E49\u0E32 " + this.pageNo + " \u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22\u0E41\u0E25\u0E49\u0E27",
                                    duration: 2000,
                                    color: 'success',
                                    position: 'bottom'
                                })];
                        case 11:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 12:
                            _l.sent();
                            // Log to history
                            this.logHistory('page_insert', { where: where, orientation: this.insertOrientation, insertedAt: this.pageNo }, this.pageNo);
                            return [3 /*break*/, 17];
                        case 13:
                            err_2 = _l.sent();
                            console.error('insertBlankPage error:', err_2);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: 'เกิดข้อผิดพลาดในการแทรกหน้า',
                                    duration: 2000,
                                    color: 'danger',
                                    position: 'bottom'
                                })];
                        case 14:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 15:
                            _l.sent();
                            return [3 /*break*/, 17];
                        case 16:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 17: return [2 /*return*/];
                    }
                });
            });
        };
        /* ================= Delete Current Page ================= */
        PdfAnnotatorModalComponent.prototype.deletePage = function () {
            return __awaiter(this, void 0, void 0, function () {
                var alert;
                var _this = this;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.basePdfBytes || this.pageCount <= 1)
                                return [2 /*return*/];
                            this.showInsertMenu = false;
                            return [4 /*yield*/, this.alertCtrl.create({
                                    header: 'ลบหน้าเอกสาร',
                                    message: "\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48 " + this.pageNo + " \u0E43\u0E0A\u0E48\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48? \u0E01\u0E32\u0E23\u0E01\u0E23\u0E30\u0E17\u0E33\u0E19\u0E35\u0E49\u0E44\u0E21\u0E48\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E40\u0E23\u0E35\u0E22\u0E01\u0E04\u0E37\u0E19\u0E44\u0E14\u0E49",
                                    buttons: [
                                        { text: 'ยกเลิก', role: 'cancel' },
                                        {
                                            text: 'ลบหน้า',
                                            role: 'destructive',
                                            cssClass: 'alert-btn-danger',
                                            handler: function () { return _this.doDeletePage(); }
                                        }
                                    ]
                                })];
                        case 1:
                            alert = _j.sent();
                            return [4 /*yield*/, alert.present()];
                        case 2:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.doDeletePage = function () {
            return __awaiter(this, void 0, void 0, function () {
                var pdfDoc, deleteIndex, newBytes, deletedPage_1, filterAndShift, shiftDeleteRecord, copy, loadingTask, _j, prevCount, tmpDoc, _5, toast, err_3, toast;
                var _this = this;
                return __generator(this, function (_k) {
                    switch (_k.label) {
                        case 0:
                            if (!this.basePdfBytes)
                                return [2 /*return*/];
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังลบหน้า...';
                            this.savePageSnapshot(); // บันทึก snapshot ก่อนลบ
                            this.cdr.detectChanges();
                            _k.label = 1;
                        case 1:
                            _k.trys.push([1, 13, 16, 17]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 2:
                            pdfDoc = _k.sent();
                            deleteIndex = this.pageNo - 1;
                            pdfDoc.removePage(deleteIndex);
                            return [4 /*yield*/, pdfDoc.save()];
                        case 3:
                            newBytes = _k.sent();
                            this.basePdfBytes = newBytes.buffer;
                            deletedPage_1 = this.pageNo;
                            filterAndShift = function (arr) { return arr
                                .filter(function (a) { return a.page !== deletedPage_1; })
                                .map(function (a) { return a.page > deletedPage_1 ? Object.assign(Object.assign({}, a), { page: a.page - 1 }) : a; }); };
                            this.textBoxes = filterAndShift(this.textBoxes);
                            this.imageStamps = filterAndShift(this.imageStamps);
                            this.shapeStamps = filterAndShift(this.shapeStamps);
                            this.signatureStamps = filterAndShift(this.signatureStamps);
                            this.dateStamps = filterAndShift(this.dateStamps);
                            this.pdfFormFields = filterAndShift(this.pdfFormFields);
                            shiftDeleteRecord = function (rec) {
                                var e_9, _j;
                                var next = {};
                                try {
                                    for (var _k = __values(Object.keys(rec)), _l = _k.next(); !_l.done; _l = _k.next()) {
                                        var key = _l.value;
                                        var p = Number(key);
                                        if (p === deletedPage_1)
                                            continue; // drop deleted page
                                        next[p > deletedPage_1 ? p - 1 : p] = rec[p];
                                    }
                                }
                                catch (e_9_1) { e_9 = { error: e_9_1 }; }
                                finally {
                                    try {
                                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                                    }
                                    finally { if (e_9) throw e_9.error; }
                                }
                                return next;
                            };
                            this.strokes = shiftDeleteRecord(this.strokes);
                            this.shapes = shiftDeleteRecord(this.shapes);
                            this.redoStack = shiftDeleteRecord(this.redoStack);
                            copy = this.basePdfBytes.slice(0);
                            if (this.pdfDocProxy) {
                                this.pdfDocProxy.destroy();
                                this.pdfDocProxy = null;
                            }
                            loadingTask = pdfjsLib__namespace.getDocument({ data: copy.slice(0) });
                            _j = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 4:
                            _j.pdfDocProxy = _k.sent();
                            prevCount = this.pageCount;
                            this.pageCount = this.pdfDocProxy.numPages;
                            this.syncLoadedWindow(prevCount);
                            // Refresh aspect ratios & rotations
                            this.pdfPageAspects.clear();
                            this.pdfPageRotations.clear();
                            _k.label = 5;
                        case 5:
                            _k.trys.push([5, 7, , 8]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(copy)];
                        case 6:
                            tmpDoc = _k.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), width = _j.width, height = _j.height;
                                _this.pdfPageAspects.set(idx + 1, width / height);
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            return [3 /*break*/, 8];
                        case 7:
                            _5 = _k.sent();
                            return [3 /*break*/, 8];
                        case 8:
                            // Navigate to the previous page (or page 1 if we deleted page 1)
                            this.pageNo = Math.min(deletedPage_1, this.pageCount);
                            this.renderedPages.clear();
                            this.renderingPages.clear();
                            return [4 /*yield*/, this.generateThumbnails()];
                        case 9:
                            _k.sent();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 10:
                            _k.sent();
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: "\u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48 " + deletedPage_1 + " \u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22\u0E41\u0E25\u0E49\u0E27",
                                    duration: 2000,
                                    color: 'success',
                                    position: 'bottom'
                                })];
                        case 11:
                            toast = _k.sent();
                            return [4 /*yield*/, toast.present()];
                        case 12:
                            _k.sent();
                            return [3 /*break*/, 17];
                        case 13:
                            err_3 = _k.sent();
                            console.error('deletePage error:', err_3);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: 'เกิดข้อผิดพลาดในการลบหน้า',
                                    duration: 2000,
                                    color: 'danger',
                                    position: 'bottom'
                                })];
                        case 14:
                            toast = _k.sent();
                            return [4 /*yield*/, toast.present()];
                        case 15:
                            _k.sent();
                            return [3 /*break*/, 17];
                        case 16:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 17: return [2 /*return*/];
                    }
                });
            });
        };
        /* ================= Thumbnail Sidebar Wrappers ================= */
        PdfAnnotatorModalComponent.prototype.toggleThumbInsert = function (idx, event) {
            if (this.thumbInsertIndex === idx) {
                this.thumbInsertIndex = -1;
                this.cdr.detectChanges();
                return;
            }
            this.thumbInsertIndex = idx;
            if (event && event.currentTarget) {
                var btn = event.currentTarget;
                var rect = btn.getBoundingClientRect();
                // Center the dropdown vertically on the button
                this.thumbDropdownTop = rect.top + rect.height / 2;
            }
            this.cdr.detectChanges();
        };
        /** Insert a blank page at `afterIndex` (0 = before page 1, n = after page n) */
        PdfAnnotatorModalComponent.prototype.insertAtThumb = function (afterIndex, orientation) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            this.thumbInsertIndex = -1;
                            if (!this.basePdfBytes)
                                return [2 /*return*/];
                            // Navigate to the page around which we are inserting so insertBlankPage works correctly
                            this.insertOrientation = orientation;
                            if (!(afterIndex === 0)) return [3 /*break*/, 2];
                            this.pageNo = 1;
                            return [4 /*yield*/, this.insertBlankPage('before')];
                        case 1:
                            _j.sent();
                            return [3 /*break*/, 4];
                        case 2:
                            this.pageNo = afterIndex;
                            return [4 /*yield*/, this.insertBlankPage('after')];
                        case 3:
                            _j.sent();
                            _j.label = 4;
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.triggerThumbFileUpload = function (afterIndex) {
            this.thumbInsertIndex = -1;
            this.thumbInsertAtIndex = afterIndex;
            this.cdr.detectChanges();
            if (this.thumbFileInputRef) {
                this.thumbFileInputRef.nativeElement.value = '';
                this.thumbFileInputRef.nativeElement.click();
            }
        };
        PdfAnnotatorModalComponent.prototype.onThumbFileSelected = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var input, file, reader, arrayBuffer, importedPdf, mainPdf, importedPages, insertIndex, currentIndex, importedPages_1, importedPages_1_1, page, newBytes, insertedCount_1, shiftPage_2, shiftAnnotations, shiftRecord, copy, loadingTask, _j, prevCount, tmpDoc, _6, toast, err_4, toast, toast;
                var e_10, _k;
                var _this = this;
                return __generator(this, function (_l) {
                    switch (_l.label) {
                        case 0:
                            input = event.target;
                            if (!input.files || !input.files[0] || !this.basePdfBytes)
                                return [2 /*return*/];
                            file = input.files[0];
                            // Navigate to the correct insert position then trigger image upload
                            if (this.thumbInsertAtIndex === 0) {
                                this.pageNo = 1;
                            }
                            else {
                                this.pageNo = this.thumbInsertAtIndex;
                            }
                            if (!file.type.startsWith('image/')) return [3 /*break*/, 1];
                            reader = new FileReader();
                            reader.onload = function (e) { return __awaiter(_this, void 0, void 0, function () {
                                var dataUrl, newPage, stamp;
                                return __generator(this, function (_j) {
                                    switch (_j.label) {
                                        case 0:
                                            dataUrl = e.target.result;
                                            if (!(this.thumbInsertAtIndex === 0)) return [3 /*break*/, 2];
                                            return [4 /*yield*/, this.insertBlankPage('before')];
                                        case 1:
                                            _j.sent();
                                            return [3 /*break*/, 4];
                                        case 2: return [4 /*yield*/, this.insertBlankPage('after')];
                                        case 3:
                                            _j.sent();
                                            _j.label = 4;
                                        case 4:
                                            newPage = this.thumbInsertAtIndex === 0 ? 1 : this.thumbInsertAtIndex + 1;
                                            stamp = {
                                                id: 'img_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                                                page: newPage, x: 0, y: 0, width: 100, height: 100,
                                                dataUrl: dataUrl
                                            };
                                            this.imageStamps.push(stamp);
                                            this.cdr.detectChanges();
                                            return [2 /*return*/];
                                    }
                                });
                            }); };
                            reader.readAsDataURL(file);
                            return [3 /*break*/, 25];
                        case 1:
                            if (!(file.type === 'application/pdf')) return [3 /*break*/, 22];
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังแทรกไฟล์ PDF...';
                            this.savePageSnapshot();
                            this.cdr.detectChanges();
                            _l.label = 2;
                        case 2:
                            _l.trys.push([2, 17, 20, 21]);
                            return [4 /*yield*/, file.arrayBuffer()];
                        case 3:
                            arrayBuffer = _l.sent();
                            return [4 /*yield*/, pdfLib.PDFDocument.load(arrayBuffer)];
                        case 4:
                            importedPdf = _l.sent();
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 5:
                            mainPdf = _l.sent();
                            return [4 /*yield*/, mainPdf.copyPages(importedPdf, importedPdf.getPageIndices())];
                        case 6:
                            importedPages = _l.sent();
                            insertIndex = this.thumbInsertAtIndex;
                            currentIndex = insertIndex;
                            try {
                                for (importedPages_1 = __values(importedPages), importedPages_1_1 = importedPages_1.next(); !importedPages_1_1.done; importedPages_1_1 = importedPages_1.next()) {
                                    page = importedPages_1_1.value;
                                    mainPdf.insertPage(currentIndex, page);
                                    currentIndex++;
                                }
                            }
                            catch (e_10_1) { e_10 = { error: e_10_1 }; }
                            finally {
                                try {
                                    if (importedPages_1_1 && !importedPages_1_1.done && (_k = importedPages_1.return)) _k.call(importedPages_1);
                                }
                                finally { if (e_10) throw e_10.error; }
                            }
                            return [4 /*yield*/, mainPdf.save()];
                        case 7:
                            newBytes = _l.sent();
                            this.basePdfBytes = newBytes.buffer;
                            insertedCount_1 = importedPages.length;
                            shiftPage_2 = insertIndex + 1;
                            shiftAnnotations = function (arr) { return arr.map(function (a) { return a.page >= shiftPage_2 ? Object.assign(Object.assign({}, a), { page: a.page + insertedCount_1 }) : a; }); };
                            this.textBoxes = shiftAnnotations(this.textBoxes);
                            this.imageStamps = shiftAnnotations(this.imageStamps);
                            this.shapeStamps = shiftAnnotations(this.shapeStamps);
                            this.signatureStamps = shiftAnnotations(this.signatureStamps);
                            this.dateStamps = shiftAnnotations(this.dateStamps);
                            this.pdfFormFields = shiftAnnotations(this.pdfFormFields);
                            shiftRecord = function (rec) {
                                var e_11, _j;
                                var next = {};
                                try {
                                    for (var _k = __values(Object.keys(rec)), _l = _k.next(); !_l.done; _l = _k.next()) {
                                        var key = _l.value;
                                        var p = Number(key);
                                        next[p >= shiftPage_2 ? p + insertedCount_1 : p] = rec[p];
                                    }
                                }
                                catch (e_11_1) { e_11 = { error: e_11_1 }; }
                                finally {
                                    try {
                                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                                    }
                                    finally { if (e_11) throw e_11.error; }
                                }
                                return next;
                            };
                            this.strokes = shiftRecord(this.strokes);
                            this.shapes = shiftRecord(this.shapes);
                            this.redoStack = shiftRecord(this.redoStack);
                            copy = this.basePdfBytes.slice(0);
                            if (this.pdfDocProxy) {
                                this.pdfDocProxy.destroy();
                                this.pdfDocProxy = null;
                            }
                            loadingTask = pdfjsLib__namespace.getDocument({ data: copy.slice(0) });
                            _j = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 8:
                            _j.pdfDocProxy = _l.sent();
                            prevCount = this.pageCount;
                            this.pageCount = this.pdfDocProxy.numPages;
                            this.syncLoadedWindow(prevCount);
                            this.pdfPageAspects.clear();
                            this.pdfPageRotations.clear();
                            _l.label = 9;
                        case 9:
                            _l.trys.push([9, 11, , 12]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(copy)];
                        case 10:
                            tmpDoc = _l.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), w = _j.width, h = _j.height;
                                _this.pdfPageAspects.set(idx + 1, w / h);
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            return [3 /*break*/, 12];
                        case 11:
                            _6 = _l.sent();
                            return [3 /*break*/, 12];
                        case 12:
                            this.pageNo = shiftPage_2;
                            this.renderedPages.clear();
                            this.renderingPages.clear();
                            return [4 /*yield*/, this.generateThumbnails()];
                        case 13:
                            _l.sent();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 14:
                            _l.sent();
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: "\u0E41\u0E17\u0E23\u0E01\u0E44\u0E1F\u0E25\u0E4C PDF \u0E08\u0E33\u0E19\u0E27\u0E19 " + insertedCount_1 + " \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E23\u0E35\u0E22\u0E1A\u0E23\u0E49\u0E2D\u0E22\u0E41\u0E25\u0E49\u0E27",
                                    duration: 2000,
                                    color: 'success',
                                    position: 'bottom'
                                })];
                        case 15:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 16:
                            _l.sent();
                            this.logHistory('page_insert', { where: 'pdf_file', insertedAt: shiftPage_2, count: insertedCount_1 }, shiftPage_2);
                            return [3 /*break*/, 21];
                        case 17:
                            err_4 = _l.sent();
                            console.error('insert PDF error:', err_4);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: 'เกิดข้อผิดพลาดในการแทรกไฟล์ PDF',
                                    duration: 2000,
                                    color: 'danger',
                                    position: 'bottom'
                                })];
                        case 18:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 19:
                            _l.sent();
                            return [3 /*break*/, 21];
                        case 20:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            if (this.thumbFileInputRef) {
                                this.thumbFileInputRef.nativeElement.value = '';
                            }
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 21: return [3 /*break*/, 25];
                        case 22: return [4 /*yield*/, this.toastCtrl.create({
                                message: 'รองรับเฉพาะไฟล์รูปภาพและเอกสาร PDF ในขณะนี้',
                                duration: 2500, color: 'warning', position: 'bottom'
                            })];
                        case 23:
                            toast = _l.sent();
                            return [4 /*yield*/, toast.present()];
                        case 24:
                            _l.sent();
                            _l.label = 25;
                        case 25: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.onThumbDragStart = function (i) {
            this.thumbDragFromIndex = i;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.onThumbDragOver = function (i) {
            if (this.thumbDragFromIndex === null || i === this.thumbDragFromIndex)
                return;
            this.thumbDragOverIndex = i;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.onThumbDragLeave = function () {
            this.thumbDragOverIndex = null;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.onThumbDrop = function (i) {
            return __awaiter(this, void 0, void 0, function () {
                var from;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            from = this.thumbDragFromIndex;
                            this.thumbDragFromIndex = null;
                            this.thumbDragOverIndex = null;
                            if (from === null || from === i) {
                                this.cdr.detectChanges();
                                return [2 /*return*/];
                            }
                            return [4 /*yield*/, this.reorderPage(from + 1, i + 1)];
                        case 1:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.onThumbDragEnd = function () {
            this.thumbDragFromIndex = null;
            this.thumbDragOverIndex = null;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.reorderPage = function (fromPage, toPage) {
            return __awaiter(this, void 0, void 0, function () {
                var pdfDoc, fromIdx, toIdx, _j, copiedPage, insertAt, newBytes, shiftAnnot, shiftRecord, copy, loadingTask, _k, prevCount, tmpDoc, err_5;
                var _this = this;
                return __generator(this, function (_l) {
                    switch (_l.label) {
                        case 0:
                            if (!this.basePdfBytes || fromPage === toPage)
                                return [2 /*return*/];
                            this.savePageSnapshot();
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังย้ายหน้า...';
                            this.cdr.detectChanges();
                            _l.label = 1;
                        case 1:
                            _l.trys.push([1, 8, 9, 11]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 2:
                            pdfDoc = _l.sent();
                            fromIdx = fromPage - 1;
                            toIdx = toPage - 1;
                            return [4 /*yield*/, pdfDoc.copyPages(pdfDoc, [fromIdx])];
                        case 3:
                            _j = __read.apply(void 0, [_l.sent(), 1]), copiedPage = _j[0];
                            pdfDoc.removePage(fromIdx);
                            insertAt = fromIdx < toIdx ? toIdx : toIdx;
                            pdfDoc.insertPage(insertAt, copiedPage);
                            return [4 /*yield*/, pdfDoc.save()];
                        case 4:
                            newBytes = _l.sent();
                            this.basePdfBytes = newBytes.buffer;
                            shiftAnnot = function (arr) { return arr.map(function (a) {
                                if (a.page === fromPage)
                                    return Object.assign(Object.assign({}, a), { page: toPage });
                                if (fromPage < toPage && a.page > fromPage && a.page <= toPage)
                                    return Object.assign(Object.assign({}, a), { page: a.page - 1 });
                                if (fromPage > toPage && a.page >= toPage && a.page < fromPage)
                                    return Object.assign(Object.assign({}, a), { page: a.page + 1 });
                                return a;
                            }); };
                            this.textBoxes = shiftAnnot(this.textBoxes);
                            this.imageStamps = shiftAnnot(this.imageStamps);
                            this.shapeStamps = shiftAnnot(this.shapeStamps);
                            this.signatureStamps = shiftAnnot(this.signatureStamps);
                            this.dateStamps = shiftAnnot(this.dateStamps);
                            this.pdfFormFields = shiftAnnot(this.pdfFormFields);
                            shiftRecord = function (rec) {
                                var e_12, _j;
                                var next = {};
                                try {
                                    for (var _k = __values(Object.keys(rec)), _l = _k.next(); !_l.done; _l = _k.next()) {
                                        var k = _l.value;
                                        var p = Number(k);
                                        if (p === fromPage)
                                            next[toPage] = rec[p];
                                        else if (fromPage < toPage && p > fromPage && p <= toPage)
                                            next[p - 1] = rec[p];
                                        else if (fromPage > toPage && p >= toPage && p < fromPage)
                                            next[p + 1] = rec[p];
                                        else
                                            next[p] = rec[p];
                                    }
                                }
                                catch (e_12_1) { e_12 = { error: e_12_1 }; }
                                finally {
                                    try {
                                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                                    }
                                    finally { if (e_12) throw e_12.error; }
                                }
                                return next;
                            };
                            this.strokes = shiftRecord(this.strokes);
                            this.shapes = shiftRecord(this.shapes);
                            this.redoStack = shiftRecord(this.redoStack);
                            copy = this.basePdfBytes.slice(0);
                            if (this.pdfDocProxy) {
                                this.pdfDocProxy.destroy();
                                this.pdfDocProxy = null;
                            }
                            loadingTask = pdfjsLib__namespace.getDocument({ data: copy.slice(0) });
                            _k = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 5:
                            _k.pdfDocProxy = _l.sent();
                            prevCount = this.pageCount;
                            this.pageCount = this.pdfDocProxy.numPages;
                            this.syncLoadedWindow(prevCount);
                            this.pdfPageAspects.clear();
                            this.pdfPageRotations.clear();
                            return [4 /*yield*/, pdfLib.PDFDocument.load(copy)];
                        case 6:
                            tmpDoc = _l.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), width = _j.width, height = _j.height;
                                _this.pdfPageAspects.set(idx + 1, width / height);
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            this.renderedPages.clear();
                            this.pageThumbnails = [];
                            return [4 /*yield*/, this.generateThumbnailsRange(1, this.loadedUntilPage)];
                        case 7:
                            _l.sent();
                            this.pageNo = toPage;
                            this.scrollToPage(this.pageNo);
                            return [3 /*break*/, 11];
                        case 8:
                            err_5 = _l.sent();
                            console.error('reorderPage error', err_5);
                            return [3 /*break*/, 11];
                        case 9:
                            this.isLoading = false;
                            this.cdr.detectChanges();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 10:
                            _l.sent();
                            return [7 /*endfinally*/];
                        case 11: return [2 /*return*/];
                    }
                });
            });
        };
        /** ถาม dialog หน้าปลายทาง แล้วย้ายหน้า fromPage ไปยังตำแหน่งใหม่ */
        PdfAnnotatorModalComponent.prototype.promptMovePage = function (fromPage) {
            return __awaiter(this, void 0, void 0, function () {
                var alert;
                var _this = this;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.basePdfBytes || this.pageCount <= 1)
                                return [2 /*return*/];
                            return [4 /*yield*/, this.alertCtrl.create({
                                    header: "\u0E22\u0E49\u0E32\u0E22\u0E2B\u0E19\u0E49\u0E32 " + fromPage,
                                    message: "\u0E23\u0E30\u0E1A\u0E38\u0E2B\u0E19\u0E49\u0E32\u0E1B\u0E25\u0E32\u0E22\u0E17\u0E32\u0E07 (1 - " + this.pageCount + ")",
                                    inputs: [{ name: 'target', type: 'number', min: 1, max: this.pageCount, value: fromPage }],
                                    buttons: [
                                        { text: 'ยกเลิก', role: 'cancel' },
                                        {
                                            text: 'ย้าย',
                                            handler: function (data) {
                                                var to = parseInt(data === null || data === void 0 ? void 0 : data.target, 10);
                                                if (isNaN(to) || to < 1 || to > _this.pageCount) {
                                                    _this.toastCtrl.create({ message: "\u0E01\u0E23\u0E38\u0E13\u0E32\u0E23\u0E30\u0E1A\u0E38\u0E2B\u0E19\u0E49\u0E32\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07 1 - " + _this.pageCount, duration: 2000, color: 'danger' })
                                                        .then(function (t) { return t.present(); });
                                                    return false; // คงหน้าต่างไว้ให้แก้ใหม่
                                                }
                                                if (to !== fromPage)
                                                    _this.moveToPage(fromPage, to);
                                                return true;
                                            },
                                        },
                                    ],
                                })];
                        case 1:
                            alert = _j.sent();
                            return [4 /*yield*/, alert.present()];
                        case 2:
                            _j.sent();
                            this.cdr.detectChanges();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.moveToPage = function (fromPage, toPage) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0: return [4 /*yield*/, this.reorderPage(fromPage, toPage)];
                        case 1:
                            _j.sent();
                            this.pageNo = toPage;
                            this.scrollToPage(toPage);
                            this.cdr.detectChanges();
                            return [2 /*return*/];
                    }
                });
            });
        };
        // ──────────────────────────────────────────────────────────────────
        PdfAnnotatorModalComponent.prototype.movePageToIndex = function (pageNum, direction) {
            return __awaiter(this, void 0, void 0, function () {
                var prevPageNo;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!(direction === 'up' && pageNum > 1)) return [3 /*break*/, 2];
                            prevPageNo = this.pageNo;
                            this.pageNo = pageNum;
                            return [4 /*yield*/, this.swapPages(pageNum - 1, pageNum)];
                        case 1:
                            _j.sent();
                            this.pageNo = pageNum - 1;
                            this.scrollToPage(this.pageNo);
                            return [3 /*break*/, 4];
                        case 2:
                            if (!(direction === 'down' && pageNum < this.pageCount)) return [3 /*break*/, 4];
                            this.pageNo = pageNum;
                            return [4 /*yield*/, this.swapPages(pageNum, pageNum + 1)];
                        case 3:
                            _j.sent();
                            this.pageNo = pageNum + 1;
                            this.scrollToPage(this.pageNo);
                            _j.label = 4;
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.deleteSpecificPage = function (pageNum) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageCount <= 1)
                                return [2 /*return*/];
                            this.pageNo = pageNum;
                            return [4 /*yield*/, this.deletePage()];
                        case 1:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.insertBlankPageFromThumb = function (where) {
            this.showThumbInsertMenu = false;
            this.insertBlankPage(where);
        };
        PdfAnnotatorModalComponent.prototype.deletePageFromThumb = function () {
            this.deletePage();
        };
        /* ================= Move Page Up/Down ================= */
        PdfAnnotatorModalComponent.prototype.movePageUp = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageNo <= 1 || !this.basePdfBytes)
                                return [2 /*return*/];
                            return [4 /*yield*/, this.swapPages(this.pageNo - 1, this.pageNo)];
                        case 1:
                            _j.sent();
                            this.pageNo = this.pageNo - 1;
                            this.scrollToPage(this.pageNo);
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.movePageDown = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageNo >= this.pageCount || !this.basePdfBytes)
                                return [2 /*return*/];
                            return [4 /*yield*/, this.swapPages(this.pageNo, this.pageNo + 1)];
                        case 1:
                            _j.sent();
                            this.pageNo = this.pageNo + 1;
                            this.scrollToPage(this.pageNo);
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.swapPages = function (pageA, pageB) {
            return __awaiter(this, void 0, void 0, function () {
                var pdfDoc, idxA, idxB, _j, copyOfB, _k, copyOfA, newBytes, swapAnnot, swapRecord, copy, loadingTask, _l, prevCount, tmpDoc, _7, err_6, toast;
                var _this = this;
                return __generator(this, function (_m) {
                    switch (_m.label) {
                        case 0:
                            if (!this.basePdfBytes)
                                return [2 /*return*/];
                            this.savePageSnapshot();
                            this.isLoading = true;
                            this.loadingMessage = 'กำลังย้ายหน้า...';
                            this.cdr.detectChanges();
                            _m.label = 1;
                        case 1:
                            _m.trys.push([1, 13, 16, 17]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 2:
                            pdfDoc = _m.sent();
                            idxA = pageA - 1;
                            idxB = pageB - 1;
                            return [4 /*yield*/, pdfDoc.copyPages(pdfDoc, [idxB])];
                        case 3:
                            _j = __read.apply(void 0, [_m.sent(), 1]), copyOfB = _j[0];
                            return [4 /*yield*/, pdfDoc.copyPages(pdfDoc, [idxA])];
                        case 4:
                            _k = __read.apply(void 0, [_m.sent(), 1]), copyOfA = _k[0];
                            // Insert B at position A, then A at position B+1 (now shifted by 1)
                            pdfDoc.insertPage(idxA, copyOfB);
                            pdfDoc.insertPage(idxB + 1, copyOfA);
                            // Remove the original A (now at idxA+1) and original B (now at idxB+2)
                            pdfDoc.removePage(idxA + 1);
                            pdfDoc.removePage(idxB + 1);
                            return [4 /*yield*/, pdfDoc.save()];
                        case 5:
                            newBytes = _m.sent();
                            this.basePdfBytes = newBytes.buffer;
                            swapAnnot = function (arr) { return arr.map(function (a) {
                                if (a.page === pageA)
                                    return Object.assign(Object.assign({}, a), { page: pageB });
                                if (a.page === pageB)
                                    return Object.assign(Object.assign({}, a), { page: pageA });
                                return a;
                            }); };
                            this.textBoxes = swapAnnot(this.textBoxes);
                            this.imageStamps = swapAnnot(this.imageStamps);
                            this.shapeStamps = swapAnnot(this.shapeStamps);
                            this.signatureStamps = swapAnnot(this.signatureStamps);
                            this.dateStamps = swapAnnot(this.dateStamps);
                            this.pdfFormFields = swapAnnot(this.pdfFormFields);
                            swapRecord = function (rec) {
                                var e_13, _j;
                                var next = {};
                                try {
                                    for (var _k = __values(Object.keys(rec)), _l = _k.next(); !_l.done; _l = _k.next()) {
                                        var k = _l.value;
                                        var p = Number(k);
                                        if (p === pageA)
                                            next[pageB] = rec[p];
                                        else if (p === pageB)
                                            next[pageA] = rec[p];
                                        else
                                            next[p] = rec[p];
                                    }
                                }
                                catch (e_13_1) { e_13 = { error: e_13_1 }; }
                                finally {
                                    try {
                                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                                    }
                                    finally { if (e_13) throw e_13.error; }
                                }
                                return next;
                            };
                            this.strokes = swapRecord(this.strokes);
                            this.shapes = swapRecord(this.shapes);
                            this.redoStack = swapRecord(this.redoStack);
                            copy = this.basePdfBytes.slice(0);
                            if (this.pdfDocProxy) {
                                this.pdfDocProxy.destroy();
                                this.pdfDocProxy = null;
                            }
                            loadingTask = pdfjsLib__namespace.getDocument({ data: copy.slice(0) });
                            _l = this;
                            return [4 /*yield*/, loadingTask.promise];
                        case 6:
                            _l.pdfDocProxy = _m.sent();
                            prevCount = this.pageCount;
                            this.pageCount = this.pdfDocProxy.numPages;
                            this.syncLoadedWindow(prevCount);
                            this.pdfPageAspects.clear();
                            this.pdfPageRotations.clear();
                            _m.label = 7;
                        case 7:
                            _m.trys.push([7, 9, , 10]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(copy)];
                        case 8:
                            tmpDoc = _m.sent();
                            tmpDoc.getPages().forEach(function (pg, idx) {
                                var _j = pg.getSize(), width = _j.width, height = _j.height;
                                _this.pdfPageAspects.set(idx + 1, width / height);
                                _this.pdfPageRotations.set(idx + 1, pg.getRotation().angle || 0);
                            });
                            return [3 /*break*/, 10];
                        case 9:
                            _7 = _m.sent();
                            return [3 /*break*/, 10];
                        case 10:
                            this.renderedPages.clear();
                            this.renderingPages.clear();
                            return [4 /*yield*/, this.generateThumbnails()];
                        case 11:
                            _m.sent();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 12:
                            _m.sent();
                            return [3 /*break*/, 17];
                        case 13:
                            err_6 = _m.sent();
                            console.error('swapPages error:', err_6);
                            return [4 /*yield*/, this.toastCtrl.create({
                                    message: 'เกิดข้อผิดพลาดในการย้ายหน้า',
                                    duration: 2000, color: 'danger', position: 'bottom'
                                })];
                        case 14:
                            toast = _m.sent();
                            return [4 /*yield*/, toast.present()];
                        case 15:
                            _m.sent();
                            return [3 /*break*/, 17];
                        case 16:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 17: return [2 /*return*/];
                    }
                });
            });
        };
        /* ================= Page helpers ================= */
        PdfAnnotatorModalComponent.prototype.ensurePage = function (p) {
            if (p === void 0) { p = this.pageNo; }
            if (!this.strokes[p])
                this.strokes[p] = [];
            if (!this.shapes[p])
                this.shapes[p] = [];
            if (!this.redoStack[p])
                this.redoStack[p] = [];
        };
        PdfAnnotatorModalComponent.prototype.getPdfCanvas = function (p) {
            return document.getElementById('pdfCanvas-' + p);
        };
        PdfAnnotatorModalComponent.prototype.getAnnotCanvas = function (p) {
            return document.getElementById('annotCanvas-' + p);
        };
        PdfAnnotatorModalComponent.prototype.onViewerScroll = function (event) {
            if (this.isScrollNavigating)
                return;
            var container = event.target;
            var scrollTop = container.scrollTop;
            var containerHeight = container.clientHeight;
            // Find which page is most visible
            for (var i = 1; i <= this.loadedUntilPage; i++) {
                var pageEl = document.getElementById('page-' + i);
                if (!pageEl)
                    continue;
                var pageTop = pageEl.offsetTop - container.offsetTop;
                var pageBottom = pageTop + pageEl.offsetHeight;
                var visibleTop = Math.max(scrollTop, pageTop);
                var visibleBottom = Math.min(scrollTop + containerHeight, pageBottom);
                var visibleHeight = visibleBottom - visibleTop;
                if (visibleHeight > containerHeight * 0.5) {
                    if (this.pageNo !== i) {
                        this.pageNo = i;
                        this.scrollThumbnailIntoView(i);
                        this.cdr.detectChanges();
                        this.fitWidth();
                    }
                    // Load next chunk when approaching the last loaded page
                    if (i >= this.loadedUntilPage - 5)
                        this.loadNextChunk();
                    break;
                }
            }
        };
        // เลื่อน sidebar thumbnail ใกล้ล่างสุด → โหลด chunk หน้าถัดไป
        // (ก่อนหน้านี้มีแต่ onViewerScroll ของ viewer หลัก เลื่อน thumbnail เลยไม่โหลดต่อ)
        PdfAnnotatorModalComponent.prototype.onThumbScroll = function (event) {
            var el = event.target;
            if (el.scrollTop + el.clientHeight >= el.scrollHeight - 120) {
                this.loadNextChunk();
            }
        };
        PdfAnnotatorModalComponent.prototype.prevPage = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageNo <= 1)
                                return [2 /*return*/];
                            this.pageNo -= 1;
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.fitWidth()];
                        case 1:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.zoomIn = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            this.zoom = Math.min(3, this.zoom + 0.1);
                            this.renderedPages.clear();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 1:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.nextPage = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageNo >= this.pageCount)
                                return [2 /*return*/];
                            if (!(this.pageNo >= this.loadedUntilPage)) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.loadNextChunk()];
                        case 1:
                            _j.sent();
                            _j.label = 2;
                        case 2:
                            this.pageNo += 1;
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.fitWidth()];
                        case 3:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.firstPage = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageNo === 1)
                                return [2 /*return*/];
                            this.pageNo = 1;
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.fitWidth()];
                        case 1:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.lastPage = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.pageNo === this.pageCount)
                                return [2 /*return*/];
                            // Jump to last loaded page; pre-load next chunk in background
                            this.pageNo = this.loadedUntilPage;
                            this.scrollToPage(this.pageNo);
                            return [4 /*yield*/, this.fitWidth()];
                        case 1:
                            _j.sent();
                            if (this.loadedUntilPage < this.pageCount)
                                this.loadNextChunk();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.zoomOut = function () {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            this.zoom = Math.max(0.5, this.zoom - 0.1);
                            this.renderedPages.clear();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 1:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.scrollToPage = function (pageNum) {
            var _this = this;
            this.isScrollNavigating = true;
            var pageEl = document.getElementById('page-' + pageNum);
            if (pageEl) {
                pageEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
            // Also scroll thumbnail into view
            this.scrollThumbnailIntoView(pageNum);
            // Longer timeout for long documents - smooth scroll can take time
            setTimeout(function () {
                _this.isScrollNavigating = false;
            }, 1500);
        };
        PdfAnnotatorModalComponent.prototype.scrollThumbnailIntoView = function (pageNum) {
            var thumbEl = document.getElementById('thumb-' + pageNum);
            if (thumbEl) {
                thumbEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        };
        PdfAnnotatorModalComponent.prototype.debouncedRenderVisible = function () {
            var _this = this;
            if (this.renderDebounceTimer) {
                clearTimeout(this.renderDebounceTimer);
            }
            this.renderDebounceTimer = setTimeout(function () {
                _this.renderAllPages();
            }, 200);
        };
        PdfAnnotatorModalComponent.prototype.renderAllPages = function () {
            return __awaiter(this, void 0, void 0, function () {
                var p;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            // Prevent concurrent render calls
                            if (this.isRenderingAll)
                                return [2 /*return*/];
                            this.isRenderingAll = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, , 6, 7]);
                            p = 1;
                            _j.label = 2;
                        case 2:
                            if (!(p <= this.pageCount)) return [3 /*break*/, 5];
                            return [4 /*yield*/, this.renderPage(p)];
                        case 3:
                            _j.sent();
                            _j.label = 4;
                        case 4:
                            p++;
                            return [3 /*break*/, 2];
                        case 5: return [3 /*break*/, 7];
                        case 6:
                            this.isRenderingAll = false;
                            return [7 /*endfinally*/];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        /** Compute zoom so the WIDEST page in the document fits within the container.
         *  This prevents landscape pages from overflowing and being clipped by overflow-x. */
        PdfAnnotatorModalComponent.prototype.fitWidth = function () {
            return __awaiter(this, void 0, void 0, function () {
                var parent, containerW, targetW, sameContainer, samePage, maxVpWidth, p, pg, vp, _8;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.viewerContainerRef)
                                return [2 /*return*/];
                            parent = this.viewerContainerRef.nativeElement;
                            if (!(!parent || parent.clientWidth === 0)) return [3 /*break*/, 2];
                            return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 50); })];
                        case 1:
                            _j.sent();
                            return [2 /*return*/, this.fitWidth()];
                        case 2:
                            containerW = parent.clientWidth;
                            targetW = containerW - 40;
                            sameContainer = Math.abs(containerW - this.lastParentWidth) < 2;
                            samePage = this.pageNo === this.lastFitPageNo;
                            if (sameContainer && samePage)
                                return [2 /*return*/];
                            this.lastParentWidth = containerW;
                            this.lastFitPageNo = this.pageNo;
                            if (!(this.pages.length > 0)) return [3 /*break*/, 4];
                            return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 100); })];
                        case 3:
                            _j.sent();
                            _j.label = 4;
                        case 4:
                            maxVpWidth = 0;
                            p = 1;
                            _j.label = 5;
                        case 5:
                            if (!(p <= this.pageCount)) return [3 /*break*/, 10];
                            _j.label = 6;
                        case 6:
                            _j.trys.push([6, 8, , 9]);
                            return [4 /*yield*/, this.pdfDocProxy.getPage(p)];
                        case 7:
                            pg = _j.sent();
                            vp = pg.getViewport({ scale: 1 });
                            if (vp.width > maxVpWidth)
                                maxVpWidth = vp.width;
                            return [3 /*break*/, 9];
                        case 8:
                            _8 = _j.sent();
                            return [3 /*break*/, 9];
                        case 9:
                            p++;
                            return [3 /*break*/, 5];
                        case 10:
                            if (maxVpWidth <= 0)
                                return [2 /*return*/]; // safety guard
                            this.zoom = targetW / maxVpWidth;
                            this.renderedPages.clear();
                            return [4 /*yield*/, this.renderAllPages()];
                        case 11:
                            _j.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.renderPage = function (p) {
            if (p === void 0) { p = this.pageNo; }
            return __awaiter(this, void 0, void 0, function () {
                var page, viewport, pdfCanvas, pdfCtx, dpr, pageWrapper, textLayerDiv, textContent, textLayer, e_14, annotCanvas_1, err_7;
                var _this = this;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.pdfDocProxy || this.renderingPages.has(p) || this.renderedPages.has(p))
                                return [2 /*return*/];
                            this.renderingPages.add(p);
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 10, 11, 12]);
                            return [4 /*yield*/, this.pdfDocProxy.getPage(p)];
                        case 2:
                            page = _j.sent();
                            // Store the true effective rotation from pdf.js, as it correctly handles inherited rotations
                            // from the PDF page tree (which pdf-lib's getRotation() sometimes misses).
                            // We will use this in saveDocument to know exactly how the user saw the page.
                            this.pdfPageRotations.set(p, page.rotate || 0);
                            viewport = page.getViewport({ scale: this.zoom });
                            if (p === this.pageNo)
                                this.currentViewport = viewport;
                            pdfCanvas = this.getPdfCanvas(p);
                            if (!pdfCanvas)
                                return [2 /*return*/];
                            pdfCtx = pdfCanvas.getContext('2d');
                            dpr = Math.min(window.devicePixelRatio || 1, 2);
                            pdfCanvas.width = Math.floor(viewport.width * dpr);
                            pdfCanvas.height = Math.floor(viewport.height * dpr);
                            pdfCanvas.style.width = viewport.width + 'px';
                            pdfCanvas.style.height = viewport.height + 'px';
                            pdfCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
                            pdfCtx.clearRect(0, 0, viewport.width, viewport.height);
                            return [4 /*yield*/, page.render({ canvasContext: pdfCtx, viewport: viewport }).promise];
                        case 3:
                            _j.sent();
                            pageWrapper = pdfCanvas.parentElement;
                            if (!pageWrapper) return [3 /*break*/, 8];
                            textLayerDiv = pageWrapper.querySelector('.textLayer');
                            if (!textLayerDiv) {
                                textLayerDiv = document.createElement('div');
                                textLayerDiv.className = 'textLayer';
                                pageWrapper.insertBefore(textLayerDiv, pdfCanvas.nextSibling);
                            }
                            textLayerDiv.innerHTML = '';
                            textLayerDiv.style.width = viewport.width + 'px';
                            textLayerDiv.style.height = viewport.height + 'px';
                            textLayerDiv.style.left = '0';
                            textLayerDiv.style.top = '0';
                            // Ensure scale factor is cleanly applied
                            textLayerDiv.style.setProperty('--scale-factor', viewport.scale.toString());
                            _j.label = 4;
                        case 4:
                            _j.trys.push([4, 7, , 8]);
                            return [4 /*yield*/, page.getTextContent()];
                        case 5:
                            textContent = _j.sent();
                            textLayer = new pdfjsLib__namespace.TextLayer({
                                textContentSource: textContent,
                                container: textLayerDiv,
                                viewport: viewport
                            });
                            return [4 /*yield*/, textLayer.render()];
                        case 6:
                            _j.sent();
                            return [3 /*break*/, 8];
                        case 7:
                            e_14 = _j.sent();
                            console.warn('Failed to render text layer:', e_14);
                            return [3 /*break*/, 8];
                        case 8: 
                        // Small delay to ensure PDF content (fonts, text) are fully rendered
                        return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 100); })];
                        case 9:
                            // Small delay to ensure PDF content (fonts, text) are fully rendered
                            _j.sent();
                            this.resizeAnnotCanvasTo(p, viewport.width, viewport.height);
                            annotCanvas_1 = this.getAnnotCanvas(p);
                            if (annotCanvas_1) {
                                // Run events outside Angular to eliminate Change Detection lag on 120Hz/240Hz Apple Pencils
                                this.zone.runOutsideAngular(function () {
                                    if (annotCanvas_1._hasPointerEvents)
                                        return;
                                    annotCanvas_1._hasPointerEvents = true;
                                    annotCanvas_1.addEventListener('pointerdown', function (e) { return _this.onCanvasPointerDown(e, p); });
                                    annotCanvas_1.addEventListener('pointermove', function (e) { return _this.onCanvasPointerMove(e, p); });
                                    annotCanvas_1.addEventListener('pointerup', function (e) { return _this.onCanvasPointerUp(e, p); });
                                    annotCanvas_1.addEventListener('pointerleave', function (e) { return _this.onCanvasPointerUp(e, p); });
                                    annotCanvas_1.addEventListener('pointercancel', function (e) { return _this.onCanvasPointerUp(e, p); });
                                });
                            }
                            this.redraw(p);
                            this.clampTextBoxesToView();
                            this.renderedPages.add(p);
                            return [3 /*break*/, 12];
                        case 10:
                            err_7 = _j.sent();
                            console.error("Error rendering page " + p + ":", err_7);
                            return [3 /*break*/, 12];
                        case 11:
                            this.renderingPages.delete(p);
                            if (this.renderingPages.size === 0) {
                                this.isLoading = false;
                                this.loadingMessage = '';
                                this.cdr.detectChanges();
                            }
                            return [7 /*endfinally*/];
                        case 12: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.resizeAnnotCanvasTo = function (p, cssW, cssH) {
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var ctx = canvas.getContext('2d');
            // Cap DPR at 2 to reduce memory usage
            var dpr = Math.min(window.devicePixelRatio || 1, 2);
            // Force clear canvas before resizing to remove any artifacts
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            canvas.width = Math.floor(cssW * dpr);
            canvas.height = Math.floor(cssH * dpr);
            canvas.style.width = cssW + 'px';
            canvas.style.height = cssH + 'px';
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';
            ctx.imageSmoothingEnabled = false;
        };
        PdfAnnotatorModalComponent.prototype.setupResizeAutoRender = function () {
            var _this = this;
            if (!this.viewerContainerRef)
                return;
            this.resizeObserver = new ResizeObserver(function () {
                _this.fitWidth();
            });
            this.resizeObserver.observe(this.viewerContainerRef.nativeElement);
        };
        /* ================= Tool Mode Toggles ================= */
        PdfAnnotatorModalComponent.prototype.setToolMode = function (mode) {
            this.toolMode = this.toolMode === mode ? 'none' : mode;
            this.showShapeMenu = false;
            this.syncToolModeStyles();
        };
        PdfAnnotatorModalComponent.prototype.updateCursor = function () {
            var _this = this;
            this.pages.forEach(function (p) {
                var canvas = _this.getAnnotCanvas(p);
                if (canvas) {
                    switch (_this.toolMode) {
                        case 'draw':
                        case 'shape':
                        case 'eraser':
                        case 'date':
                        case 'mark':
                        case 'formfield':
                            canvas.style.cursor = 'crosshair';
                            break;
                        case 'highlight':
                            canvas.style.cursor = 'cell';
                            break;
                        case 'text':
                            canvas.style.cursor = 'text';
                            break;
                        case 'signature':
                            canvas.style.cursor = 'copy'; // Or custom cursor if available
                            break;
                        default:
                            canvas.style.cursor = 'default';
                    }
                }
            });
        };
        /* ================= Size Adjustments ================= */
        PdfAnnotatorModalComponent.prototype.changeBrushSize = function (delta) {
            this.brushSize = Math.max(1, Math.min(50, this.brushSize + delta));
            this.saveSettings();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.setBrushColor = function (color) {
            this.brushColor = color;
            this.saveSettings();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.changeHighlightSize = function (delta) {
            this.highlightSize = Math.max(5, Math.min(100, this.highlightSize + delta));
            this.saveSettings();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.setHighlightColor = function (color) {
            this.highlightColor = color;
            this.saveSettings();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.changeTextFontSize = function (delta) {
            var _this = this;
            this.textFontSize = Math.max(8, Math.min(100, this.textFontSize + delta));
            if (this.activeTextBoxId) {
                var tb = this.textBoxes.find(function (t) { return t.id === _this.activeTextBoxId; });
                if (tb) {
                    tb.fontSize = this.textFontSize;
                    this.cdr.detectChanges();
                }
            }
            this.saveSettings();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.toggleDraw = function () { this.setToolMode('draw'); };
        PdfAnnotatorModalComponent.prototype.toggleEraser = function () { this.setToolMode('eraser'); };
        PdfAnnotatorModalComponent.prototype.toggleHighlight = function () { this.setToolMode('highlight'); };
        PdfAnnotatorModalComponent.prototype.enableTextPlaceMode = function () { this.setToolMode('text'); };
        PdfAnnotatorModalComponent.prototype.toggleShapeMenu = function () {
            this.showShapeMenu = !this.showShapeMenu;
            if (this.showShapeMenu) {
                this.toolMode = 'shape';
            }
        };
        PdfAnnotatorModalComponent.prototype.toggleShapeDropdown = function () {
            this.showShapeDropdown = !this.showShapeDropdown;
        };
        PdfAnnotatorModalComponent.prototype.selectShape = function (type) {
            this.shapeType = type;
            this.toolMode = 'shape';
            this.showShapeMenu = false;
            this.showShapeDropdown = false;
            this.saveSettings();
            this.updateCursor();
        };
        PdfAnnotatorModalComponent.prototype.setShapeStrokeColor = function (color) {
            var _this = this;
            this.shapeStrokeColor = color;
            if (this.activeObjectId && this.activeObjectType === 'shape') {
                var s = this.shapeStamps.find(function (x) { return x.id === _this.activeObjectId; });
                if (s)
                    s.strokeColor = color;
            }
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.setShapeFillColor = function (color) {
            var _this = this;
            this.shapeFillColor = color;
            if (this.activeObjectId && this.activeObjectType === 'shape') {
                var s = this.shapeStamps.find(function (x) { return x.id === _this.activeObjectId; });
                if (s)
                    s.fillColor = color;
            }
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.toggleShapeFill = function () {
            var _this = this;
            this.shapeFillEnabled = !this.shapeFillEnabled;
            if (this.activeObjectId && this.activeObjectType === 'shape') {
                var s = this.shapeStamps.find(function (x) { return x.id === _this.activeObjectId; });
                if (s)
                    s.fillColor = this.shapeFillEnabled ? this.shapeFillColor : 'none';
            }
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.toggleShapeNoStroke = function () {
            var _this = this;
            this.shapeNoStroke = !this.shapeNoStroke;
            if (this.activeObjectId && this.activeObjectType === 'shape') {
                var s = this.shapeStamps.find(function (x) { return x.id === _this.activeObjectId; });
                if (s)
                    s.strokeColor = this.shapeNoStroke ? 'none' : this.shapeStrokeColor;
            }
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.changeShapeStrokeSize = function (delta) {
            var _this = this;
            var s = this.shapeStrokeSize + delta;
            if (s >= 1 && s <= 20) {
                this.shapeStrokeSize = s;
                if (this.activeObjectId && this.activeObjectType === 'shape') {
                    var shape = this.shapeStamps.find(function (x) { return x.id === _this.activeObjectId; });
                    if (shape)
                        shape.strokeWidth = s;
                }
                this.saveSettings();
            }
        };
        /* ================= Annotation Canvas Events ================= */
        PdfAnnotatorModalComponent.prototype.getNormPos = function (e, p) {
            var _this = this;
            var rect = this.activeCanvasRect || (function () {
                var canvas = _this.getAnnotCanvas(p);
                return canvas ? canvas.getBoundingClientRect() : null;
            })();
            if (!rect)
                return { x: 0, y: 0, p: 0 };
            var nx = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
            var ny = Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height));
            var pressure = (typeof e.pressure === 'number' && e.pressure > 0) ? e.pressure : 0;
            return { x: nx, y: ny, p: pressure };
        };
        PdfAnnotatorModalComponent.prototype.finalizeActiveStroke = function () {
            if (!this.activeStroke && !this.activeShape)
                return;
            var needsDetection = false;
            if (this.activeStroke) {
                this.ensurePage();
                this.strokes[this.pageNo].push(this.activeStroke);
                this.activeStroke = null;
            }
            if (this.activeShape) {
                var sh = this.activeShape;
                this.activeShape = null;
                // Convert canvas shape → draggable ShapeStamp overlay
                var canvas = this.getAnnotCanvas(sh.page);
                if (canvas) {
                    var cw = canvas.clientWidth;
                    var ch = canvas.clientHeight;
                    var x1 = sh.startX * cw;
                    var y1 = sh.startY * ch;
                    var x2 = sh.endX * cw;
                    var y2 = sh.endY * ch;
                    var left = Math.min(x1, x2);
                    var top = Math.min(y1, y2);
                    var right = Math.max(x1, x2);
                    var bottom = Math.max(y1, y2);
                    // For line/arrow the bounding box can be tiny — ensure minimum 20px
                    var bw = Math.max(right - left, 20);
                    var bh = Math.max(bottom - top, 20);
                    var stamp = {
                        id: 'shs_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                        page: sh.page,
                        x: (left / cw) * 100,
                        y: (top / ch) * 100,
                        width: (bw / cw) * 100,
                        height: (bh / ch) * 100,
                        type: sh.type,
                        strokeColor: sh.color,
                        strokeWidth: sh.size,
                        viewWidth: cw,
                        fillColor: sh.fillColor,
                        // Fraction of the bbox where the original start/end points sit
                        startFracX: bw > 0 ? (x1 - left) / bw : 0,
                        startFracY: bh > 0 ? (y1 - top) / bh : 0,
                        endFracX: bw > 0 ? (x2 - left) / bw : 1,
                        endFracY: bh > 0 ? (y2 - top) / bh : 1,
                    };
                    this.shapeStamps.push(stamp);
                }
                // Single-draw: exit shape mode after drawing one shape
                this.toolMode = 'none';
                this.updateCursor();
                this.syncToolModeStyles();
                needsDetection = true;
            }
            this.activePointerId = null;
            this.activeCanvasRect = null;
            this.redraw(this.pageNo);
            if (needsDetection) {
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.removeShapeStamp = function (id) {
            this.shapeStamps = this.shapeStamps.filter(function (s) { return s.id !== id; });
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.startShapeDrag = function (e, ssid) {
            var _this = this;
            if (this.toolMode !== 'none')
                return;
            this.closeContextMenu();
            this.activeObjectId = ssid;
            this.activeObjectType = 'shape';
            var stamp = this.shapeStamps.find(function (s) { return s.id === ssid; });
            if (!stamp)
                return;
            // Sync UI settings with the selected shape
            this.shapeType = stamp.type;
            if (stamp.strokeColor === 'none' || stamp.strokeColor === 'rgba(0,0,0,0)' || stamp.strokeColor === 'transparent') {
                this.shapeNoStroke = true;
            }
            else {
                this.shapeNoStroke = false;
                this.shapeStrokeColor = stamp.strokeColor;
            }
            if (!stamp.fillColor || stamp.fillColor === 'none' || stamp.fillColor === 'rgba(0,0,0,0)' || stamp.fillColor === 'transparent') {
                this.shapeFillEnabled = false;
            }
            else {
                this.shapeFillEnabled = true;
                this.shapeFillColor = stamp.fillColor;
            }
            this.shapeStrokeSize = stamp.strokeWidth || this.shapeStrokeSize;
            this.isDraggingShape = true;
            this.dragShapeId = ssid;
            var canvasRect = this.getDragCanvasRect(stamp.page);
            var startXpx = (stamp.x / 100) * canvasRect.width;
            var startYpx = (stamp.y / 100) * canvasRect.height;
            this.dragOffsetX = e.clientX - canvasRect.left - startXpx;
            this.dragOffsetY = e.clientY - canvasRect.top - startYpx;
            var move = function (ev) {
                ev.preventDefault();
                if (!_this.isDraggingShape || !_this.dragShapeId)
                    return;
                var s = _this.shapeStamps.find(function (x) { return x.id === _this.dragShapeId; });
                if (!s)
                    return;
                s.x = ((ev.clientX - canvasRect.left - _this.dragOffsetX) / canvasRect.width) * 100;
                s.y = ((ev.clientY - canvasRect.top - _this.dragOffsetY) / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                _this.isDraggingShape = false;
                _this.dragShapeId = null;
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startShapeResize = function (ev, shapeId, direction) {
            var _this = this;
            if (direction === void 0) { direction = 'se'; }
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            ev.preventDefault();
            var stamp = this.shapeStamps.find(function (s) { return s.id === shapeId; });
            if (!stamp)
                return;
            // Sync UI settings with the selected shape
            this.activeObjectId = shapeId;
            this.activeObjectType = 'shape';
            this.shapeType = stamp.type;
            if (stamp.strokeColor === 'none' || stamp.strokeColor === 'rgba(0,0,0,0)' || stamp.strokeColor === 'transparent') {
                this.shapeNoStroke = true;
            }
            else {
                this.shapeNoStroke = false;
                this.shapeStrokeColor = stamp.strokeColor;
            }
            if (!stamp.fillColor || stamp.fillColor === 'none' || stamp.fillColor === 'rgba(0,0,0,0)' || stamp.fillColor === 'transparent') {
                this.shapeFillEnabled = false;
            }
            else {
                this.shapeFillEnabled = true;
                this.shapeFillColor = stamp.fillColor;
            }
            this.shapeStrokeSize = stamp.strokeWidth || this.shapeStrokeSize;
            this.isResizingShape = true;
            this.resizeShapeId = shapeId;
            var canvasRect = this.getDragCanvasRect(stamp.page);
            var startX = ev.clientX;
            var startY = ev.clientY;
            var startW = stamp.width;
            var startH = stamp.height;
            var startSX = stamp.x;
            var startSY = stamp.y;
            var move = function (e) {
                e.preventDefault();
                if (!_this.isResizingShape || !_this.resizeShapeId)
                    return;
                var s = _this.shapeStamps.find(function (x) { return x.id === _this.resizeShapeId; });
                if (!s)
                    return;
                var dx = ((e.clientX - startX) / canvasRect.width) * 100;
                var dy = ((e.clientY - startY) / canvasRect.height) * 100;
                var nw = startW, nh = startH, nx = startSX, ny = startSY;
                if (direction.includes('e'))
                    nw = Math.max(2, startW + dx);
                if (direction.includes('w')) {
                    nw = Math.max(2, startW - dx);
                    nx = startSX + (startW - nw);
                }
                if (direction.includes('s'))
                    nh = Math.max(2, startH + dy);
                if (direction.includes('n')) {
                    nh = Math.max(2, startH - dy);
                    ny = startSY + (startH - nh);
                }
                s.width = nw;
                s.height = nh;
                s.x = nx;
                s.y = ny;
                _this.cdr.detectChanges();
            };
            var up = function () {
                _this.isResizingShape = false;
                _this.resizeShapeId = null;
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        /** Returns arrow rotation angle in degrees — used in SVG template to avoid Math in template */
        PdfAnnotatorModalComponent.prototype.getArrowAngleDeg = function (ss) {
            return (180 / Math.PI) * Math.atan2(ss.endFracY - ss.startFracY, ss.endFracX - ss.startFracX);
        };
        PdfAnnotatorModalComponent.prototype.onCanvasPointerDown = function (e, p) {
            var _this = this;
            // Prevent default touch behavior (scroll, zoom) when any tool is active
            if (this.toolMode !== 'none') {
                e.preventDefault();
            }
            // Finalize previous stroke if it exists
            if (this.activeStroke || this.activeShape) {
                this.finalizeActiveStroke();
            }
            // iPad Palm Rejection / Multi-touch handling
            if (this.activePointerId !== null) {
                if (e.pointerType === 'pen') {
                    // ALWAYS trust a new pen touch. If pointerup was delayed, cut it off and start fresh.
                    this.activeStroke = null;
                    this.activeShape = null;
                }
                else if (this.activePointerType === 'pen') {
                    return; // Strongly ignore touch if pen is currently active
                }
                else {
                    // Trust the newest touch if no pen is involved
                    this.activeStroke = null;
                    this.activeShape = null;
                }
            }
            // Deselect any active element when clicking on the empty canvas
            this.zone.run(function () {
                if (_this.activeTextBoxId !== null || _this.activeObjectId !== null || _this.activeFormFieldId !== null) {
                    _this.activeTextBoxId = null;
                    _this.activeObjectId = null;
                    _this.activeObjectType = null;
                    _this.activeFormFieldId = null;
                    _this.cdr.detectChanges();
                }
            });
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            this.activeCanvasRect = canvas.getBoundingClientRect();
            this.ensurePage(p);
            this.pageNo = p; // Mark this page as current for mode consistency
            switch (this.toolMode) {
                case 'draw':
                case 'highlight':
                case 'shape':
                    canvas.setPointerCapture(e.pointerId);
                    this.activePointerId = e.pointerId;
                    this.activePointerType = e.pointerType;
                    if (this.toolMode === 'draw' || this.toolMode === 'highlight') {
                        var isHighlight = this.toolMode === 'highlight';
                        this.activeStroke = {
                            id: 's_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                            color: isHighlight ? this.highlightColor : this.brushColor,
                            size: isHighlight ? this.highlightSize : this.brushSize,
                            points: [this.getNormPos(e, p)],
                            isHighlight: isHighlight
                        };
                    }
                    else if (this.toolMode === 'shape') {
                        var pos = this.getNormPos(e, p);
                        this.activeShape = {
                            id: 'sh_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                            page: p,
                            type: this.shapeType,
                            startX: pos.x,
                            startY: pos.y,
                            endX: pos.x,
                            endY: pos.y,
                            color: this.shapeNoStroke ? 'rgba(0,0,0,0)' : this.shapeStrokeColor,
                            size: this.shapeNoStroke ? 0 : this.shapeStrokeSize,
                            fillColor: this.shapeFillEnabled ? this.shapeFillColor : undefined
                        };
                    }
                    this.redoStack[p] = [];
                    break;
                case 'eraser':
                    this.eraseAtPoint(e, p);
                    break;
                case 'date': {
                    var rect = canvas.getBoundingClientRect();
                    var mouseX = e.clientX - rect.left;
                    var mouseY = e.clientY - rect.top;
                    var now = new Date();
                    var day = String(now.getDate()).padStart(2, '0');
                    var month = String(now.getMonth() + 1).padStart(2, '0');
                    var year = now.getFullYear();
                    var thaiYear = year + 543;
                    var dateText = day + "/" + month + "/" + thaiYear;
                    // Normalize mouse x/y to 0..100
                    var xNormalized = (mouseX / rect.width) * 100;
                    var yNormalized = (mouseY / rect.height) * 100;
                    this.dateStamps.push({
                        id: 'date_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                        page: p,
                        x: xNormalized - 5,
                        y: yNormalized - 1,
                        text: dateText,
                        color: this.dateColor,
                        fontSize: this.dateFontSize
                    });
                    // Log to history
                    this.logHistory('date_stamp', { page: p, text: dateText }, p);
                    this.toolMode = 'none';
                    this.updateCursor();
                    break;
                }
                case 'mark': {
                    var rect = canvas.getBoundingClientRect();
                    var mouseX = e.clientX - rect.left;
                    var mouseY = e.clientY - rect.top;
                    var sizePx = this.markSize;
                    var dataUrl = this.generateMarkDataUrl(this.markType, this.markColor, sizePx * 2);
                    var xPct = ((mouseX - sizePx / 2) / rect.width) * 100;
                    var yPct = ((mouseY - sizePx / 2) / rect.height) * 100;
                    var wPct = (sizePx / rect.width) * 100;
                    var hPct = (sizePx / rect.height) * 100;
                    this.imageStamps.push({
                        id: 'mark_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                        page: p, x: xPct, y: yPct, width: wPct, height: hPct,
                        dataUrl: dataUrl,
                        markType: this.markType,
                        markColor: this.markColor,
                    });
                    this.logHistory('image', { type: 'mark', markType: this.markType }, p);
                    break;
                }
                case 'formfield': {
                    var rect = canvas.getBoundingClientRect();
                    var mouseX = e.clientX - rect.left;
                    var mouseY = e.clientY - rect.top;
                    var type = this.formFieldType;
                    var defaultW = type === 'text' ? 28 : 4.5;
                    var defaultH = type === 'text' ? 4 : 4.5;
                    var newId = 'ff_' + Date.now() + '_' + Math.random().toString(16).slice(2);
                    this.pdfFormFields.push({
                        id: newId,
                        page: p,
                        type: type,
                        x: Math.max(0, (mouseX / rect.width) * 100 - defaultW / 2),
                        y: Math.max(0, (mouseY / rect.height) * 100 - defaultH / 2),
                        width: defaultW,
                        height: defaultH,
                        fieldName: type + "_" + ++this.formFieldCounter,
                        radioGroupName: type === 'radio' ? 'radioGroup_1' : undefined,
                        fontSize: 12,
                        borderVisible: true,
                    });
                    this.activeFormFieldId = newId;
                    this.activeTextBoxId = null;
                    this.activeObjectId = null;
                    this.activeObjectType = null;
                    this.logHistory('image', { type: 'formfield', fieldType: type }, p);
                    break;
                }
                case 'signature':
                    if (this.pendingSignatureDataUrl) {
                        this.placeSignatureOnPage(e, p);
                    }
                    break;
                case 'text':
                    this.placeTextBoxOnPage(e, p);
                    break;
                default:
                    // Do nothing for 'none' or 'signature' (if no data URL)
                    break;
            }
            // Only run detectChanges for modes that modify the Angular template.
            // Canvas-only modes (draw/highlight/shape/eraser) don't need it.
            var canvasOnlyMode = this.toolMode === 'draw' || this.toolMode === 'highlight'
                || this.toolMode === 'shape' || this.toolMode === 'eraser'
                || this.toolMode === 'mark' || this.toolMode === 'formfield';
            if (!canvasOnlyMode) {
                this.cdr.detectChanges();
            }
        };
        PdfAnnotatorModalComponent.prototype.onCanvasPointerMove = function (e, p) {
            var e_15, _j;
            var _this = this;
            if (this.activePointerId !== null && e.pointerId !== this.activePointerId)
                return;
            // Prevent default touch handling during active drawing
            if (this.activeStroke || this.activeShape) {
                e.preventDefault();
            }
            if (this.activeStroke) {
                var events = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
                if (!events || events.length === 0)
                    events = [e];
                var startIdx_1 = Math.max(0, this.activeStroke.points.length - 1);
                var canvasRect = this.activeCanvasRect;
                try {
                    for (var events_1 = __values(events), events_1_1 = events_1.next(); !events_1_1.done; events_1_1 = events_1.next()) {
                        var ev = events_1_1.value;
                        var pt = this.getNormPos(ev, p);
                        if (this.activeStroke.points.length > 0 && canvasRect) {
                            var lastPt = this.activeStroke.points[this.activeStroke.points.length - 1];
                            // Skip physically tiny sub-pixel movements (less than 1.5px) to drastically reduce rendering overhead/lag
                            var dx = (pt.x - lastPt.x) * canvasRect.width;
                            var dy = (pt.y - lastPt.y) * canvasRect.height;
                            if (dx * dx + dy * dy < 2.25)
                                continue; // 1.5px squared
                            // Exponential Moving Average to smooth Apple Pencil hardware pressure & coordinate jitter
                            pt.x = (pt.x * 0.4) + (lastPt.x * 0.6);
                            pt.y = (pt.y * 0.4) + (lastPt.y * 0.6);
                            pt.p = (pt.p * 0.2) + (lastPt.p * 0.8);
                        }
                        this.activeStroke.points.push(pt);
                    }
                }
                catch (e_15_1) { e_15 = { error: e_15_1 }; }
                finally {
                    try {
                        if (events_1_1 && !events_1_1.done && (_j = events_1.return)) _j.call(events_1);
                    }
                    finally { if (e_15) throw e_15.error; }
                }
                // Incremental render for zero-latency drawing
                if (!this.renderRequested) {
                    this.renderRequested = true;
                    var strokeToDraw_1 = this.activeStroke; // capture local reference
                    requestAnimationFrame(function () {
                        if (strokeToDraw_1) {
                            if (strokeToDraw_1.isHighlight) {
                                // Highlight strokes must be fully redrawn each frame (no incremental draw)
                                // to prevent the alpha opacity from multiplying on top of itself at overlapping line joints.
                                _this.redraw(p, true);
                            }
                            else {
                                _this.drawStrokeIncremental(p, strokeToDraw_1, startIdx_1);
                            }
                        }
                        _this.renderRequested = false;
                    });
                }
            }
            else if (this.activeShape) {
                var pos = this.getNormPos(e, p);
                this.activeShape.endX = pos.x;
                this.activeShape.endY = pos.y;
                if (!this.renderRequested) {
                    this.renderRequested = true;
                    requestAnimationFrame(function () {
                        _this.redraw(p, true);
                        _this.renderRequested = false;
                    });
                }
            }
            else if (this.toolMode === 'eraser' && e.buttons === 1) {
                this.eraseAtPoint(e, p);
            }
        };
        PdfAnnotatorModalComponent.prototype.onCanvasPointerUp = function (e, p) {
            if (this.activePointerId !== null && e.pointerId === this.activePointerId) {
                e.preventDefault();
                this.finalizeActiveStroke();
                var canvas = this.getAnnotCanvas(p);
                if (canvas && canvas.hasPointerCapture(e.pointerId)) {
                    canvas.releasePointerCapture(e.pointerId);
                }
                this.activePointerId = null;
                this.activePointerType = '';
            }
        };
        PdfAnnotatorModalComponent.prototype.placeSignatureOnPage = function (e, p) {
            var _this = this;
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var rect = canvas.getBoundingClientRect();
            var mouseX = e.clientX - rect.left;
            var mouseY = e.clientY - rect.top;
            var dataUrl = this.pendingSignatureDataUrl;
            // Load the image to get its real aspect ratio
            var img = new Image();
            img.onload = function () { return __awaiter(_this, void 0, void 0, function () {
                var sigWidthPercent, pdfAspect, canvasAspect, imgNaturalAspect, sigHeightPercent, x, y, now, thaiYear, dateStr, timeStr, digitalId, _j, stamp;
                return __generator(this, function (_k) {
                    switch (_k.label) {
                        case 0:
                            sigWidthPercent = 15;
                            pdfAspect = this.pdfPageAspects.get(p);
                            canvasAspect = rect.width / rect.height;
                            imgNaturalAspect = img.width / img.height;
                            sigHeightPercent = pdfAspect
                                ? sigWidthPercent * (pdfAspect / imgNaturalAspect)
                                : sigWidthPercent * (img.height / img.width) * canvasAspect;
                            x = (mouseX / rect.width) * 100 - (sigWidthPercent / 2);
                            y = (mouseY / rect.height) * 100 - (sigHeightPercent / 2);
                            now = new Date();
                            thaiYear = now.getFullYear() + 543;
                            dateStr = now.getDate().toString().padStart(2, '0') + "/" + (now.getMonth() + 1).toString().padStart(2, '0') + "/" + thaiYear;
                            timeStr = now.getHours().toString().padStart(2, '0') + ":" + now.getMinutes().toString().padStart(2, '0') + ":" + now.getSeconds().toString().padStart(2, '0') + " +07'00'";
                            if (!this.userId) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.hashUserId(this.userId)];
                        case 1:
                            _j = _k.sent();
                            return [3 /*break*/, 3];
                        case 2:
                            _j = '';
                            _k.label = 3;
                        case 3:
                            digitalId = _j;
                            stamp = {
                                id: 'sig_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                                page: p,
                                x: x,
                                y: y,
                                width: sigWidthPercent,
                                height: sigHeightPercent,
                                dataUrl: dataUrl,
                                digitalId: digitalId,
                                signDate: dateStr,
                                signTime: timeStr
                            };
                            this.signatureStamps.push(stamp);
                            // Log to history
                            this.logHistory('sign', { page: p, x: stamp.x, y: stamp.y, digitalId: stamp.digitalId }, p);
                            this.pendingSignatureDataUrl = null;
                            this.toolMode = 'none';
                            this.updateCursor();
                            this.cdr.detectChanges();
                            return [2 /*return*/];
                    }
                });
            }); };
            img.src = dataUrl;
        };
        /** Generate SHA-256 based Digital ID from userId */
        PdfAnnotatorModalComponent.prototype.hashUserId = function (userId) {
            return __awaiter(this, void 0, void 0, function () {
                var encoder, data, hashBuffer, hashArray, hashHex, e_16, hash, i, ch;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            _j.trys.push([0, 2, , 3]);
                            encoder = new TextEncoder();
                            data = encoder.encode(userId);
                            return [4 /*yield*/, crypto.subtle.digest('SHA-256', data)];
                        case 1:
                            hashBuffer = _j.sent();
                            hashArray = Array.from(new Uint8Array(hashBuffer));
                            hashHex = hashArray.map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
                            // Take first 10 hex chars for a shorter but still unique ID
                            return [2 /*return*/, "DID-" + hashHex.substring(0, 10).toUpperCase()];
                        case 2:
                            e_16 = _j.sent();
                            hash = 0;
                            for (i = 0; i < userId.length; i++) {
                                ch = userId.charCodeAt(i);
                                hash = ((hash << 5) - hash) + ch;
                                hash = hash & hash;
                            }
                            return [2 /*return*/, "DID-" + Math.abs(hash).toString(16).toUpperCase().padStart(8, '0')];
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        /** Log signature placement to database for reference/audit */
        PdfAnnotatorModalComponent.prototype.logSignatureToDatabase = function (digitalId, signDate, pageNumber) {
            if (!this.userId || !digitalId)
                return;
            var isoDate = signDate.toISOString().replace('T', ' ').substring(0, 19);
            this.http.post(this.signaturesApiUrl, {
                aksi: 'log_signature',
                digital_id: digitalId,
                user_id: this.userId,
                sign_date: isoDate,
                document_name: this.fileName || '',
                page_number: pageNumber,
                detail_id: this.detailId || '',
                edoc_id: this.edocId || ''
            }).subscribe(function (res) {
                if (res === null || res === void 0 ? void 0 : res.success) {
                    console.log('Signature logged:', digitalId);
                }
                else {
                    console.warn('Failed to log signature:', res === null || res === void 0 ? void 0 : res.msg);
                }
            }, function (err) { return console.error('Error logging signature:', err); });
        };
        PdfAnnotatorModalComponent.prototype.placeTextBoxOnPage = function (e, p) {
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var rect = canvas.getBoundingClientRect();
            var mouseX = e.clientX - rect.left;
            var mouseY = e.clientY - rect.top;
            // Normalize position to 0..100
            var x = (mouseX / rect.width) * 100;
            var y = (mouseY / rect.height) * 100;
            // Default size in percentages
            var widthPercent = 6;
            var heightPercent = 5; // Reduced from 10%
            this.textBoxes.push({
                id: 't_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                page: p,
                x: x,
                y: y,
                width: widthPercent,
                height: heightPercent,
                text: '',
                color: this.textColor,
                fontSize: this.textFontSize,
                bold: this.tbDefaultBold,
                italic: this.tbDefaultItalic,
                align: this.tbDefaultAlign,
                fontFamily: this.tbDefaultFontFamily,
                opacity: 1,
                rotation: 0,
                letterSpacing: this.tbDefaultLetterSpacing,
                lineHeight: this.tbDefaultLineHeight,
            });
            this.activeTextBoxId = this.textBoxes[this.textBoxes.length - 1].id;
            this.toolMode = 'none';
            this.syncToolModeStyles();
            this.updateCursor();
            this.cdr.detectChanges();
            // Log to history
            this.logHistory('text', { page: p, fontSize: this.textFontSize, color: this.textColor }, p);
            // Auto-focus the textarea to show keyboard immediately
            setTimeout(function () {
                var textBoxEl = document.querySelector('.text-box.active textarea');
                if (textBoxEl) {
                    textBoxEl.focus();
                }
            }, 100);
        };
        /* ================= Eraser ================= */
        PdfAnnotatorModalComponent.prototype.changeEraserSize = function (delta) {
            var newSize = this.eraserSize + delta;
            if (newSize >= 5 && newSize <= 200) {
                this.eraserSize = newSize;
                this.saveSettings();
            }
        };
        PdfAnnotatorModalComponent.prototype.eraseAtPoint = function (e, p) {
            var pos = this.getNormPos(e, p);
            // Scale threshold based on eraser size. 
            // Default size 20 matches ~0.02 threshold roughly
            var threshold = (this.eraserSize / 1000);
            // Check strokes
            this.strokes[p] = this.strokes[p].filter(function (stroke) {
                return !stroke.points.some(function (pt) { return Math.abs(pt.x - pos.x) < threshold && Math.abs(pt.y - pos.y) < threshold; });
            });
            // Check shapes
            this.shapes[p] = this.shapes[p].filter(function (shape) {
                var centerX = (shape.startX + shape.endX) / 2;
                var centerY = (shape.startY + shape.endY) / 2;
                var halfW = Math.abs(shape.endX - shape.startX) / 2;
                var halfH = Math.abs(shape.endY - shape.startY) / 2;
                return !(pos.x >= centerX - halfW - threshold &&
                    pos.x <= centerX + halfW + threshold &&
                    pos.y >= centerY - halfH - threshold &&
                    pos.y <= centerY + halfH + threshold);
            });
            this.redraw(p);
        };
        /* ================= Drawing ================= */
        PdfAnnotatorModalComponent.prototype.calcLineWidth = function (base, pressure) {
            if (!pressure)
                return base;
            return Math.max(1, base * (0.6 + pressure * 1.8));
        };
        PdfAnnotatorModalComponent.prototype.redraw = function (p, includeActive) {
            var e_17, _j, e_18, _k;
            if (p === void 0) { p = this.pageNo; }
            if (includeActive === void 0) { includeActive = false; }
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
            var dpr = window.devicePixelRatio || 1;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';
            ctx.clearRect(0, 0, canvas.width / dpr, canvas.height / dpr);
            this.ensurePage(p);
            try {
                // Draw all static annotations for this specific page
                for (var _l = __values(this.strokes[p]), _m = _l.next(); !_m.done; _m = _l.next()) {
                    var s = _m.value;
                    this.drawStroke(ctx, p, s);
                }
            }
            catch (e_17_1) { e_17 = { error: e_17_1 }; }
            finally {
                try {
                    if (_m && !_m.done && (_j = _l.return)) _j.call(_l);
                }
                finally { if (e_17) throw e_17.error; }
            }
            try {
                for (var _o = __values(this.shapes[p]), _p = _o.next(); !_p.done; _p = _o.next()) {
                    var sh = _p.value;
                    this.drawShape(ctx, p, sh);
                }
            }
            catch (e_18_1) { e_18 = { error: e_18_1 }; }
            finally {
                try {
                    if (_p && !_p.done && (_k = _o.return)) _k.call(_o);
                }
                finally { if (e_18) throw e_18.error; }
            }
            // Draw active if this is the target page
            if (includeActive && p === this.pageNo) {
                if (this.activeStroke)
                    this.drawStroke(ctx, p, this.activeStroke);
                if (this.activeShape)
                    this.drawShape(ctx, p, this.activeShape);
            }
        };
        PdfAnnotatorModalComponent.prototype.drawStroke = function (ctx, p, s) {
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var dpr = window.devicePixelRatio || 1;
            var w = canvas.width / dpr;
            var h = canvas.height / dpr;
            if (s.points.length < 2)
                return;
            if (s.isHighlight) {
                ctx.save();
                ctx.globalAlpha = 0.4;
                // Highlighters multiply against the background to feel like real markers
                ctx.globalCompositeOperation = 'multiply';
                ctx.strokeStyle = s.color;
                ctx.lineCap = 'round';
                ctx.lineJoin = 'round';
                ctx.lineWidth = s.size;
                // Draw as a single continuous path without multiple beginPath() calls
                // to ensure overlapping joints do not amplify the alpha transparency.
                ctx.beginPath();
                for (var i = 0; i < s.points.length; i++) {
                    var pt = s.points[i];
                    if (i === 0) {
                        ctx.moveTo(pt.x * w, pt.y * h);
                    }
                    else {
                        ctx.lineTo(pt.x * w, pt.y * h);
                    }
                }
                ctx.stroke();
                ctx.restore();
                return;
            }
            ctx.strokeStyle = s.color;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            // To support pressure-sensitive width AND butter-smooth curves,
            // we use segmented quadratic bezier curves passing through midpoints
            for (var i = 1; i < s.points.length; i++) {
                var prevPrev = i > 1 ? s.points[i - 2] : s.points[i - 1];
                var prev = s.points[i - 1];
                var curr = s.points[i];
                var startX = (prevPrev.x + prev.x) / 2 * w;
                var startY = (prevPrev.y + prev.y) / 2 * h;
                var endX = (prev.x + curr.x) / 2 * w;
                var endY = (prev.y + curr.y) / 2 * h;
                ctx.lineWidth = this.calcLineWidth(s.size, curr.p);
                ctx.beginPath();
                if (i === 1) {
                    ctx.moveTo(prev.x * w, prev.y * h);
                    ctx.lineTo(endX, endY);
                }
                else if (i === s.points.length - 1) {
                    ctx.moveTo(startX, startY);
                    ctx.quadraticCurveTo(prev.x * w, prev.y * h, curr.x * w, curr.y * h);
                }
                else {
                    ctx.moveTo(startX, startY);
                    ctx.quadraticCurveTo(prev.x * w, prev.y * h, endX, endY);
                }
                ctx.stroke();
            }
        };
        PdfAnnotatorModalComponent.prototype.drawStrokeIncremental = function (p, s, startIdx) {
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
            var dpr = window.devicePixelRatio || 1;
            var w = canvas.width / dpr;
            var h = canvas.height / dpr;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.strokeStyle = s.color;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            var renderStart = Math.max(1, startIdx);
            for (var i = renderStart; i < s.points.length; i++) {
                var prevPrev = i > 1 ? s.points[i - 2] : s.points[i - 1];
                var prev = s.points[i - 1];
                var curr = s.points[i];
                var startX = (prevPrev.x + prev.x) / 2 * w;
                var startY = (prevPrev.y + prev.y) / 2 * h;
                var endX = (prev.x + curr.x) / 2 * w;
                var endY = (prev.y + curr.y) / 2 * h;
                ctx.lineWidth = this.calcLineWidth(s.size, curr.p);
                ctx.beginPath();
                if (i === 1) {
                    ctx.moveTo(prev.x * w, prev.y * h);
                    ctx.lineTo(endX, endY);
                }
                else if (i === s.points.length - 1) {
                    ctx.moveTo(startX, startY);
                    ctx.quadraticCurveTo(prev.x * w, prev.y * h, curr.x * w, curr.y * h);
                }
                else {
                    ctx.moveTo(startX, startY);
                    ctx.quadraticCurveTo(prev.x * w, prev.y * h, endX, endY);
                }
                ctx.stroke();
            }
        };
        PdfAnnotatorModalComponent.prototype.drawShape = function (ctx, p, sh) {
            var canvas = this.getAnnotCanvas(p);
            if (!canvas)
                return;
            var dpr = window.devicePixelRatio || 1;
            var w = canvas.width / dpr;
            var h = canvas.height / dpr;
            var x1 = sh.startX * w;
            var y1 = sh.startY * h;
            var x2 = sh.endX * w;
            var y2 = sh.endY * h;
            ctx.strokeStyle = sh.color;
            ctx.lineWidth = sh.size;
            ctx.beginPath();
            switch (sh.type) {
                case 'rect':
                    ctx.rect(x1, y1, x2 - x1, y2 - y1);
                    if (sh.fillColor) {
                        ctx.fillStyle = sh.fillColor;
                        ctx.fill();
                    }
                    break;
                case 'circle': {
                    var cx = (x1 + x2) / 2;
                    var cy = (y1 + y2) / 2;
                    var rx = Math.abs(x2 - x1) / 2;
                    var ry = Math.abs(y2 - y1) / 2;
                    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
                    if (sh.fillColor) {
                        ctx.fillStyle = sh.fillColor;
                        ctx.fill();
                    }
                    break;
                }
                case 'line':
                    ctx.moveTo(x1, y1);
                    ctx.lineTo(x2, y2);
                    break;
                case 'arrow': {
                    ctx.moveTo(x1, y1);
                    ctx.lineTo(x2, y2);
                    ctx.stroke();
                    var angle = Math.atan2(y2 - y1, x2 - x1);
                    var headLen = 15;
                    ctx.beginPath();
                    ctx.moveTo(x2, y2);
                    ctx.lineTo(x2 - headLen * Math.cos(angle - Math.PI / 6), y2 - headLen * Math.sin(angle - Math.PI / 6));
                    ctx.moveTo(x2, y2);
                    ctx.lineTo(x2 - headLen * Math.cos(angle + Math.PI / 6), y2 - headLen * Math.sin(angle + Math.PI / 6));
                    break;
                }
            }
            ctx.stroke();
        };
        /* ================= Undo/Redo per page ================= */
        PdfAnnotatorModalComponent.prototype.canUndo = function () {
            this.ensurePage(this.pageNo);
            return this.strokes[this.pageNo].length > 0 || this.shapes[this.pageNo].length > 0;
        };
        PdfAnnotatorModalComponent.prototype.canRedo = function () {
            this.ensurePage(this.pageNo);
            return this.redoStack[this.pageNo].length > 0;
        };
        PdfAnnotatorModalComponent.prototype.undo = function () {
            this.ensurePage(this.pageNo);
            var item = this.strokes[this.pageNo].pop();
            if (!item)
                item = this.shapes[this.pageNo].pop();
            if (!item)
                return;
            this.redoStack[this.pageNo].push(item);
            this.redraw(this.pageNo);
        };
        PdfAnnotatorModalComponent.prototype.redo = function () {
            this.ensurePage(this.pageNo);
            var item = this.redoStack[this.pageNo].pop();
            if (!item)
                return;
            if ('points' in item)
                this.strokes[this.pageNo].push(item);
            else
                this.shapes[this.pageNo].push(item);
            this.redraw(this.pageNo);
        };
        PdfAnnotatorModalComponent.prototype.clearAnnotations = function () {
            var _this = this;
            this.ensurePage(this.pageNo);
            this.strokes[this.pageNo] = [];
            this.shapes[this.pageNo] = [];
            this.redoStack[this.pageNo] = [];
            this.textBoxes = this.textBoxes.filter(function (t) { return t.page !== _this.pageNo; });
            this.imageStamps = this.imageStamps.filter(function (i) { return i.page !== _this.pageNo; });
            this.signatureStamps = this.signatureStamps.filter(function (s) { return s.page !== _this.pageNo; });
            this.dateStamps = this.dateStamps.filter(function (d) { return d.page !== _this.pageNo; });
            this.redraw(this.pageNo);
        };
        /* ================= TextBox Operations ================= */
        PdfAnnotatorModalComponent.prototype.selectTextBox = function (id, ev) {
            ev.stopPropagation();
            this.activeTextBoxId = id;
        };
        PdfAnnotatorModalComponent.prototype.onTextBoxPointerDown = function (ev, id) {
            ev.stopPropagation();
            this.activeTextBoxId = id;
            this.startDrag(ev, id);
        };
        PdfAnnotatorModalComponent.prototype.clearTextSelection = function () {
            this.activeTextBoxId = null;
        };
        PdfAnnotatorModalComponent.prototype.getDragCanvasRect = function (p) {
            var canvas = this.getAnnotCanvas(p);
            return canvas ? canvas.getBoundingClientRect() : new DOMRect();
        };
        PdfAnnotatorModalComponent.prototype.startDrag = function (e, textBoxId) {
            var _this = this;
            if (this.toolMode !== 'none')
                return;
            this.closeContextMenu();
            // Set both activeTextBoxId (for UI) and global active object (for Delete key)
            this.activeTextBoxId = textBoxId;
            this.activeObjectId = textBoxId;
            this.activeObjectType = 'text';
            this.activeFormFieldId = null; // ปิดแถบฟอร์มเมื่อสลับมาแก้กล่องข้อความ
            var tb = this.textBoxes.find(function (t) { return t.id === textBoxId; });
            if (!tb)
                return;
            // Sync UI settings with the selected text box
            this.textColor = tb.color || this.textColor;
            this.textFontSize = tb.fontSize || this.textFontSize;
            // If user tapped directly on textarea to type, do not initiate dragging or blurring.
            var target = e.target;
            if (target.tagName.toLowerCase() === 'textarea') {
                return;
            }
            var textBoxEl = e.currentTarget;
            // Lock touch-action during drag to prevent iPad scroll
            textBoxEl.style.touchAction = 'none';
            // Disable textarea to prevent iPadOS Scribble during drag
            var textareaEl = textBoxEl === null || textBoxEl === void 0 ? void 0 : textBoxEl.querySelector('textarea');
            if (textareaEl) {
                textareaEl.blur();
                textareaEl.setAttribute('readonly', 'true');
                textareaEl.style.pointerEvents = 'none';
            }
            this.isDragging = true;
            this.dragTextBoxId = textBoxId;
            var canvasRect = this.getDragCanvasRect(tb.page);
            // Convert current % position to pixels for initial offset calculation
            var startXpx = (tb.x / 100) * canvasRect.width;
            var startYpx = (tb.y / 100) * canvasRect.height;
            this.dragOffsetX = e.clientX - canvasRect.left - startXpx;
            this.dragOffsetY = e.clientY - canvasRect.top - startYpx;
            var move = function (ev) {
                ev.preventDefault();
                if (!_this.isDragging || !_this.dragTextBoxId)
                    return;
                var t = _this.textBoxes.find(function (x) { return x.id === _this.dragTextBoxId; });
                if (!t)
                    return;
                var mouseXpx = ev.clientX - canvasRect.left - _this.dragOffsetX;
                var mouseYpx = ev.clientY - canvasRect.top - _this.dragOffsetY;
                // Back to normalized
                t.x = (mouseXpx / canvasRect.width) * 100;
                t.y = (mouseYpx / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                _this.isDragging = false;
                _this.dragTextBoxId = null;
                // Restore touch-action so iPad can scroll PDF again
                textBoxEl.style.touchAction = '';
                // Restore textarea after drag
                if (textareaEl) {
                    textareaEl.removeAttribute('readonly');
                    textareaEl.style.pointerEvents = '';
                }
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startTextBoxDrag = function (ev, textBoxId) {
            ev.preventDefault();
            ev.stopPropagation();
            var tb = this.textBoxes.find(function (t) { return t.id === textBoxId; });
            if (!tb)
                return;
            this.activeTextBoxId = textBoxId;
            this.startDrag(ev, textBoxId);
        };
        PdfAnnotatorModalComponent.prototype.onTextBoxInput = function (event, tb) {
            var textarea = event.target;
            this.resizeTextBox(tb, textarea);
        };
        PdfAnnotatorModalComponent.prototype.resizeTextBox = function (tb, textarea) {
            var _a;
            if (!textarea) {
                var el = document.querySelector("[data-tbid=\"" + tb.id + "\"] textarea");
                if (!el)
                    return;
                textarea = el;
            }
            var lines = tb.text.split('\n');
            var maxLineWidthPx = 30;
            var measureSpan = document.createElement('span');
            measureSpan.style.cssText = "position: absolute; visibility: hidden; white-space: pre; font-family: '" + (tb.fontFamily || 'THSarabunNew') + "', sans-serif; font-size: " + tb.fontSize * this.zoom + "px; font-weight: " + (tb.bold ? 'bold' : 'normal') + "; font-style: " + (tb.italic ? 'italic' : 'normal') + "; letter-spacing: " + ((_a = tb.letterSpacing) !== null && _a !== void 0 ? _a : 0) + "px;";
            lines.forEach(function (line) {
                measureSpan.textContent = line || ' ';
                document.body.appendChild(measureSpan);
                var lineWidth = measureSpan.offsetWidth + 18;
                if (lineWidth > maxLineWidthPx)
                    maxLineWidthPx = lineWidth;
                document.body.removeChild(measureSpan);
            });
            var canvasRect = this.getDragCanvasRect(tb.page);
            if (canvasRect.width > 0 && canvasRect.height > 0) {
                tb.width = Math.min(95, (maxLineWidthPx / canvasRect.width) * 100);
                this.cdr.detectChanges();
                textarea.style.height = '0px';
                var contentHeightPx = textarea.scrollHeight;
                textarea.style.height = contentHeightPx + 'px';
                var minHeightPx = (tb.fontSize * 1.4 * this.zoom) + 6;
                var finalHeightPx = Math.max(contentHeightPx, minHeightPx);
                tb.height = Math.min(95, ((finalHeightPx + 10) / canvasRect.height) * 100);
            }
            this.cdr.detectChanges();
            textarea.style.height = '';
        };
        PdfAnnotatorModalComponent.prototype.onTextBoxFocus = function (id) {
            this.activeTextBoxId = id;
            this.activeObjectId = id;
            this.activeObjectType = 'text';
            var tb = this.textBoxes.find(function (t) { return t.id === id; });
            if (tb) {
                this.textColor = tb.color || this.textColor;
                this.textFontSize = tb.fontSize || this.textFontSize;
            }
        };
        /* ================= TextBox Resize ================= */
        PdfAnnotatorModalComponent.prototype.startResize = function (ev, textBoxId) {
            var _this = this;
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            ev.preventDefault();
            var tb = this.textBoxes.find(function (t) { return t.id === textBoxId; });
            if (!tb)
                return;
            // Sync UI settings
            this.activeTextBoxId = textBoxId;
            this.activeObjectId = textBoxId;
            this.activeObjectType = 'text';
            this.textColor = tb.color || this.textColor;
            this.textFontSize = tb.fontSize || this.textFontSize;
            this.isResizing = true;
            this.resizeTextBoxId = textBoxId;
            var canvasRect = this.getDragCanvasRect(tb.page);
            var startX = ev.clientX;
            var startY = ev.clientY;
            var startW_norm = tb.width;
            var startH_norm = tb.height;
            var move = function (e) {
                e.preventDefault();
                if (!_this.isResizing || !_this.resizeTextBoxId)
                    return;
                var t = _this.textBoxes.find(function (x) { return x.id === _this.resizeTextBoxId; });
                if (!t)
                    return;
                var deltaX_px = e.clientX - startX;
                var deltaY_px = e.clientY - startY;
                t.width = Math.max(5, startW_norm + (deltaX_px / canvasRect.width) * 100);
                t.height = Math.max(2, startH_norm + (deltaY_px / canvasRect.height) * 100);
                _this.cdr.detectChanges();
            };
            var up = function () {
                _this.isResizing = false;
                _this.resizeTextBoxId = null;
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startResizeRight = function (ev, textBoxId) {
            var _this = this;
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            ev.preventDefault();
            var tb = this.textBoxes.find(function (t) { return t.id === textBoxId; });
            if (!tb)
                return;
            this.activeTextBoxId = textBoxId;
            this.activeObjectId = textBoxId;
            this.activeObjectType = 'text';
            var canvasRect = this.getDragCanvasRect(tb.page);
            var startX = ev.clientX;
            var startW = tb.width;
            var move = function (e) {
                e.preventDefault();
                var deltaX = (e.clientX - startX) / canvasRect.width * 100;
                tb.width = Math.max(5, Math.min(95 - tb.x, startW + deltaX));
                _this.cdr.detectChanges();
            };
            var up = function () { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startResizeLeft = function (ev, textBoxId) {
            var _this = this;
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            ev.preventDefault();
            var tb = this.textBoxes.find(function (t) { return t.id === textBoxId; });
            if (!tb)
                return;
            this.activeTextBoxId = textBoxId;
            this.activeObjectId = textBoxId;
            this.activeObjectType = 'text';
            var canvasRect = this.getDragCanvasRect(tb.page);
            var startX = ev.clientX;
            var startTbX = tb.x;
            var startTbW = tb.width;
            var move = function (e) {
                e.preventDefault();
                var deltaX = (e.clientX - startX) / canvasRect.width * 100;
                var newX = Math.max(0, startTbX + deltaX);
                var newW = Math.max(5, startTbW - deltaX);
                if (newX + newW <= 98) {
                    tb.x = newX;
                    tb.width = newW;
                }
                _this.cdr.detectChanges();
            };
            var up = function () { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.removeTextBox = function (textBoxId) {
            this.textBoxes = this.textBoxes.filter(function (t) { return t.id !== textBoxId; });
            if (this.activeTextBoxId === textBoxId)
                this.activeTextBoxId = null;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.clampOneTextBox = function (tb) {
            // Both tb.x, tb.y, tb.width, tb.height are in 0-100 units
            tb.x = Math.max(0, Math.min(tb.x, 100 - tb.width));
            tb.y = Math.max(0, Math.min(tb.y, 100 - tb.height));
        };
        PdfAnnotatorModalComponent.prototype.clampTextBoxesToView = function () {
            var _this = this;
            this.textBoxes.forEach(function (tb) { return _this.clampOneTextBox(tb); });
        };
        /* ================= Image Stamp Operations ================= */
        PdfAnnotatorModalComponent.prototype.triggerImageUpload = function () {
            var _a, _b;
            (_b = (_a = this.fileInputRef) === null || _a === void 0 ? void 0 : _a.nativeElement) === null || _b === void 0 ? void 0 : _b.click();
        };
        PdfAnnotatorModalComponent.prototype.normalizeImageToPng = function (dataUrl) {
            return new Promise(function (resolve) {
                var img = new Image();
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    canvas.width = img.naturalWidth;
                    canvas.height = img.naturalHeight;
                    var ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0);
                    resolve(canvas.toDataURL('image/png'));
                };
                img.onerror = function () { return resolve(dataUrl); }; // fallback: keep original
                img.src = dataUrl;
            });
        };
        PdfAnnotatorModalComponent.prototype.onImageSelected = function (event) {
            var _this = this;
            var input = event.target;
            if (!input.files || !input.files[0])
                return;
            var file = input.files[0];
            var reader = new FileReader();
            reader.onload = function (e) { return __awaiter(_this, void 0, void 0, function () {
                var _a, rawDataUrl, dataUrl, img;
                var _this = this;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            rawDataUrl = (_a = e.target) === null || _a === void 0 ? void 0 : _a.result;
                            return [4 /*yield*/, this.normalizeImageToPng(rawDataUrl)];
                        case 1:
                            dataUrl = _j.sent();
                            img = new Image();
                            img.onload = function () {
                                var w = img.naturalWidth;
                                var h = img.naturalHeight;
                                // Scale display size (px) to at most 30% of canvas width, min 5%
                                var canvasRect = _this.getDragCanvasRect(_this.pageNo);
                                var cw = canvasRect.width || 600;
                                var ch = canvasRect.height || 800;
                                var maxPx = Math.min(cw * 0.4, ch * 0.4);
                                if (w > maxPx || h > maxPx) {
                                    if (w > h) {
                                        h = (h / w) * maxPx;
                                        w = maxPx;
                                    }
                                    else {
                                        w = (w / h) * maxPx;
                                        h = maxPx;
                                    }
                                }
                                _this.imageStamps.push({
                                    id: 'img_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                                    page: _this.pageNo,
                                    x: ((cw / 2 - w / 2) / cw) * 100,
                                    y: ((ch / 2 - h / 2) / ch) * 100,
                                    width: (w / cw) * 100,
                                    height: (h / ch) * 100,
                                    dataUrl: dataUrl
                                });
                                _this.logHistory('image', { type: 'upload' }, _this.pageNo);
                                _this.cdr.detectChanges();
                            };
                            img.src = dataUrl;
                            return [2 /*return*/];
                    }
                });
            }); };
            reader.readAsDataURL(file);
            input.value = ''; // Reset for same file selection
        };
        PdfAnnotatorModalComponent.prototype.startImageDrag = function (e, imgId) {
            var _this = this;
            if (this.toolMode !== 'none')
                return;
            this.closeContextMenu();
            this.activeObjectId = imgId;
            this.activeObjectType = 'image';
            var img = this.imageStamps.find(function (i) { return i.id === imgId; });
            if (!img)
                return;
            this.isDraggingImage = true;
            this.dragImageId = imgId;
            var canvasRect = this.getDragCanvasRect(img.page);
            var startXpx = (img.x / 100) * canvasRect.width;
            var startYpx = (img.y / 100) * canvasRect.height;
            this.dragOffsetX = e.clientX - canvasRect.left - startXpx;
            this.dragOffsetY = e.clientY - canvasRect.top - startYpx;
            var move = function (ev) {
                ev.preventDefault();
                if (!_this.isDraggingImage || !_this.dragImageId)
                    return;
                var i = _this.imageStamps.find(function (x) { return x.id === _this.dragImageId; });
                if (!i)
                    return;
                var mouseXpx = ev.clientX - canvasRect.left - _this.dragOffsetX;
                var mouseYpx = ev.clientY - canvasRect.top - _this.dragOffsetY;
                i.x = (mouseXpx / canvasRect.width) * 100;
                i.y = (mouseYpx / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                _this.isDraggingImage = false;
                _this.dragImageId = null;
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startImageResize = function (ev, imageId, direction) {
            var _this = this;
            if (direction === void 0) { direction = 'se'; }
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            ev.preventDefault();
            var img = this.imageStamps.find(function (i) { return i.id === imageId; });
            if (!img)
                return;
            this.isResizingImage = true;
            this.resizeImageId = imageId;
            var canvasRect = this.getDragCanvasRect(img.page);
            var startX = ev.clientX;
            var startY = ev.clientY;
            var startW_norm = img.width;
            var startH_norm = img.height;
            var startX_norm = img.x;
            var startY_norm = img.y;
            var aspectRatio = startW_norm / startH_norm;
            var move = function (e) {
                e.preventDefault();
                if (!_this.isResizingImage || !_this.resizeImageId)
                    return;
                var i = _this.imageStamps.find(function (x) { return x.id === _this.resizeImageId; });
                if (!i)
                    return;
                var deltaX_norm = ((e.clientX - startX) / canvasRect.width) * 100;
                var deltaY_norm = ((e.clientY - startY) / canvasRect.height) * 100;
                var isShift = e.shiftKey; // Maintain aspect ratio if shift is pressed
                var newW = startW_norm;
                var newH = startH_norm;
                var newX = startX_norm;
                var newY = startY_norm;
                if (direction.includes('e')) {
                    newW = Math.max(2, startW_norm + deltaX_norm);
                }
                if (direction.includes('w')) {
                    newW = Math.max(2, startW_norm - deltaX_norm);
                    newX = startX_norm + (startW_norm - newW);
                }
                if (direction.includes('s')) {
                    newH = Math.max(2, startH_norm + deltaY_norm);
                }
                if (direction.includes('n')) {
                    newH = Math.max(2, startH_norm - deltaY_norm);
                    newY = startY_norm + (startH_norm - newH);
                }
                // Maintain aspect ratio for corner handles or if Shift is held
                if (isShift || direction.length > 1) {
                    if (direction.includes('e') || direction.includes('w')) {
                        newH = newW / aspectRatio;
                        if (direction.includes('n')) {
                            newY = startY_norm + (startH_norm - newH);
                        }
                    }
                    else {
                        newW = newH * aspectRatio;
                        if (direction.includes('w')) {
                            newX = startX_norm + (startW_norm - newW);
                        }
                    }
                }
                i.width = newW;
                i.height = newH;
                i.x = newX;
                i.y = newY;
                _this.cdr.detectChanges();
            };
            var up = function () {
                _this.isResizingImage = false;
                _this.resizeImageId = null;
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.removeImage = function (imageId) {
            this.imageStamps = this.imageStamps.filter(function (i) { return i.id !== imageId; });
            this.cdr.detectChanges();
        };
        /* ================= Stamp Picker ================= */
        PdfAnnotatorModalComponent.prototype.openStampPicker = function () {
            return __awaiter(this, void 0, void 0, function () {
                var response, err_8;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            this.showStampGenerator = false;
                            this.showStampPickerModal = true;
                            this.cdr.detectChanges();
                            if (!this.userId)
                                return [2 /*return*/];
                            this.isLoadingSignatures = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, 4, 5]);
                            return [4 /*yield*/, this.http.post(this.stampsApiUrl, {
                                    aksi: 'load_stamps', userId: this.userId
                                }).toPromise()];
                        case 2:
                            response = _j.sent();
                            if (response === null || response === void 0 ? void 0 : response.success) {
                                this.savedStamps = response.data.map(function (row) { return ({
                                    id: row.id,
                                    name: row.stamp_name,
                                    type: row.stamp_type,
                                    dataUrl: row.stamp_data
                                }); });
                            }
                            return [3 /*break*/, 5];
                        case 3:
                            err_8 = _j.sent();
                            console.error('Error loading stamps', err_8);
                            return [3 /*break*/, 5];
                        case 4:
                            this.isLoadingSignatures = false;
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.closeStampPicker = function () {
            this.showStampPickerModal = false;
            this.showStampGenerator = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.openStampGenerator = function () {
            this.stampGenDocNo = '';
            this.stampGenDate = '';
            this.stampGenTime = '';
            this.stampGenShowDocNo = true;
            this.stampGenShowDate = true;
            this.stampGenShowTime = true;
            this.stampGenNoBorder = false;
            this.showStampGenerator = true;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.cancelStampGenerator = function () {
            this.showStampGenerator = false;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.triggerStampUpload = function () {
            var _a, _b;
            (_b = (_a = this.stampFileInputRef) === null || _a === void 0 ? void 0 : _a.nativeElement) === null || _b === void 0 ? void 0 : _b.click();
        };
        PdfAnnotatorModalComponent.prototype.onStampFileSelected = function (event) {
            var _this = this;
            var input = event.target;
            if (!input.files || !input.files[0])
                return;
            var file = input.files[0];
            var reader = new FileReader();
            reader.onload = function (e) { return __awaiter(_this, void 0, void 0, function () {
                var _a, dataUrl, newStamp, res, err_9;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            dataUrl = (_a = e.target) === null || _a === void 0 ? void 0 : _a.result;
                            newStamp = { id: 'stamp_' + Date.now(), name: file.name.replace(/\.[^/.]+$/, '') || 'ตรายาง', type: 'custom', dataUrl: dataUrl };
                            this.isLoadingSignatures = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 4, 5, 6]);
                            if (!this.userId) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.http.post(this.stampsApiUrl, {
                                    aksi: 'save_stamp', userId: this.userId, stampName: newStamp.name, stampType: newStamp.type, stampData: dataUrl
                                }).toPromise()];
                        case 2:
                            res = _j.sent();
                            if (res === null || res === void 0 ? void 0 : res.success)
                                newStamp.id = res.data.id;
                            _j.label = 3;
                        case 3:
                            this.savedStamps.unshift(newStamp);
                            this.useSavedStamp(newStamp);
                            return [3 /*break*/, 6];
                        case 4:
                            err_9 = _j.sent();
                            console.error('Error uploading stamp', err_9);
                            return [3 /*break*/, 6];
                        case 5:
                            this.isLoadingSignatures = false;
                            input.value = '';
                            this.cdr.detectChanges();
                            return [7 /*endfinally*/];
                        case 6: return [2 /*return*/];
                    }
                });
            }); };
            reader.readAsDataURL(file);
        };
        PdfAnnotatorModalComponent.prototype.useSavedStamp = function (stamp) {
            this.pendingStamp = {
                dataUrl: stamp.dataUrl,
                defaultWidth: stamp.type === 'receive' ? 350 : 250
            };
            this.closeStampPicker();
        };
        PdfAnnotatorModalComponent.prototype.onStampGhostMove = function (ev, pageNum) {
            if (!this.pendingStamp)
                return;
            var rect = ev.currentTarget.getBoundingClientRect();
            this.stampGhostX = ev.clientX - rect.left;
            this.stampGhostY = ev.clientY - rect.top;
            this.stampGhostPage = pageNum;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.onStampGhostClick = function (ev, pageNum) {
            var _this = this;
            if (!this.pendingStamp)
                return;
            ev.stopPropagation();
            var rect = ev.currentTarget.getBoundingClientRect();
            var clickX = ev.clientX - rect.left;
            var clickY = ev.clientY - rect.top;
            var img = new Image();
            img.onload = function () {
                var w = img.width;
                var h = img.height;
                var maxSize = _this.pendingStamp.defaultWidth;
                if (w > maxSize || h > maxSize) {
                    if (w > h) {
                        h = (h / w) * maxSize;
                        w = maxSize;
                    }
                    else {
                        w = (w / h) * maxSize;
                        h = maxSize;
                    }
                }
                var wPct = (w / rect.width) * 100;
                var hPct = (h / rect.height) * 100;
                _this.imageStamps.push({
                    id: 'img_' + Date.now() + '_' + Math.random().toString(16).slice(2),
                    page: pageNum,
                    x: Math.max(0, (clickX / rect.width) * 100 - wPct / 2),
                    y: Math.max(0, (clickY / rect.height) * 100 - hPct / 2),
                    width: wPct,
                    height: hPct,
                    dataUrl: _this.pendingStamp.dataUrl
                });
                _this.logHistory('image', { type: 'stamp' }, pageNum);
                _this.pendingStamp = null;
                _this.cdr.detectChanges();
            };
            img.src = this.pendingStamp.dataUrl;
        };
        PdfAnnotatorModalComponent.prototype.cancelPendingStamp = function () {
            this.pendingStamp = null;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.startStampRename = function (stamp, event) {
            event.stopPropagation();
            this.stampEditingId = stamp.id;
            this.stampEditingName = stamp.name;
            this.cdr.detectChanges();
            setTimeout(function () {
                var input = document.querySelector('.stamp-name-input');
                input === null || input === void 0 ? void 0 : input.select();
            }, 30);
        };
        PdfAnnotatorModalComponent.prototype.saveStampRename = function (stamp) {
            return __awaiter(this, void 0, void 0, function () {
                var name, err_10;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            name = this.stampEditingName.trim();
                            this.stampEditingId = null;
                            this.cdr.detectChanges();
                            if (!name || name === stamp.name)
                                return [2 /*return*/];
                            stamp.name = name;
                            if (!this.userId || (typeof stamp.id === 'string' && stamp.id.startsWith('stamp_')))
                                return [2 /*return*/];
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, , 4]);
                            return [4 /*yield*/, this.http.post(this.stampsApiUrl, {
                                    aksi: 'rename_stamp', id: stamp.id, stampName: name
                                }).toPromise()];
                        case 2:
                            _j.sent();
                            return [3 /*break*/, 4];
                        case 3:
                            err_10 = _j.sent();
                            console.error('Error renaming stamp', err_10);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.deleteSavedStamp = function (stamp, event) {
            return __awaiter(this, void 0, void 0, function () {
                var res, err_11;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            event.stopPropagation();
                            if (typeof stamp.id === 'string' && stamp.id.startsWith('stamp_')) {
                                this.savedStamps = this.savedStamps.filter(function (s) { return s.id !== stamp.id; });
                                this.cdr.detectChanges();
                                return [2 /*return*/];
                            }
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, , 4]);
                            return [4 /*yield*/, this.http.post(this.stampsApiUrl, {
                                    aksi: 'delete_stamp', id: stamp.id
                                }).toPromise()];
                        case 2:
                            res = _j.sent();
                            if (res === null || res === void 0 ? void 0 : res.success) {
                                this.savedStamps = this.savedStamps.filter(function (s) { return s.id !== stamp.id; });
                                this.cdr.detectChanges();
                            }
                            return [3 /*break*/, 4];
                        case 3:
                            err_11 = _j.sent();
                            console.error('Error deleting stamp', err_11);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.drawDottedLine = function (ctx, x1, y, x2, color) {
            ctx.save();
            ctx.setLineDash([4, 8]);
            ctx.strokeStyle = color;
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(x1, y);
            ctx.lineTo(x2, y);
            ctx.stroke();
            ctx.restore();
        };
        PdfAnnotatorModalComponent.prototype.saveGeneratedStamp = function () {
            var e_19, _j;
            var _this = this;
            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');
            if (!ctx)
                return;
            // จำนวนแถว (เลขรับ/วันที่/เวลา) ที่เลือกแสดง — ใช้คำนวณความสูงให้พอดี
            var receiveRows = this.stampGenType === 'receive'
                ? [this.stampGenShowDocNo, this.stampGenShowDate, this.stampGenShowTime].filter(Boolean).length
                : 0;
            if (this.stampGenType === 'receive') {
                canvas.width = 800;
                canvas.height = receiveRows > 0 ? 320 + (receiveRows - 1) * 70 : 200;
            }
            else {
                canvas.width = 800;
                canvas.height = this.stampGenText3 ? 320 : 260;
            }
            var c = this.stampGenColor;
            // วาดเส้นขอบ (เว้นเมื่อผู้ใช้เลือก "ไม่แสดงเส้นขอบ")
            if (!this.stampGenNoBorder) {
                ctx.strokeStyle = c;
                ctx.lineWidth = 10;
                ctx.strokeRect(5, 5, canvas.width - 10, canvas.height - 10);
                ctx.lineWidth = 2;
                ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);
            }
            var innerTop = 20;
            var innerRight = canvas.width - 20;
            var padX = 40;
            var maxTextW = innerRight - 20 - padX * 2;
            var textCX = canvas.width / 2;
            ctx.fillStyle = c;
            ctx.textBaseline = 'top';
            ctx.textAlign = 'center';
            ctx.font = 'bold 50px "THSarabunNew", "Sarabun", Tahoma, sans-serif';
            ctx.fillText(this.stampGenText1 || ' ', textCX, innerTop + 30, maxTextW);
            ctx.font = 'bold 44px "THSarabunNew", "Sarabun", Tahoma, sans-serif';
            ctx.fillText(this.stampGenText2 || ' ', textCX, innerTop + 30 + 60, maxTextW);
            if (this.stampGenType === 'receive') {
                ctx.textAlign = 'left';
                ctx.textBaseline = 'alphabetic';
                ctx.font = '40px "THSarabunNew", "Sarabun", Tahoma, sans-serif';
                var lx = 20 + padX;
                var lineX1 = lx + 100;
                var lineX2 = innerRight - padX;
                // วาดเฉพาะแถวที่เลือกแสดง แล้วเลื่อนตำแหน่งต่อเนื่อง (ไม่เว้นช่องว่าง)
                var rows = [];
                if (this.stampGenShowDocNo)
                    rows.push({ label: 'เลขรับ', value: this.stampGenDocNo });
                if (this.stampGenShowDate)
                    rows.push({ label: 'วันที่', value: this.stampGenDate });
                if (this.stampGenShowTime)
                    rows.push({ label: 'เวลา', value: this.stampGenTime, isTime: true });
                var ry = 280;
                try {
                    for (var rows_1 = __values(rows), rows_1_1 = rows_1.next(); !rows_1_1.done; rows_1_1 = rows_1.next()) {
                        var r = rows_1_1.value;
                        var endX = r.isTime ? lineX2 - 60 : lineX2;
                        ctx.textAlign = 'left';
                        ctx.fillText(r.label, lx, ry);
                        this.drawDottedLine(ctx, lineX1, ry, endX, c);
                        if (r.value) {
                            ctx.fillStyle = '#000000';
                            ctx.fillText(r.value, lineX1 + 20, ry);
                            ctx.fillStyle = c;
                        }
                        if (r.isTime) {
                            ctx.textAlign = 'right';
                            ctx.fillText('น.', lineX2, ry);
                        }
                        ry += 70;
                    }
                }
                catch (e_19_1) { e_19 = { error: e_19_1 }; }
                finally {
                    try {
                        if (rows_1_1 && !rows_1_1.done && (_j = rows_1.return)) _j.call(rows_1);
                    }
                    finally { if (e_19) throw e_19.error; }
                }
            }
            else if (this.stampGenText3) {
                ctx.font = 'bold 40px "THSarabunNew", "Sarabun", Tahoma, sans-serif';
                ctx.fillText(this.stampGenText3, textCX, innerTop + 30 + 130, maxTextW);
            }
            var dataUrl = canvas.toDataURL('image/png');
            var newStamp = { id: 'stamp_' + Date.now(), name: this.stampGenText1 || 'ตราประทับ', type: this.stampGenType, dataUrl: dataUrl };
            if (!this.userId) {
                this.savedStamps.unshift(newStamp);
                this.useSavedStamp(newStamp);
                return;
            }
            this.isLoadingSignatures = true;
            this.http.post(this.stampsApiUrl, {
                aksi: 'save_stamp', userId: this.userId, stampName: newStamp.name, stampType: newStamp.type, stampData: dataUrl
            }).toPromise().then(function (res) {
                if (res === null || res === void 0 ? void 0 : res.success)
                    newStamp.id = res.data.id;
                _this.savedStamps.unshift(newStamp);
                _this.useSavedStamp(newStamp);
            }).catch(function (err) {
                console.error('Error saving stamp', err);
            }).finally(function () {
                _this.isLoadingSignatures = false;
                _this.cdr.detectChanges();
            });
        };
        /* ================= Signature Pad ================= */
        PdfAnnotatorModalComponent.prototype.openSignaturePad = function () {
            var _this = this;
            this.showSignaturePad = true;
            this.signaturePoints = [];
            this.signatureStrokes = [];
            this.sigMode = 'draw';
            this.typedText = '';
            setTimeout(function () {
                _this.initSignatureCanvas();
            }, 100);
        };
        PdfAnnotatorModalComponent.prototype.closeSignaturePad = function () {
            this.showSignaturePad = false;
            this.signaturePoints = [];
            this.signatureStrokes = [];
            this.sigMode = 'draw';
            this.typedText = '';
        };
        PdfAnnotatorModalComponent.prototype.setSignaturePenColor = function (color) {
            this.signaturePenColor = color;
        };
        PdfAnnotatorModalComponent.prototype.changeSignaturePenSize = function (delta) {
            var newSize = this.signaturePenSize + delta;
            if (newSize >= 1 && newSize <= 10) {
                this.signaturePenSize = newSize;
            }
        };
        PdfAnnotatorModalComponent.prototype.switchSigMode = function (mode) {
            var _this = this;
            this.sigMode = mode;
            if (mode === 'draw') {
                this.typedText = '';
                this.signatureStrokes = [];
                this.signaturePoints = [];
                setTimeout(function () { return _this.initSignatureCanvas(); }, 50);
            }
            else {
                setTimeout(function () { return _this.renderTypedCanvas(); }, 50);
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.onTypedInput = function () {
            this.renderTypedCanvas();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.pickTypedFont = function (index) {
            this.typedFontIndex = index;
            this.renderTypedCanvas();
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.renderTypedCanvas = function () {
            var _a;
            var canvas = (_a = this.signatureCanvasRef) === null || _a === void 0 ? void 0 : _a.nativeElement;
            if (!canvas)
                return;
            if (canvas.width <= 1) {
                var container = canvas.parentElement;
                var cStyle = container ? getComputedStyle(container) : null;
                var padH = cStyle ? parseFloat(cStyle.paddingLeft) + parseFloat(cStyle.paddingRight) : 0;
                var w_1 = container ? Math.max(200, container.clientWidth - padH - 4) : 400;
                var dpr_1 = Math.min(window.devicePixelRatio || 1, 2);
                canvas.width = Math.floor(w_1 * dpr_1);
                canvas.height = Math.floor((w_1 / 2) * dpr_1);
                canvas.style.width = w_1 + 'px';
                canvas.style.height = (w_1 / 2) + 'px';
            }
            var ctx = canvas.getContext('2d');
            if (!ctx)
                return;
            var dpr = Math.min(window.devicePixelRatio || 1, 2);
            var w = canvas.width / dpr;
            var h = canvas.height / dpr;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.clearRect(0, 0, w, h);
            ctx.save();
            ctx.setLineDash([6, 4]);
            ctx.strokeStyle = '#d1d5db';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(20, h * 0.7);
            ctx.lineTo(w - 20, h * 0.7);
            ctx.stroke();
            ctx.restore();
            if (!this.typedText)
                return;
            var font = this.typedFontOptions[this.typedFontIndex];
            var fontSize = Math.round(h * 0.4);
            ctx.font = font.style + " " + font.weight + " " + fontSize + "px " + font.family;
            ctx.fillStyle = this.signaturePenColor;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'alphabetic';
            ctx.fillText(this.typedText, w / 2, h * 0.65);
        };
        PdfAnnotatorModalComponent.prototype.initSignatureCanvas = function () {
            var _a;
            var canvas = (_a = this.signatureCanvasRef) === null || _a === void 0 ? void 0 : _a.nativeElement;
            if (!canvas)
                return;
            var container = canvas.parentElement;
            var cStyle = container ? getComputedStyle(container) : null;
            var padH = cStyle ? parseFloat(cStyle.paddingLeft) + parseFloat(cStyle.paddingRight) : 0;
            var containerWidth = container ? Math.max(200, container.clientWidth - padH - 4) : 400;
            var dpr = Math.min(window.devicePixelRatio || 1, 2);
            canvas.width = Math.floor(containerWidth * dpr);
            canvas.height = Math.floor((containerWidth / 2) * dpr);
            canvas.style.width = containerWidth + 'px';
            canvas.style.height = (containerWidth / 2) + 'px';
            this.signatureCtx = canvas.getContext('2d');
            if (this.signatureCtx) {
                this.signatureCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
                this.signatureCtx.strokeStyle = this.signaturePenColor;
                this.signatureCtx.lineWidth = this.signaturePenSize;
                this.signatureCtx.lineCap = 'round';
                this.signatureCtx.lineJoin = 'round';
            }
            // Remove old listeners first (prevents duplicates)
            canvas.removeEventListener('pointerdown', this.boundOnSigStart);
            canvas.removeEventListener('pointermove', this.boundOnSigMove);
            canvas.removeEventListener('pointerup', this.boundOnSigEnd);
            canvas.removeEventListener('pointerleave', this.boundOnSigEnd);
            this.boundOnSigStart = this.onSignatureStart.bind(this);
            this.boundOnSigMove = this.onSignatureMove.bind(this);
            this.boundOnSigEnd = this.onSignatureEnd.bind(this);
            canvas.addEventListener('pointerdown', this.boundOnSigStart);
            canvas.addEventListener('pointermove', this.boundOnSigMove);
            canvas.addEventListener('pointerup', this.boundOnSigEnd);
            canvas.addEventListener('pointerleave', this.boundOnSigEnd);
        };
        PdfAnnotatorModalComponent.prototype.getSignaturePos = function (e) {
            var canvas = this.signatureCanvasRef.nativeElement;
            var rect = canvas.getBoundingClientRect();
            return {
                x: (e.clientX - rect.left),
                y: (e.clientY - rect.top)
            };
        };
        PdfAnnotatorModalComponent.prototype.onSignatureStart = function (e) {
            e.preventDefault();
            this.isDrawingSignature = true;
            var pos = this.getSignaturePos(e);
            this.signaturePoints = [pos];
        };
        PdfAnnotatorModalComponent.prototype.onSignatureMove = function (e) {
            if (!this.isDrawingSignature || !this.signatureCtx)
                return;
            e.preventDefault();
            var pos = this.getSignaturePos(e);
            this.signaturePoints.push(pos);
            // Redraw everything for smooth Bezier rendering
            this.redrawSignatureCanvas();
        };
        PdfAnnotatorModalComponent.prototype.onSignatureEnd = function (e) {
            if (!this.isDrawingSignature)
                return;
            this.isDrawingSignature = false;
            if (this.signaturePoints.length >= 2) {
                this.signatureStrokes.push({
                    points: __spreadArray([], __read(this.signaturePoints)),
                    color: this.signaturePenColor,
                    size: this.signaturePenSize
                });
            }
            this.signaturePoints = [];
        };
        PdfAnnotatorModalComponent.prototype.redrawSignatureCanvas = function () {
            var e_20, _j;
            var _a;
            var canvas = (_a = this.signatureCanvasRef) === null || _a === void 0 ? void 0 : _a.nativeElement;
            if (!canvas || !this.signatureCtx)
                return;
            var ctx = this.signatureCtx;
            var dpr = Math.min(window.devicePixelRatio || 1, 2);
            var w = canvas.width / dpr;
            var h = canvas.height / dpr;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.clearRect(0, 0, w, h);
            // Draw guide line at ~70% height
            ctx.save();
            ctx.setLineDash([6, 4]);
            ctx.strokeStyle = '#d1d5db';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(20, h * 0.7);
            ctx.lineTo(w - 20, h * 0.7);
            ctx.stroke();
            ctx.restore();
            try {
                // Draw all saved strokes
                for (var _k = __values(this.signatureStrokes), _l = _k.next(); !_l.done; _l = _k.next()) {
                    var stroke = _l.value;
                    this.drawBezierStroke(ctx, stroke.points, stroke.color, stroke.size);
                }
            }
            catch (e_20_1) { e_20 = { error: e_20_1 }; }
            finally {
                try {
                    if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                }
                finally { if (e_20) throw e_20.error; }
            }
            // Draw current active stroke
            if (this.signaturePoints.length >= 2) {
                this.drawBezierStroke(ctx, this.signaturePoints, this.signaturePenColor, this.signaturePenSize);
            }
        };
        PdfAnnotatorModalComponent.prototype.drawBezierStroke = function (ctx, points, color, size, scale) {
            if (scale === void 0) { scale = 1; }
            if (points.length < 2)
                return;
            ctx.strokeStyle = color;
            ctx.lineWidth = size * scale;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(points[0].x * scale, points[0].y * scale);
            if (points.length === 2) {
                ctx.lineTo(points[1].x * scale, points[1].y * scale);
            }
            else {
                // Quadratic Bezier smoothing through midpoints
                for (var i = 1; i < points.length - 1; i++) {
                    var midX = (points[i].x + points[i + 1].x) / 2 * scale;
                    var midY = (points[i].y + points[i + 1].y) / 2 * scale;
                    ctx.quadraticCurveTo(points[i].x * scale, points[i].y * scale, midX, midY);
                }
                // Connect to last point
                var last = points[points.length - 1];
                ctx.lineTo(last.x * scale, last.y * scale);
            }
            ctx.stroke();
        };
        PdfAnnotatorModalComponent.prototype.clearSignaturePad = function () {
            this.signaturePoints = [];
            this.signatureStrokes = [];
            this.redrawSignatureCanvas();
        };
        /** Render strokes at high resolution on an offscreen canvas and auto-crop */
        PdfAnnotatorModalComponent.prototype.trimSignatureCanvas = function () {
            var e_21, _j;
            var _a;
            var srcCanvas = (_a = this.signatureCanvasRef) === null || _a === void 0 ? void 0 : _a.nativeElement;
            if (!srcCanvas)
                return '';
            var cssW = srcCanvas.clientWidth || 400;
            var cssH = srcCanvas.clientHeight || 200;
            var exportScale = 8;
            var offW = Math.floor(cssW * exportScale);
            var offH = Math.floor(cssH * exportScale);
            var offCanvas = document.createElement('canvas');
            offCanvas.width = offW;
            offCanvas.height = offH;
            var ctx = offCanvas.getContext('2d');
            ctx.clearRect(0, 0, offW, offH);
            if (this.sigMode === 'type') {
                // Render typed text at high resolution
                var font = this.typedFontOptions[this.typedFontIndex];
                var fontSize = Math.round(cssH * 0.4 * exportScale);
                ctx.font = font.style + " " + font.weight + " " + fontSize + "px " + font.family;
                ctx.fillStyle = this.signaturePenColor;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'alphabetic';
                ctx.fillText(this.typedText, offW / 2, offH * 0.65);
            }
            else {
                ctx.lineCap = 'round';
                ctx.lineJoin = 'round';
                try {
                    for (var _k = __values(this.signatureStrokes), _l = _k.next(); !_l.done; _l = _k.next()) {
                        var stroke = _l.value;
                        if (stroke.points.length < 2)
                            continue;
                        this.drawBezierStroke(ctx, stroke.points, stroke.color, stroke.size, exportScale);
                    }
                }
                catch (e_21_1) { e_21 = { error: e_21_1 }; }
                finally {
                    try {
                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                    }
                    finally { if (e_21) throw e_21.error; }
                }
                if (this.signaturePoints.length >= 2) {
                    this.drawBezierStroke(ctx, this.signaturePoints, this.signaturePenColor, this.signaturePenSize, exportScale);
                }
            }
            // Auto-crop to content bounds
            var imgData = ctx.getImageData(0, 0, offW, offH);
            var data = imgData.data, width = imgData.width, height = imgData.height;
            var top = height, left = width, right = 0, bottom = 0;
            for (var y = 0; y < height; y++) {
                for (var x = 0; x < width; x++) {
                    var alpha = data[(y * width + x) * 4 + 3];
                    if (alpha > 10) {
                        if (y < top)
                            top = y;
                        if (y > bottom)
                            bottom = y;
                        if (x < left)
                            left = x;
                        if (x > right)
                            right = x;
                    }
                }
            }
            // No content found
            if (top > bottom || left > right)
                return offCanvas.toDataURL('image/png');
            // Add padding
            var pad = Math.round(4 * exportScale);
            top = Math.max(0, top - pad);
            left = Math.max(0, left - pad);
            bottom = Math.min(height - 1, bottom + pad);
            right = Math.min(width - 1, right + pad);
            var trimW = right - left + 1;
            var trimH = bottom - top + 1;
            var trimCanvas = document.createElement('canvas');
            trimCanvas.width = trimW;
            trimCanvas.height = trimH;
            var trimCtx = trimCanvas.getContext('2d');
            trimCtx.drawImage(offCanvas, left, top, trimW, trimH, 0, 0, trimW, trimH);
            return trimCanvas.toDataURL('image/png');
        };
        PdfAnnotatorModalComponent.prototype.saveSignature = function () {
            var _a;
            if (this.sigMode === 'type') {
                if (!this.typedText.trim()) {
                    this.closeSignaturePad();
                    return;
                }
                this.renderTypedCanvas();
                var dataUrl_1 = this.trimSignatureCanvas();
                this.placeSignatureOnCanvas(dataUrl_1);
                this.closeSignaturePad();
                return;
            }
            var canvas = (_a = this.signatureCanvasRef) === null || _a === void 0 ? void 0 : _a.nativeElement;
            var totalPoints = this.signatureStrokes.reduce(function (sum, s) { return sum + s.points.length; }, 0);
            if (!canvas || totalPoints < 2) {
                this.closeSignaturePad();
                return;
            }
            var dataUrl = this.trimSignatureCanvas();
            this.placeSignatureOnCanvas(dataUrl);
            this.closeSignaturePad();
        };
        PdfAnnotatorModalComponent.prototype.startSignatureDrag = function (e, sigId) {
            var _this = this;
            if (this.toolMode !== 'none')
                return;
            this.closeContextMenu();
            this.activeObjectId = sigId;
            this.activeObjectType = 'signature';
            var sig = this.signatureStamps.find(function (s) { return s.id === sigId; });
            if (!sig)
                return;
            var canvasRect = this.getDragCanvasRect(sig.page);
            var startXpx = (sig.x / 100) * canvasRect.width;
            var startYpx = (sig.y / 100) * canvasRect.height;
            var offsetX = e.clientX - canvasRect.left - startXpx;
            var offsetY = e.clientY - canvasRect.top - startYpx;
            var move = function (ev) {
                ev.preventDefault();
                var s = _this.signatureStamps.find(function (x) { return x.id === sigId; });
                if (!s)
                    return;
                var mouseXpx = ev.clientX - canvasRect.left - offsetX;
                var mouseYpx = ev.clientY - canvasRect.top - offsetY;
                s.x = (mouseXpx / canvasRect.width) * 100;
                s.y = (mouseYpx / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startSignatureResize = function (ev, sigId, direction) {
            var _this = this;
            if (direction === void 0) { direction = 'se'; }
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            ev.preventDefault();
            var sig = this.signatureStamps.find(function (s) { return s.id === sigId; });
            if (!sig)
                return;
            var canvasRect = this.getDragCanvasRect(sig.page);
            var startX = ev.clientX;
            var startY = ev.clientY;
            var startW_norm = sig.width;
            var startH_norm = sig.height;
            var startX_norm = sig.x;
            var startY_norm = sig.y;
            var aspectRatio = startW_norm / startH_norm;
            var move = function (e) {
                e.preventDefault();
                var s = _this.signatureStamps.find(function (x) { return x.id === sigId; });
                if (!s)
                    return;
                var deltaX_norm = ((e.clientX - startX) / canvasRect.width) * 100;
                var deltaY_norm = ((e.clientY - startY) / canvasRect.height) * 100;
                var isShift = e.shiftKey;
                var newW = startW_norm;
                var newH = startH_norm;
                var newX = startX_norm;
                var newY = startY_norm;
                if (direction.includes('e')) {
                    newW = Math.max(2, startW_norm + deltaX_norm);
                }
                if (direction.includes('w')) {
                    newW = Math.max(2, startW_norm - deltaX_norm);
                    newX = startX_norm + (startW_norm - newW);
                }
                if (direction.includes('s')) {
                    newH = Math.max(2, startH_norm + deltaY_norm);
                }
                if (direction.includes('n')) {
                    newH = Math.max(2, startH_norm - deltaY_norm);
                    newY = startY_norm + (startH_norm - newH);
                }
                // Maintain aspect ratio for corners or if Shift is held
                if (isShift || direction.length > 1) {
                    if (direction.includes('e') || direction.includes('w')) {
                        newH = newW / aspectRatio;
                        if (direction.includes('n')) {
                            newY = startY_norm + (startH_norm - newH);
                        }
                    }
                    else {
                        newW = newH * aspectRatio;
                        if (direction.includes('w')) {
                            newX = startX_norm + (startW_norm - newW);
                        }
                    }
                }
                s.width = newW;
                s.height = newH;
                s.x = newX;
                s.y = newY;
                _this.cdr.detectChanges();
            };
            var up = function () {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.removeSignature = function (sigId) {
            this.signatureStamps = this.signatureStamps.filter(function (s) { return s.id !== sigId; });
            this.cdr.detectChanges();
        };
        /* ================= Saved Signatures (Database) ================= */
        // Open signature picker modal
        PdfAnnotatorModalComponent.prototype.openSignaturePickerOrPad = function () {
            var _this = this;
            // If user has saved signatures, show picker
            if (this.savedSignatures.length > 0) {
                this.showSignaturePicker = true;
            }
            else {
                // Otherwise, load from API first
                this.loadSavedSignatures().then(function () {
                    if (_this.savedSignatures.length > 0) {
                        _this.showSignaturePicker = true;
                    }
                    else {
                        // No saved signatures, open draw pad
                        _this.openSignaturePad();
                    }
                });
            }
        };
        PdfAnnotatorModalComponent.prototype.closeSignaturePicker = function () {
            this.showSignaturePicker = false;
        };
        // Load saved signatures from API
        PdfAnnotatorModalComponent.prototype.loadSavedSignatures = function () {
            return __awaiter(this, void 0, void 0, function () {
                var response, err_12;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.userId) {
                                console.warn('userId is not set, cannot load signatures');
                                return [2 /*return*/];
                            }
                            this.isLoadingSignatures = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, 4, 5]);
                            return [4 /*yield*/, this.http.post(this.signaturesApiUrl, {
                                    aksi: 'get_signatures',
                                    user_id: this.userId
                                }).toPromise()];
                        case 2:
                            response = _j.sent();
                            if (response === null || response === void 0 ? void 0 : response.success) {
                                this.savedSignatures = response.signatures || [];
                            }
                            else {
                                console.error('Failed to load signatures:', response === null || response === void 0 ? void 0 : response.msg);
                            }
                            return [3 /*break*/, 5];
                        case 3:
                            err_12 = _j.sent();
                            console.error('Error loading signatures:', err_12);
                            return [3 /*break*/, 5];
                        case 4:
                            this.isLoadingSignatures = false;
                            return [7 /*endfinally*/];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        // Save current signature to database
        PdfAnnotatorModalComponent.prototype.saveSignatureToDatabase = function (signatureName) {
            var _a;
            return __awaiter(this, void 0, void 0, function () {
                var canvas, totalPoints, dataUrl, response, err_13;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (this.sigMode === 'type') {
                                if (!this.typedText.trim())
                                    return [2 /*return*/];
                                this.renderTypedCanvas();
                            }
                            else {
                                canvas = (_a = this.signatureCanvasRef) === null || _a === void 0 ? void 0 : _a.nativeElement;
                                totalPoints = this.signatureStrokes.reduce(function (sum, s) { return sum + s.points.length; }, 0);
                                if (!canvas || totalPoints < 2)
                                    return [2 /*return*/];
                            }
                            if (!this.userId) {
                                console.warn('userId is not set, cannot save signature');
                                this.saveSignature();
                                return [2 /*return*/];
                            }
                            dataUrl = this.trimSignatureCanvas();
                            this.isLoadingSignatures = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, 4, 5]);
                            return [4 /*yield*/, this.http.post(this.signaturesApiUrl, {
                                    aksi: 'save_signature',
                                    user_id: this.userId,
                                    signature_name: signatureName || '',
                                    signature_data: dataUrl
                                }).toPromise()];
                        case 2:
                            response = _j.sent();
                            if (response === null || response === void 0 ? void 0 : response.success) {
                                // Add to local list
                                this.savedSignatures.push({
                                    id: response.id,
                                    user_id: this.userId,
                                    signature_name: response.signature_name,
                                    signature_data: dataUrl,
                                    is_default: this.savedSignatures.length === 0,
                                    created_at: new Date().toISOString(),
                                    updated_at: new Date().toISOString()
                                });
                                // Also place the signature on canvas
                                this.placeSignatureOnCanvas(dataUrl);
                            }
                            else {
                                console.error('Failed to save signature:', response === null || response === void 0 ? void 0 : response.msg);
                                // Fallback: just use locally
                                this.saveSignature();
                            }
                            return [3 /*break*/, 5];
                        case 3:
                            err_13 = _j.sent();
                            console.error('Error saving signature:', err_13);
                            this.saveSignature();
                            return [3 /*break*/, 5];
                        case 4:
                            this.isLoadingSignatures = false;
                            this.closeSignaturePad();
                            return [7 /*endfinally*/];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        // Use a saved signature from the list
        PdfAnnotatorModalComponent.prototype.useSavedSignature = function (sig) {
            this.placeSignatureOnCanvas(sig.signature_data);
            this.closeSignaturePicker();
        };
        PdfAnnotatorModalComponent.prototype.presentToast = function (msg) {
            return __awaiter(this, void 0, void 0, function () {
                var toast;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0: return [4 /*yield*/, this.toastCtrl.create({
                                message: msg,
                                duration: 2000,
                                position: 'top'
                            })];
                        case 1:
                            toast = _j.sent();
                            toast.present();
                            return [2 /*return*/];
                    }
                });
            });
        };
        // Place signature image on canvas (Starts placement mode)
        PdfAnnotatorModalComponent.prototype.placeSignatureOnCanvas = function (dataUrl) {
            this.pendingSignatureDataUrl = dataUrl;
            this.toolMode = 'signature';
            this.updateCursor();
            this.presentToast('คลิกที่ PDF เพื่อวางลายเซ็น');
        };
        // Delete saved signature from database
        PdfAnnotatorModalComponent.prototype.deleteSavedSignature = function (sig, event) {
            return __awaiter(this, void 0, void 0, function () {
                var response, err_14;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (event) {
                                event.stopPropagation();
                            }
                            if (!this.userId)
                                return [2 /*return*/];
                            this.isLoadingSignatures = true;
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, 4, 5]);
                            return [4 /*yield*/, this.http.post(this.signaturesApiUrl, {
                                    aksi: 'delete_signature',
                                    id: sig.id,
                                    user_id: this.userId
                                }).toPromise()];
                        case 2:
                            response = _j.sent();
                            if (response === null || response === void 0 ? void 0 : response.success) {
                                this.savedSignatures = this.savedSignatures.filter(function (s) { return s.id !== sig.id; });
                            }
                            else {
                                console.error('Failed to delete signature:', response === null || response === void 0 ? void 0 : response.msg);
                            }
                            return [3 /*break*/, 5];
                        case 3:
                            err_14 = _j.sent();
                            console.error('Error deleting signature:', err_14);
                            return [3 /*break*/, 5];
                        case 4:
                            this.isLoadingSignatures = false;
                            return [7 /*endfinally*/];
                        case 5: return [2 /*return*/];
                    }
                });
            });
        };
        // Set signature as default
        PdfAnnotatorModalComponent.prototype.setDefaultSignature = function (sig, event) {
            return __awaiter(this, void 0, void 0, function () {
                var response, err_15;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (event) {
                                event.stopPropagation();
                            }
                            if (!this.userId)
                                return [2 /*return*/];
                            _j.label = 1;
                        case 1:
                            _j.trys.push([1, 3, , 4]);
                            return [4 /*yield*/, this.http.post(this.signaturesApiUrl, {
                                    aksi: 'set_default',
                                    id: sig.id,
                                    user_id: this.userId
                                }).toPromise()];
                        case 2:
                            response = _j.sent();
                            if (response === null || response === void 0 ? void 0 : response.success) {
                                // Update local list
                                this.savedSignatures.forEach(function (s) {
                                    s.is_default = (s.id === sig.id);
                                });
                            }
                            return [3 /*break*/, 4];
                        case 3:
                            err_15 = _j.sent();
                            console.error('Error setting default:', err_15);
                            return [3 /*break*/, 4];
                        case 4: return [2 /*return*/];
                    }
                });
            });
        };
        // Open signature pad from picker (to draw new one)
        PdfAnnotatorModalComponent.prototype.openSignaturePadFromPicker = function () {
            this.closeSignaturePicker();
            this.openSignaturePad();
        };
        // Trigger file input for signature upload
        PdfAnnotatorModalComponent.prototype.triggerSignatureUpload = function () {
            var _a, _b;
            (_b = (_a = this.signatureFileInputRef) === null || _a === void 0 ? void 0 : _a.nativeElement) === null || _b === void 0 ? void 0 : _b.click();
        };
        // Handle signature file selection
        PdfAnnotatorModalComponent.prototype.onSignatureFileSelected = function (event) {
            return __awaiter(this, void 0, void 0, function () {
                var input, file, reader;
                var _this = this;
                return __generator(this, function (_j) {
                    input = event.target;
                    if (!input.files || input.files.length === 0)
                        return [2 /*return*/];
                    file = input.files[0];
                    // Validate file type
                    if (!file.type.startsWith('image/')) {
                        console.error('Invalid file type:', file.type);
                        return [2 /*return*/];
                    }
                    reader = new FileReader();
                    reader.onload = function (e) { return __awaiter(_this, void 0, void 0, function () {
                        var _a, dataUrl, err_16, response, err_17;
                        return __generator(this, function (_j) {
                            switch (_j.label) {
                                case 0:
                                    dataUrl = (_a = e.target) === null || _a === void 0 ? void 0 : _a.result;
                                    if (!dataUrl)
                                        return [2 /*return*/];
                                    // Remove white background
                                    this.isLoadingSignatures = true;
                                    _j.label = 1;
                                case 1:
                                    _j.trys.push([1, 3, , 4]);
                                    return [4 /*yield*/, this.removeWhiteBackground(dataUrl)];
                                case 2:
                                    dataUrl = _j.sent();
                                    return [3 /*break*/, 4];
                                case 3:
                                    err_16 = _j.sent();
                                    console.warn('Could not remove background:', err_16);
                                    return [3 /*break*/, 4];
                                case 4:
                                    if (!this.userId) return [3 /*break*/, 9];
                                    _j.label = 5;
                                case 5:
                                    _j.trys.push([5, 7, , 8]);
                                    return [4 /*yield*/, this.http.post(this.signaturesApiUrl, {
                                            aksi: 'save_signature',
                                            user_id: this.userId,
                                            signature_name: file.name.replace(/\.[^/.]+$/, ''),
                                            signature_data: dataUrl
                                        }).toPromise()];
                                case 6:
                                    response = _j.sent();
                                    if (response === null || response === void 0 ? void 0 : response.success) {
                                        this.savedSignatures.push({
                                            id: response.id,
                                            user_id: this.userId,
                                            signature_name: response.signature_name,
                                            signature_data: dataUrl,
                                            is_default: this.savedSignatures.length === 0,
                                            created_at: new Date().toISOString(),
                                            updated_at: new Date().toISOString()
                                        });
                                    }
                                    return [3 /*break*/, 8];
                                case 7:
                                    err_17 = _j.sent();
                                    console.error('Error uploading signature:', err_17);
                                    return [3 /*break*/, 8];
                                case 8: return [3 /*break*/, 10];
                                case 9:
                                    // No userId, just use directly
                                    this.placeSignatureOnCanvas(dataUrl);
                                    this.closeSignaturePicker();
                                    _j.label = 10;
                                case 10:
                                    this.isLoadingSignatures = false;
                                    // Reset input
                                    input.value = '';
                                    return [2 /*return*/];
                            }
                        });
                    }); };
                    reader.readAsDataURL(file);
                    return [2 /*return*/];
                });
            });
        };
        // Remove white/light background from image, making it transparent
        PdfAnnotatorModalComponent.prototype.removeWhiteBackground = function (dataUrl) {
            return new Promise(function (resolve, reject) {
                var img = new Image();
                img.onload = function () {
                    var canvas = document.createElement('canvas');
                    canvas.width = img.width;
                    canvas.height = img.height;
                    var ctx = canvas.getContext('2d');
                    if (!ctx) {
                        reject('Could not get canvas context');
                        return;
                    }
                    // Draw image
                    ctx.drawImage(img, 0, 0);
                    // Get pixel data
                    var imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                    var data = imageData.data;
                    // Threshold for "white" - pixels with RGB all above this value will be made transparent
                    var threshold = 240;
                    // Also make near-white pixels semi-transparent for smoother edges
                    var softThreshold = 200;
                    for (var i = 0; i < data.length; i += 4) {
                        var r = data[i];
                        var g = data[i + 1];
                        var b = data[i + 2];
                        // Check if pixel is white/near-white
                        if (r > threshold && g > threshold && b > threshold) {
                            // Make fully transparent
                            data[i + 3] = 0;
                        }
                        else if (r > softThreshold && g > softThreshold && b > softThreshold) {
                            // Make semi-transparent for smoother edges
                            var avg = (r + g + b) / 3;
                            var alpha = Math.max(0, 255 - (avg - softThreshold) * (255 / (threshold - softThreshold)));
                            data[i + 3] = Math.min(data[i + 3], alpha);
                        }
                    }
                    // Put modified data back
                    ctx.putImageData(imageData, 0, 0);
                    // Return as PNG (supports transparency)
                    resolve(canvas.toDataURL('image/png'));
                };
                img.onerror = function () { return reject('Failed to load image'); };
                img.src = dataUrl;
            });
        };
        /* ================= PDF Form Fields ================= */
        PdfAnnotatorModalComponent.prototype.enableFormFieldMode = function (type) {
            this.formFieldType = type;
            this.toolMode = 'formfield';
            this.showMarkOptions = true;
            this.updateCursor();
            var labels = { text: 'Text Field', checkbox: 'Checkbox', radio: 'Radio Button' };
            this.presentToast("\u0E04\u0E25\u0E34\u0E01\u0E1A\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E27\u0E32\u0E07 " + labels[type]);
        };
        PdfAnnotatorModalComponent.prototype.getFormFieldsForPage = function (page) {
            return this.pdfFormFields.filter(function (f) { return f.page === page; });
        };
        PdfAnnotatorModalComponent.prototype.removeFormField = function (id) {
            this.pdfFormFields = this.pdfFormFields.filter(function (f) { return f.id !== id; });
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.startFormFieldDrag = function (e, id) {
            var _this = this;
            if (e.button === 2 || e.ctrlKey)
                return;
            var target = e.target;
            if (target.closest('button') || target.classList.contains('resize-handle'))
                return;
            e.stopPropagation();
            e.preventDefault();
            this.activeFormFieldId = id;
            this.activeTextBoxId = null; // ปิดแถบกล่องข้อความเมื่อสลับมาแก้ฟอร์ม
            this.activeObjectId = null;
            this.activeObjectType = null;
            var ff = this.pdfFormFields.find(function (f) { return f.id === id; });
            if (!ff)
                return;
            var canvasRect = this.getDragCanvasRect(ff.page);
            var startXpx = (ff.x / 100) * canvasRect.width;
            var startYpx = (ff.y / 100) * canvasRect.height;
            var offsetX = e.clientX - canvasRect.left - startXpx;
            var offsetY = e.clientY - canvasRect.top - startYpx;
            var move = function (ev) {
                ev.preventDefault();
                var f = _this.pdfFormFields.find(function (x) { return x.id === id; });
                if (!f)
                    return;
                f.x = ((ev.clientX - canvasRect.left - offsetX) / canvasRect.width) * 100;
                f.y = ((ev.clientY - canvasRect.top - offsetY) / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startMarkDrag = function (e, markId) {
            var _this = this;
            if (e.button === 2 || e.ctrlKey)
                return;
            var target = e.target;
            if (target.closest('button') || target.classList.contains('pff-resize-handle'))
                return;
            e.stopPropagation();
            e.preventDefault();
            this.activeObjectId = markId;
            this.activeObjectType = 'image';
            this.cdr.detectChanges();
            var img = this.imageStamps.find(function (i) { return i.id === markId; });
            if (!img)
                return;
            var canvasRect = this.getDragCanvasRect(img.page);
            var offsetX = e.clientX - canvasRect.left - (img.x / 100) * canvasRect.width;
            var offsetY = e.clientY - canvasRect.top - (img.y / 100) * canvasRect.height;
            var move = function (ev) {
                ev.preventDefault();
                var i = _this.imageStamps.find(function (x) { return x.id === markId; });
                if (!i)
                    return;
                i.x = ((ev.clientX - canvasRect.left - offsetX) / canvasRect.width) * 100;
                i.y = ((ev.clientY - canvasRect.top - offsetY) / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.startFormFieldResize = function (e, id, dir) {
            var _this = this;
            e.stopPropagation();
            e.preventDefault();
            var ff = this.pdfFormFields.find(function (f) { return f.id === id; });
            if (!ff)
                return;
            var canvasRect = this.getDragCanvasRect(ff.page);
            var startX = e.clientX;
            var startY = e.clientY;
            var origX = ff.x;
            var origY = ff.y;
            var origW = ff.width;
            var origH = ff.height;
            var move = function (ev) {
                ev.preventDefault();
                var f = _this.pdfFormFields.find(function (x) { return x.id === id; });
                if (!f)
                    return;
                var dx = ((ev.clientX - startX) / canvasRect.width) * 100;
                var dy = ((ev.clientY - startY) / canvasRect.height) * 100;
                if (dir.includes('e'))
                    f.width = Math.max(2, origW + dx);
                if (dir.includes('s'))
                    f.height = Math.max(2, origH + dy);
                if (dir.includes('w')) {
                    f.x = origX + dx;
                    f.width = Math.max(2, origW - dx);
                }
                if (dir.includes('n')) {
                    f.y = origY + dy;
                    f.height = Math.max(2, origH - dy);
                }
                _this.cdr.detectChanges();
            };
            var up = function () {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.changeFormFieldFontSize = function (id, delta) {
            var _a;
            var ff = this.pdfFormFields.find(function (f) { return f.id === id; });
            if (!ff)
                return;
            ff.fontSize = Math.max(6, Math.min(72, ((_a = ff.fontSize) !== null && _a !== void 0 ? _a : 12) + delta));
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.changeFormFieldSize = function (id, delta) {
            var ff = this.pdfFormFields.find(function (f) { return f.id === id; });
            if (!ff)
                return;
            if (ff.type === 'text') {
                ff.height = Math.max(1.5, Math.min(30, ff.height + delta));
            }
            else {
                var s = Math.max(1, Math.min(30, ff.width + delta));
                ff.width = s;
                ff.height = s;
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.toggleFormFieldBorder = function (id) {
            var _a;
            var ff = this.pdfFormFields.find(function (f) { return f.id === id; });
            if (!ff)
                return;
            ff.borderVisible = !((_a = ff.borderVisible) !== null && _a !== void 0 ? _a : true);
            this.cdr.detectChanges();
        };
        /* ================= Quick Mark Stamps ================= */
        PdfAnnotatorModalComponent.prototype.enableMarkMode = function (type) {
            this.markType = type;
            this.toolMode = 'mark';
            this.showMarkOptions = true;
            this.updateCursor();
            var labels = {
                check: '✓ เครื่องหมายถูก', cross: '✗ เครื่องหมายผิด', dot: '● จุด',
            };
            this.presentToast("\u0E04\u0E25\u0E34\u0E01\u0E1A\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E27\u0E32\u0E07 " + labels[type]);
        };
        PdfAnnotatorModalComponent.prototype.setMarkColor = function (color) {
            this.markColor = color;
        };
        PdfAnnotatorModalComponent.prototype.changeMarkSize = function (delta) {
            this.markSize = Math.max(12, Math.min(96, this.markSize + delta));
        };
        PdfAnnotatorModalComponent.prototype.changeMarkStampSize = function (id, delta) {
            var img = this.imageStamps.find(function (i) { return i.id === id; });
            if (!img)
                return;
            var newSize = Math.max(1, Math.min(25, img.width + delta * 0.5));
            img.width = newSize;
            img.height = newSize;
            if (img.markType && img.markColor) {
                img.dataUrl = this.generateMarkDataUrl(img.markType, img.markColor, Math.round(newSize * 10));
            }
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.generateMarkDataUrl = function (type, color, sizePx) {
            var s = Math.round(sizePx);
            var canvas = document.createElement('canvas');
            canvas.width = s;
            canvas.height = s;
            var ctx = canvas.getContext('2d');
            var sw = Math.max(2, s * 0.10);
            ctx.strokeStyle = color;
            ctx.fillStyle = color;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.lineWidth = sw;
            if (type === 'check') {
                ctx.beginPath();
                ctx.moveTo(s * 0.12, s * 0.52);
                ctx.lineTo(s * 0.42, s * 0.82);
                ctx.lineTo(s * 0.88, s * 0.18);
                ctx.stroke();
            }
            else if (type === 'cross') {
                ctx.beginPath();
                ctx.moveTo(s * 0.15, s * 0.15);
                ctx.lineTo(s * 0.85, s * 0.85);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(s * 0.85, s * 0.15);
                ctx.lineTo(s * 0.15, s * 0.85);
                ctx.stroke();
            }
            else {
                ctx.beginPath();
                ctx.arc(s / 2, s / 2, s * 0.38, 0, Math.PI * 2);
                ctx.fill();
            }
            return canvas.toDataURL('image/png');
        };
        /* ================= Date Stamp ================= */
        PdfAnnotatorModalComponent.prototype.addDateStamp = function () {
            this.toolMode = 'date';
            this.updateCursor();
            this.presentToast('คลิกบนเอกสารเพื่อวางวันที่');
        };
        PdfAnnotatorModalComponent.prototype.startDateDrag = function (ev, dateId) {
            var _this = this;
            if (ev.button === 2 || ev.ctrlKey)
                return;
            ev.stopPropagation();
            var target = ev.target;
            if (target.closest('button'))
                return;
            ev.preventDefault();
            var ds = this.dateStamps.find(function (d) { return d.id === dateId; });
            if (!ds)
                return;
            var canvasRect = this.getDragCanvasRect(ds.page);
            var startXpx = (ds.x / 100) * canvasRect.width;
            var startYpx = (ds.y / 100) * canvasRect.height;
            var offsetX = ev.clientX - canvasRect.left - startXpx;
            var offsetY = ev.clientY - canvasRect.top - startYpx;
            var move = function (e) {
                e.preventDefault();
                var d = _this.dateStamps.find(function (x) { return x.id === dateId; });
                if (!d)
                    return;
                var mouseXpx = e.clientX - canvasRect.left - offsetX;
                var mouseYpx = e.clientY - canvasRect.top - offsetY;
                d.x = (mouseXpx / canvasRect.width) * 100;
                d.y = (mouseYpx / canvasRect.height) * 100;
                _this.cdr.detectChanges();
            };
            var up = function () {
                window.removeEventListener('pointermove', move);
                window.removeEventListener('pointerup', up);
            };
            window.addEventListener('pointermove', move);
            window.addEventListener('pointerup', up);
        };
        PdfAnnotatorModalComponent.prototype.removeDateStamp = function (dateId) {
            this.dateStamps = this.dateStamps.filter(function (d) { return d.id !== dateId; });
            this.cdr.detectChanges();
        };
        /* ================= Text Style ================= */
        PdfAnnotatorModalComponent.prototype.toggleBold = function () {
            if (this.activeTextBox) {
                this.activeTextBox.bold = !this.activeTextBox.bold;
                this.tbDefaultBold = this.activeTextBox.bold;
                this.cdr.detectChanges();
                this.saveSettings();
            }
        };
        PdfAnnotatorModalComponent.prototype.toggleItalic = function () {
            if (this.activeTextBox) {
                this.activeTextBox.italic = !this.activeTextBox.italic;
                this.tbDefaultItalic = this.activeTextBox.italic;
                this.cdr.detectChanges();
                this.saveSettings();
            }
        };
        PdfAnnotatorModalComponent.prototype.setAlign = function (a) {
            if (this.activeTextBox) {
                this.activeTextBox.align = a;
                this.tbDefaultAlign = a;
                this.cdr.detectChanges();
                this.saveSettings();
            }
        };
        PdfAnnotatorModalComponent.prototype.setTextColor = function (color) {
            this.textColor = color;
            if (this.activeTextBox) {
                this.activeTextBox.color = color;
                this.cdr.detectChanges();
            }
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.setTbFontFamily = function (tb, family) {
            tb.fontFamily = family;
            this.tbDefaultFontFamily = family;
            this.cdr.detectChanges();
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.setTbOpacity = function (tb, val) {
            tb.opacity = Math.max(0, Math.min(1, +val || 1));
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.setTbRotation = function (tb, val) {
            tb.rotation = +val || 0;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.setTbLetterSpacing = function (tb, val) {
            tb.letterSpacing = +val || 0;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.changeTbLetterSpacing = function (tb, delta) {
            var _a;
            var cur = +((_a = tb.letterSpacing) !== null && _a !== void 0 ? _a : 0);
            tb.letterSpacing = Math.max(-5, Math.min(30, Math.round((cur + delta) * 10) / 10));
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.toggleLsDrop = function (id) {
            this.lsDropOpenId = this.lsDropOpenId === id ? null : id;
            this.cdr.detectChanges();
        };
        PdfAnnotatorModalComponent.prototype.pickLetterSpacing = function (tb, val) {
            tb.letterSpacing = val;
            this.tbDefaultLetterSpacing = val;
            this.lsDropOpenId = null;
            this.cdr.detectChanges();
            this.resizeTextBox(tb);
            this.saveSettings();
        };
        PdfAnnotatorModalComponent.prototype.changeTbLineHeight = function (tb, delta) {
            var _a;
            var cur = +((_a = tb.lineHeight) !== null && _a !== void 0 ? _a : 1.4);
            tb.lineHeight = Math.max(1, Math.min(4, Math.round((cur + delta) * 10) / 10));
            this.tbDefaultLineHeight = tb.lineHeight;
            this.cdr.detectChanges();
            this.saveSettings();
        };
        /* ================= Serialize JSON ================= */
        PdfAnnotatorModalComponent.prototype.exportDrawingJson = function () {
            return JSON.stringify({
                version: 3,
                strokes: this.strokes,
                shapes: this.shapes,
                textBoxes: this.textBoxes,
                imageStamps: this.imageStamps,
                signatureStamps: this.signatureStamps,
                dateStamps: this.dateStamps
            });
        };
        /* ================= Save PDF (ALL PAGES) ================= */
        PdfAnnotatorModalComponent.prototype.renderOverlayToPngBytes = function (pageNo, pdfW, pdfH) {
            var e_22, _j, e_23, _k;
            var strokes = this.strokes[pageNo] || [];
            var shapes = this.shapes[pageNo] || [];
            var off = document.createElement('canvas');
            off.width = Math.floor(pdfW);
            off.height = Math.floor(pdfH);
            var ctx = off.getContext('2d');
            ctx.clearRect(0, 0, off.width, off.height);
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';
            var canvas = this.getAnnotCanvas(pageNo);
            var viewWidth = canvas ? canvas.clientWidth : 800;
            var thicknessScale = (pdfW / Math.max(1, viewWidth)) * 1.5;
            try {
                // Draw strokes
                for (var strokes_1 = __values(strokes), strokes_1_1 = strokes_1.next(); !strokes_1_1.done; strokes_1_1 = strokes_1.next()) {
                    var s = strokes_1_1.value;
                    if (!s.points.length)
                        continue;
                    if (s.isHighlight) {
                        ctx.save();
                        ctx.globalAlpha = 0.4;
                        ctx.globalCompositeOperation = 'multiply';
                    }
                    ctx.strokeStyle = s.color;
                    ctx.beginPath();
                    for (var i = 0; i < s.points.length; i++) {
                        var pt = s.points[i];
                        var x = pt.x * off.width;
                        var y = pt.y * off.height;
                        ctx.lineWidth = this.calcLineWidth(s.size, pt.p) * thicknessScale;
                        if (i === 0)
                            ctx.moveTo(x, y);
                        else
                            ctx.lineTo(x, y);
                    }
                    ctx.stroke();
                    if (s.isHighlight)
                        ctx.restore();
                }
            }
            catch (e_22_1) { e_22 = { error: e_22_1 }; }
            finally {
                try {
                    if (strokes_1_1 && !strokes_1_1.done && (_j = strokes_1.return)) _j.call(strokes_1);
                }
                finally { if (e_22) throw e_22.error; }
            }
            try {
                // Draw shapes
                for (var shapes_1 = __values(shapes), shapes_1_1 = shapes_1.next(); !shapes_1_1.done; shapes_1_1 = shapes_1.next()) {
                    var sh = shapes_1_1.value;
                    var x1 = sh.startX * off.width;
                    var y1 = sh.startY * off.height;
                    var x2 = sh.endX * off.width;
                    var y2 = sh.endY * off.height;
                    ctx.strokeStyle = sh.color;
                    ctx.lineWidth = sh.size * thicknessScale;
                    ctx.beginPath();
                    switch (sh.type) {
                        case 'rect':
                            ctx.rect(x1, y1, x2 - x1, y2 - y1);
                            if (sh.fillColor) {
                                ctx.fillStyle = sh.fillColor;
                                ctx.fill();
                            }
                            break;
                        case 'circle': {
                            var cx = (x1 + x2) / 2;
                            var cy = (y1 + y2) / 2;
                            var rx = Math.abs(x2 - x1) / 2;
                            var ry = Math.abs(y2 - y1) / 2;
                            ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
                            if (sh.fillColor) {
                                ctx.fillStyle = sh.fillColor;
                                ctx.fill();
                            }
                            break;
                        }
                        case 'line':
                            ctx.moveTo(x1, y1);
                            ctx.lineTo(x2, y2);
                            break;
                        case 'arrow': {
                            ctx.moveTo(x1, y1);
                            ctx.lineTo(x2, y2);
                            ctx.stroke();
                            var angle2 = Math.atan2(y2 - y1, x2 - x1);
                            var headLen = 15 * thicknessScale;
                            ctx.beginPath();
                            ctx.moveTo(x2, y2);
                            ctx.lineTo(x2 - headLen * Math.cos(angle2 - Math.PI / 6), y2 - headLen * Math.sin(angle2 - Math.PI / 6));
                            ctx.moveTo(x2, y2);
                            ctx.lineTo(x2 - headLen * Math.cos(angle2 + Math.PI / 6), y2 - headLen * Math.sin(angle2 + Math.PI / 6));
                            break;
                        }
                    }
                    ctx.stroke();
                }
            }
            catch (e_23_1) { e_23 = { error: e_23_1 }; }
            finally {
                try {
                    if (shapes_1_1 && !shapes_1_1.done && (_k = shapes_1.return)) _k.call(shapes_1);
                }
                finally { if (e_23) throw e_23.error; }
            }
            var b64 = off.toDataURL('image/png').split(',')[1];
            return Uint8Array.from(atob(b64), function (c) { return c.charCodeAt(0); });
        };
        // Helper to map visual percentage coordinates to physical PDF coordinates
        PdfAnnotatorModalComponent.prototype.getPdfPlacement = function (vxPercent, vyPercent, vwPercent, vhPercent, pageWidth, pageHeight, pageRotation) {
            var isRot = pageRotation === 90 || pageRotation === 270 || pageRotation === -90 || pageRotation === -270;
            // vW and vH are the dimensions of the visual canvas presented to the user
            // pdf-lib's getSize() gives unrotated dimensions. If it's rotated, the visual width is the page's Height, etc.
            var vW = isRot ? pageHeight : pageWidth;
            var vH = isRot ? pageWidth : pageHeight;
            var vx = (vxPercent / 100) * vW;
            var vy = (vyPercent / 100) * vH;
            var vw = (vwPercent / 100) * vW;
            var vh = (vhPercent / 100) * vH;
            var rotDeg = 0;
            var px = vx;
            var py = pageHeight - vy - vh;
            // The mapping handles drawing onto pdf-lib which uses bottom-left origin.
            if (pageRotation === 90 || pageRotation === -270) {
                // PDF page is rotated 90 CW visually. We draw elements 90 CCW to compensate for viewers rotating it later.
                rotDeg = 90;
                px = vy + vh;
                py = vx;
            }
            else if (pageRotation === 270 || pageRotation === -90) {
                // PDF page is rotated 90 CCW visually (270 CW). We draw elements 90 CW (-90).
                rotDeg = -90;
                px = pageWidth - (vy + vh);
                py = pageHeight - vx;
            }
            else if (pageRotation === 180 || pageRotation === -180) {
                // PDF page is upside down. We draw elements upside down (180).
                rotDeg = 180;
                px = pageWidth - vx;
                py = pageHeight - vy;
            }
            return { x: px, y: py, width: vw, height: vh, rotate: pdfLib.degrees(rotDeg), vW: vW, vH: vH };
        };
        PdfAnnotatorModalComponent.prototype.saveDocument = function () {
            var _a, _b, _c, _d, _e, _f, _g;
            return __awaiter(this, void 0, void 0, function () {
                var pdfDoc, fontkit, fontBytes, thaiFont, boldFontBytes, thaiFontBold, pdfPages, i, pNum, flip, pg, newAngle, annotatedPageNums_1, wmPages, batchSize, _loop_1, this_1, i, form, _j, _k, ff, pgIdx, pdfPage, _l, pgW, pgH, rotAngle, isRotated, vW, vH, fx, fw, fh, fy, borderW, opts, tf, cb, rg, pdfBytes, e_24;
                var e_25, _m;
                var _this = this;
                return __generator(this, function (_o) {
                    switch (_o.label) {
                        case 0:
                            if (!this.basePdfBytes)
                                return [2 /*return*/];
                            this.isLoading = true;
                            this.saveProgress = 1;
                            this.loadingMessage = 'กำลังเตรียมเอกสาร...';
                            this.cdr.detectChanges();
                            _o.label = 1;
                        case 1:
                            _o.trys.push([1, 14, 15, 16]);
                            return [4 /*yield*/, pdfLib.PDFDocument.load(this.basePdfBytes)];
                        case 2:
                            pdfDoc = _o.sent();
                            fontkit = fontkitModule__namespace.default || fontkitModule__namespace;
                            pdfDoc.registerFontkit(fontkit);
                            return [4 /*yield*/, fetch(this.fontUrl).then(function (r) { return r.arrayBuffer(); })];
                        case 3:
                            fontBytes = _o.sent();
                            return [4 /*yield*/, pdfDoc.embedFont(fontBytes)];
                        case 4:
                            thaiFont = _o.sent();
                            return [4 /*yield*/, fetch(this.fontBoldUrl).then(function (r) { return r.arrayBuffer(); })];
                        case 5:
                            boldFontBytes = _o.sent();
                            return [4 /*yield*/, pdfDoc.embedFont(boldFontBytes)];
                        case 6:
                            thaiFontBold = _o.sent();
                            pdfPages = pdfDoc.getPages();
                            // ── Apply page flips BEFORE placing annotations ──
                            // Structurally rotates pages (90° increments) so the exported file matches
                            // what the user sees after flipping. We also update pdfPageRotations so the
                            // annotation-placement loop below maps coordinates into the rotated space.
                            // basePdfBytes stays pristine, so re-baking the same flip on every save is
                            // idempotent (each save reloads the original rotation from the fresh doc).
                            for (i = 0; i < pdfPages.length; i++) {
                                pNum = i + 1;
                                flip = this.pageFlips[pNum] || 0;
                                if (flip !== 0) {
                                    pg = pdfPages[i];
                                    newAngle = (pg.getRotation().angle + flip) % 360;
                                    pg.setRotation(pdfLib.degrees(newAngle));
                                    this.pdfPageRotations.set(pNum, newAngle);
                                }
                            }
                            annotatedPageNums_1 = new Set();
                            Object.keys(this.strokes).forEach(function (p) {
                                var _a;
                                if ((((_a = _this.strokes[+p]) === null || _a === void 0 ? void 0 : _a.length) || 0) > 0)
                                    annotatedPageNums_1.add(+p);
                            });
                            Object.keys(this.shapes).forEach(function (p) {
                                var _a;
                                if ((((_a = _this.shapes[+p]) === null || _a === void 0 ? void 0 : _a.length) || 0) > 0)
                                    annotatedPageNums_1.add(+p);
                            });
                            this.shapeStamps.forEach(function (ss) { return annotatedPageNums_1.add(ss.page); });
                            this.textBoxes.forEach(function (t) { return annotatedPageNums_1.add(t.page); });
                            this.imageStamps.forEach(function (img) { return annotatedPageNums_1.add(img.page); });
                            this.signatureStamps.forEach(function (s) { return annotatedPageNums_1.add(s.page); });
                            this.dateStamps.forEach(function (d) { return annotatedPageNums_1.add(d.page); });
                            // Watermark-enabled pages must be processed even if they have no annotations
                            if (this.watermark.enabled) {
                                wmPages = this.watermark.scope === 'all' ? this.pages : [this.pageNo];
                                wmPages.forEach(function (p) { return annotatedPageNums_1.add(p); });
                            }
                            // Page-number / header-footer pages must also be processed even if empty
                            if (this.pageNumber.enabled) {
                                this.pages.forEach(function (p) {
                                    if (_this.shouldShowPageNum(p))
                                        annotatedPageNums_1.add(p);
                                });
                            }
                            batchSize = pdfPages.length > 100 ? 20 : 5;
                            _loop_1 = function (i) {
                                var pageNum, page, _p, width, height, canvas, cw, rotationAngle, isRot, vW, vH, wmOpacity, wmRotation, wmFontSize, hexColor, r2, g2, b2, textWidth, sX, sY, ty, tx, wmBytes, wmImg, _q, imgW, imgH, sX, sY, ty, tx, wmErr_1, pnSize, pnHex, pnR, pnG, pnB, pnText, pnTextWidth, margin, pnX, pnY, pos, hfSize, hfHex, hfR, hfG, hfB, hfMargin, hText, hWidth, hX, hPos, hY, fText, fWidth, fX, fPos, fY, hasStrokes, hasShapes, overlayPng, overlayImg, placement, toRgb, stampsForPage, stampsForPage_1, stampsForPage_1_1, ss, ssViewW, ssStrokeScale, pdfStrokeW, fillColor, strokeColor, placement, centerPt, pt1, pt2, headLen, angle, textForPage, _loop_2, textForPage_1, textForPage_1_1, tb, imgForPage, imgForPage_1, imgForPage_1_1, img, pngUrl, _r, bytes, embedded, placement, e_26, e_27_1, sigForPage, sigForPage_1, sigForPage_1_1, sig, bytes, embedded, placement, idFontSize, idLines, lineHeight, totalTextHeight, textVisualXPct, textStartYPct, li, lineBaselineVPct, pt, e_28, e_29_1, dateForPage, dateForPage_1, dateForPage_1_1, ds, hex, r, g, b, baselineVPct, pt;
                                var e_30, _s, e_31, _t, e_27, _u, e_29, _v, e_32, _w;
                                return __generator(this, function (_x) {
                                    switch (_x.label) {
                                        case 0:
                                            pageNum = i + 1;
                                            page = pdfPages[i];
                                            if (!(i % batchSize === 0 || i === pdfPages.length - 1)) return [3 /*break*/, 2];
                                            this_1.saveProgress = Math.round(((i + 1) / pdfPages.length) * 60);
                                            this_1.loadingMessage = "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E1B\u0E23\u0E30\u0E21\u0E27\u0E25\u0E1C\u0E25\u0E2B\u0E19\u0E49\u0E32 " + (i + 1) + " / " + pdfPages.length;
                                            this_1.cdr.detectChanges();
                                            return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 0); })];
                                        case 1:
                                            _x.sent();
                                            _x.label = 2;
                                        case 2:
                                            // Skip pages with no annotations entirely
                                            if (!annotatedPageNums_1.has(pageNum))
                                                return [2 /*return*/, "continue"];
                                            _p = page.getSize(), width = _p.width, height = _p.height;
                                            canvas = this_1.getAnnotCanvas(pageNum);
                                            cw = canvas ? canvas.clientWidth : 800;
                                            rotationAngle = (_a = this_1.pdfPageRotations.get(pageNum)) !== null && _a !== void 0 ? _a : page.getRotation().angle;
                                            isRot = rotationAngle === 90 || rotationAngle === 270 || rotationAngle === -90 || rotationAngle === -270;
                                            vW = isRot ? height : width;
                                            vH = isRot ? width : height;
                                            if (!(this_1.watermark.enabled && (this_1.watermark.scope === 'all' || pageNum === this_1.pageNo))) return [3 /*break*/, 10];
                                            wmOpacity = this_1.watermark.opacity / 100;
                                            wmRotation = this_1.watermark.rotation;
                                            if (!(this_1.watermark.type === 'text' && this_1.watermark.text)) return [3 /*break*/, 3];
                                            wmFontSize = this_1.watermark.fontSize || 40;
                                            hexColor = this_1.watermark.color || '#999999';
                                            r2 = parseInt(hexColor.slice(1, 3), 16) / 255;
                                            g2 = parseInt(hexColor.slice(3, 5), 16) / 255;
                                            b2 = parseInt(hexColor.slice(5, 7), 16) / 255;
                                            if (this_1.watermark.mode === 'center') {
                                                textWidth = thaiFont.widthOfTextAtSize(this_1.watermark.text, wmFontSize);
                                                page.drawText(this_1.watermark.text, {
                                                    x: width / 2 - textWidth / 2, y: height / 2, size: wmFontSize, font: thaiFont,
                                                    color: pdfLib.rgb(r2, g2, b2), opacity: wmOpacity, rotate: pdfLib.degrees(-wmRotation)
                                                });
                                            }
                                            else {
                                                sX = this_1.watermark.spacingX || 200;
                                                sY = this_1.watermark.spacingY || 150;
                                                for (ty = -height; ty < height * 2; ty += sY) {
                                                    for (tx = -width; tx < width * 2; tx += sX) {
                                                        page.drawText(this_1.watermark.text, {
                                                            x: tx, y: height - ty, size: wmFontSize, font: thaiFont,
                                                            color: pdfLib.rgb(r2, g2, b2), opacity: wmOpacity, rotate: pdfLib.degrees(-wmRotation)
                                                        });
                                                    }
                                                }
                                            }
                                            return [3 /*break*/, 10];
                                        case 3:
                                            if (!(this_1.watermark.type === 'image' && this_1.watermark.imageDataUrl)) return [3 /*break*/, 10];
                                            _x.label = 4;
                                        case 4:
                                            _x.trys.push([4, 9, , 10]);
                                            wmBytes = Uint8Array.from(atob(this_1.watermark.imageDataUrl.split(',')[1]), function (c) { return c.charCodeAt(0); });
                                            if (!this_1.watermark.imageDataUrl.includes('png')) return [3 /*break*/, 6];
                                            return [4 /*yield*/, pdfDoc.embedPng(wmBytes)];
                                        case 5:
                                            _q = _x.sent();
                                            return [3 /*break*/, 8];
                                        case 6: return [4 /*yield*/, pdfDoc.embedJpg(wmBytes)];
                                        case 7:
                                            _q = _x.sent();
                                            _x.label = 8;
                                        case 8:
                                            wmImg = _q;
                                            imgW = Math.min(wmImg.width, width * 0.4);
                                            imgH = (wmImg.height / wmImg.width) * imgW;
                                            if (this_1.watermark.mode === 'center') {
                                                page.drawImage(wmImg, {
                                                    x: width / 2 - imgW / 2, y: height / 2 - imgH / 2,
                                                    width: imgW, height: imgH, opacity: wmOpacity, rotate: pdfLib.degrees(-wmRotation)
                                                });
                                            }
                                            else {
                                                sX = this_1.watermark.spacingX || 200;
                                                sY = this_1.watermark.spacingY || 150;
                                                for (ty = 0; ty < height; ty += sY) {
                                                    for (tx = 0; tx < width; tx += sX) {
                                                        page.drawImage(wmImg, {
                                                            x: tx, y: height - ty - imgH,
                                                            width: imgW, height: imgH, opacity: wmOpacity, rotate: pdfLib.degrees(-wmRotation)
                                                        });
                                                    }
                                                }
                                            }
                                            return [3 /*break*/, 10];
                                        case 9:
                                            wmErr_1 = _x.sent();
                                            console.warn('Watermark image error', wmErr_1);
                                            return [3 /*break*/, 10];
                                        case 10:
                                            // 0b) Page Numbers
                                            if (this_1.shouldShowPageNum(pageNum)) {
                                                pnSize = this_1.pageNumber.fontSize || 14;
                                                pnHex = this_1.pageNumber.color || '#000000';
                                                pnR = parseInt(pnHex.slice(1, 3), 16) / 255;
                                                pnG = parseInt(pnHex.slice(3, 5), 16) / 255;
                                                pnB = parseInt(pnHex.slice(5, 7), 16) / 255;
                                                pnText = this_1.formatPageNum(pageNum);
                                                pnTextWidth = thaiFont.widthOfTextAtSize(pnText, pnSize);
                                                margin = 30;
                                                pnX = margin;
                                                pnY = margin;
                                                pos = this_1.getEffectivePosition(pageNum);
                                                if (pos.endsWith('right'))
                                                    pnX = width - pnTextWidth - margin;
                                                if (pos.endsWith('center'))
                                                    pnX = (width - pnTextWidth) / 2;
                                                if (pos.startsWith('top'))
                                                    pnY = height - pnSize - margin;
                                                if (pos.startsWith('bottom'))
                                                    pnY = margin;
                                                page.drawText(pnText, {
                                                    x: pnX, y: pnY, size: pnSize, font: thaiFont,
                                                    color: pdfLib.rgb(pnR, pnG, pnB), opacity: 1.0
                                                });
                                            }
                                            // 0c) Header / Footer Text (shown only on pages that have a page number)
                                            if (this_1.pageNumber.enabled && this_1.shouldShowPageNum(pageNum) && (this_1.pageNumber.headerText || this_1.pageNumber.footerText)) {
                                                hfSize = Math.max(this_1.pageNumber.fontSize - 2, 10);
                                                hfHex = this_1.pageNumber.color || '#000000';
                                                hfR = parseInt(hfHex.slice(1, 3), 16) / 255;
                                                hfG = parseInt(hfHex.slice(3, 5), 16) / 255;
                                                hfB = parseInt(hfHex.slice(5, 7), 16) / 255;
                                                hfMargin = 30;
                                                if (this_1.pageNumber.headerText) {
                                                    hText = this_1.pageNumber.headerText;
                                                    hWidth = thaiFont.widthOfTextAtSize(hText, hfSize);
                                                    hX = hfMargin;
                                                    hPos = this_1.pageNumber.headerPosition;
                                                    if (hPos.endsWith('right'))
                                                        hX = width - hWidth - hfMargin;
                                                    if (hPos.endsWith('center'))
                                                        hX = (width - hWidth) / 2;
                                                    hY = height - hfSize - hfMargin;
                                                    page.drawText(hText, {
                                                        x: hX, y: hY, size: hfSize, font: thaiFont,
                                                        color: pdfLib.rgb(hfR, hfG, hfB), opacity: 0.7
                                                    });
                                                }
                                                if (this_1.pageNumber.footerText) {
                                                    fText = this_1.pageNumber.footerText;
                                                    fWidth = thaiFont.widthOfTextAtSize(fText, hfSize);
                                                    fX = hfMargin;
                                                    fPos = this_1.pageNumber.footerPosition;
                                                    if (fPos.endsWith('right'))
                                                        fX = width - fWidth - hfMargin;
                                                    if (fPos.endsWith('center'))
                                                        fX = (width - fWidth) / 2;
                                                    fY = hfMargin;
                                                    page.drawText(fText, {
                                                        x: fX, y: fY, size: hfSize, font: thaiFont,
                                                        color: pdfLib.rgb(hfR, hfG, hfB), opacity: 0.7
                                                    });
                                                }
                                            }
                                            hasStrokes = (((_b = this_1.strokes[pageNum]) === null || _b === void 0 ? void 0 : _b.length) || 0) > 0;
                                            hasShapes = (((_c = this_1.shapes[pageNum]) === null || _c === void 0 ? void 0 : _c.length) || 0) > 0;
                                            if (!(hasStrokes || hasShapes)) return [3 /*break*/, 12];
                                            overlayPng = this_1.renderOverlayToPngBytes(pageNum, vW, vH);
                                            return [4 /*yield*/, pdfDoc.embedPng(overlayPng)];
                                        case 11:
                                            overlayImg = _x.sent();
                                            placement = this_1.getPdfPlacement(0, 0, 100, 100, width, height, rotationAngle);
                                            page.drawImage(overlayImg, { x: placement.x, y: placement.y, width: placement.width, height: placement.height, rotate: placement.rotate });
                                            _x.label = 12;
                                        case 12:
                                            toRgb = function (hex) {
                                                if (!hex || hex === 'none' || hex.includes('rgba'))
                                                    return undefined;
                                                var cleanHex = hex.replace('#', '');
                                                if (cleanHex.length === 3)
                                                    cleanHex = cleanHex.split('').map(function (c) { return c + c; }).join('');
                                                if (cleanHex.length !== 6)
                                                    return undefined;
                                                return pdfLib.rgb(parseInt(cleanHex.substring(0, 2), 16) / 255, parseInt(cleanHex.substring(2, 4), 16) / 255, parseInt(cleanHex.substring(4, 6), 16) / 255);
                                            };
                                            stampsForPage = this_1.shapeStamps.filter(function (ss) { return ss.page === pageNum; });
                                            try {
                                                for (stampsForPage_1 = (e_30 = void 0, __values(stampsForPage)), stampsForPage_1_1 = stampsForPage_1.next(); !stampsForPage_1_1.done; stampsForPage_1_1 = stampsForPage_1.next()) {
                                                    ss = stampsForPage_1_1.value;
                                                    ssViewW = ss.viewWidth && ss.viewWidth > 0 ? ss.viewWidth : Math.max(1, cw);
                                                    ssStrokeScale = vW / ssViewW;
                                                    pdfStrokeW = ss.strokeWidth * ssStrokeScale;
                                                    fillColor = ss.fillColor ? toRgb(ss.fillColor) : undefined;
                                                    strokeColor = (ss.strokeColor && ss.strokeColor !== 'rgba(0,0,0,0)' && ss.strokeWidth > 0) ? toRgb(ss.strokeColor) : undefined;
                                                    placement = this_1.getPdfPlacement(ss.x, ss.y, ss.width, ss.height, width, height, rotationAngle);
                                                    if (ss.type === 'rect') {
                                                        page.drawRectangle({
                                                            x: placement.x,
                                                            y: placement.y,
                                                            width: placement.width,
                                                            height: placement.height,
                                                            rotate: placement.rotate,
                                                            color: fillColor,
                                                            borderColor: strokeColor,
                                                            borderWidth: strokeColor ? pdfStrokeW : undefined
                                                        });
                                                    }
                                                    else if (ss.type === 'circle') {
                                                        centerPt = this_1.getPdfPlacement(ss.x + ss.width / 2, ss.y + ss.height / 2, 0, 0, width, height, rotationAngle);
                                                        page.drawEllipse({
                                                            x: centerPt.x,
                                                            y: centerPt.y,
                                                            xScale: placement.width / 2,
                                                            yScale: placement.height / 2,
                                                            color: fillColor,
                                                            borderColor: strokeColor,
                                                            borderWidth: strokeColor ? pdfStrokeW : undefined
                                                        });
                                                    }
                                                    else if (ss.type === 'line' || ss.type === 'arrow') {
                                                        pt1 = this_1.getPdfPlacement(ss.x + ss.startFracX * ss.width, ss.y + ss.startFracY * ss.height, 0, 0, width, height, rotationAngle);
                                                        pt2 = this_1.getPdfPlacement(ss.x + ss.endFracX * ss.width, ss.y + ss.endFracY * ss.height, 0, 0, width, height, rotationAngle);
                                                        page.drawLine({
                                                            start: { x: pt1.x, y: pt1.y },
                                                            end: { x: pt2.x, y: pt2.y },
                                                            color: strokeColor || pdfLib.rgb(0, 0, 0),
                                                            thickness: strokeColor ? pdfStrokeW : 1
                                                        });
                                                        if (ss.type === 'arrow') {
                                                            headLen = 15 * ssStrokeScale;
                                                            angle = Math.atan2(pt2.y - pt1.y, pt2.x - pt1.x);
                                                            page.drawLine({
                                                                start: { x: pt2.x, y: pt2.y },
                                                                end: { x: pt2.x - headLen * Math.cos(angle - Math.PI / 6), y: pt2.y - headLen * Math.sin(angle - Math.PI / 6) },
                                                                color: strokeColor || pdfLib.rgb(0, 0, 0),
                                                                thickness: strokeColor ? pdfStrokeW : 1
                                                            });
                                                            page.drawLine({
                                                                start: { x: pt2.x, y: pt2.y },
                                                                end: { x: pt2.x - headLen * Math.cos(angle + Math.PI / 6), y: pt2.y - headLen * Math.sin(angle + Math.PI / 6) },
                                                                color: strokeColor || pdfLib.rgb(0, 0, 0),
                                                                thickness: strokeColor ? pdfStrokeW : 1
                                                            });
                                                        }
                                                    }
                                                }
                                            }
                                            catch (e_30_1) { e_30 = { error: e_30_1 }; }
                                            finally {
                                                try {
                                                    if (stampsForPage_1_1 && !stampsForPage_1_1.done && (_s = stampsForPage_1.return)) _s.call(stampsForPage_1);
                                                }
                                                finally { if (e_30) throw e_30.error; }
                                            }
                                            textForPage = this_1.textBoxes.filter(function (t) { return t.page === pageNum; });
                                            _loop_2 = function (tb) {
                                                var e_33, _y, e_34, _z;
                                                if (!tb.text.trim())
                                                    return "continue";
                                                var fontToUse = (tb.bold || tb.italic) ? thaiFontBold : thaiFont;
                                                var colorHex = tb.color || '#0000ff';
                                                var txtColor = toRgb(colorHex) || pdfLib.rgb(0, 0, 1);
                                                var lines = tb.text.split('\n');
                                                var lineHeight = tb.fontSize * ((_d = tb.lineHeight) !== null && _d !== void 0 ? _d : 1.4);
                                                // Compensate for textarea CSS padding (2px top, 4px left) so PDF matches screen
                                                var canvas_1 = this_1.getAnnotCanvas(pageNum);
                                                var canvasCW = canvas_1 ? canvas_1.clientWidth : 800;
                                                var canvasCH = canvas_1 ? canvas_1.clientHeight : 1000;
                                                var padLeftPct = (4 / canvasCW) * 100; // 4px left padding → %
                                                var padTopPct = (2 / canvasCH) * 100; // 2px top padding  → %
                                                // Convert CSS letter-spacing (px on canvas) → PDF points: px * (PDF_pt / canvas_px)
                                                var charSpacing = ((_e = tb.letterSpacing) !== null && _e !== void 0 ? _e : 0) * (vW / canvasCW);
                                                var maxW = (tb.width / 100) * vW;
                                                // shift X by padLeft, shift Y down by padTop
                                                var textStartXPct = tb.x + padLeftPct;
                                                var currentVisualY = ((tb.y + padTopPct) / 100) * vH;
                                                try {
                                                    for (var lines_1 = (e_33 = void 0, __values(lines)), lines_1_1 = lines_1.next(); !lines_1_1.done; lines_1_1 = lines_1.next()) {
                                                        var para = lines_1_1.value;
                                                        if (!para) {
                                                            currentVisualY += lineHeight;
                                                            continue;
                                                        }
                                                        var paraWords = [];
                                                        if (typeof Intl !== 'undefined' && Intl.Segmenter) {
                                                            var segmenter = new Intl.Segmenter('th', { granularity: 'word' });
                                                            paraWords = Array.from(segmenter.segment(para)).map(function (s) { return s.segment; });
                                                        }
                                                        else {
                                                            var parts = para.split(' ');
                                                            for (var i_1 = 0; i_1 < parts.length; i_1++) {
                                                                paraWords.push(parts[i_1]);
                                                                if (i_1 < parts.length - 1)
                                                                    paraWords.push(' ');
                                                            }
                                                        }
                                                        var lineWidthWithSpacing = function (text) { return fontToUse.widthOfTextAtSize(text, tb.fontSize) + charSpacing * text.length; };
                                                        var drawLineText = function (text, pt) {
                                                            if (charSpacing !== 0)
                                                                page.pushOperators(pdfLib.setCharacterSpacing(charSpacing));
                                                            page.drawText(text, { x: pt.x, y: pt.y, size: tb.fontSize, font: fontToUse, color: txtColor, rotate: pt.rotate });
                                                            if (charSpacing !== 0)
                                                                page.pushOperators(pdfLib.setCharacterSpacing(0));
                                                        };
                                                        var line = '';
                                                        try {
                                                            for (var paraWords_1 = (e_34 = void 0, __values(paraWords)), paraWords_1_1 = paraWords_1.next(); !paraWords_1_1.done; paraWords_1_1 = paraWords_1.next()) {
                                                                var word = paraWords_1_1.value;
                                                                var testLine = line + word;
                                                                var textWidth = lineWidthWithSpacing(testLine);
                                                                if (textWidth > maxW && line) {
                                                                    var alignXVisual = (textStartXPct / 100) * vW;
                                                                    var finalLineWidth = lineWidthWithSpacing(line);
                                                                    if (tb.align === 'center')
                                                                        alignXVisual += (maxW / 2) - (finalLineWidth / 2);
                                                                    if (tb.align === 'right')
                                                                        alignXVisual += maxW - finalLineWidth;
                                                                    var baselineVisualY = currentVisualY + (tb.fontSize * 0.95);
                                                                    drawLineText(line, this_1.getPdfPlacement((alignXVisual / vW) * 100, (baselineVisualY / vH) * 100, 0, 0, width, height, rotationAngle));
                                                                    line = word.replace(/^\s+/, '');
                                                                    currentVisualY += lineHeight;
                                                                }
                                                                else {
                                                                    line = testLine;
                                                                }
                                                            }
                                                        }
                                                        catch (e_34_1) { e_34 = { error: e_34_1 }; }
                                                        finally {
                                                            try {
                                                                if (paraWords_1_1 && !paraWords_1_1.done && (_z = paraWords_1.return)) _z.call(paraWords_1);
                                                            }
                                                            finally { if (e_34) throw e_34.error; }
                                                        }
                                                        if (line) {
                                                            var alignXVisual = (textStartXPct / 100) * vW;
                                                            var finalLineWidth = lineWidthWithSpacing(line);
                                                            if (tb.align === 'center')
                                                                alignXVisual += (maxW / 2) - (finalLineWidth / 2);
                                                            if (tb.align === 'right')
                                                                alignXVisual += maxW - finalLineWidth;
                                                            var baselineVisualY = currentVisualY + (tb.fontSize * 0.95);
                                                            drawLineText(line, this_1.getPdfPlacement((alignXVisual / vW) * 100, (baselineVisualY / vH) * 100, 0, 0, width, height, rotationAngle));
                                                            currentVisualY += lineHeight;
                                                        }
                                                    }
                                                }
                                                catch (e_33_1) { e_33 = { error: e_33_1 }; }
                                                finally {
                                                    try {
                                                        if (lines_1_1 && !lines_1_1.done && (_y = lines_1.return)) _y.call(lines_1);
                                                    }
                                                    finally { if (e_33) throw e_33.error; }
                                                }
                                            };
                                            try {
                                                for (textForPage_1 = (e_31 = void 0, __values(textForPage)), textForPage_1_1 = textForPage_1.next(); !textForPage_1_1.done; textForPage_1_1 = textForPage_1.next()) {
                                                    tb = textForPage_1_1.value;
                                                    _loop_2(tb);
                                                }
                                            }
                                            catch (e_31_1) { e_31 = { error: e_31_1 }; }
                                            finally {
                                                try {
                                                    if (textForPage_1_1 && !textForPage_1_1.done && (_t = textForPage_1.return)) _t.call(textForPage_1);
                                                }
                                                finally { if (e_31) throw e_31.error; }
                                            }
                                            imgForPage = this_1.imageStamps.filter(function (img) { return img.page === pageNum; });
                                            _x.label = 13;
                                        case 13:
                                            _x.trys.push([13, 23, 24, 25]);
                                            imgForPage_1 = (e_27 = void 0, __values(imgForPage)), imgForPage_1_1 = imgForPage_1.next();
                                            _x.label = 14;
                                        case 14:
                                            if (!!imgForPage_1_1.done) return [3 /*break*/, 22];
                                            img = imgForPage_1_1.value;
                                            _x.label = 15;
                                        case 15:
                                            _x.trys.push([15, 20, , 21]);
                                            if (!img.dataUrl.startsWith('data:image/png')) return [3 /*break*/, 16];
                                            _r = img.dataUrl;
                                            return [3 /*break*/, 18];
                                        case 16: return [4 /*yield*/, this_1.normalizeImageToPng(img.dataUrl)];
                                        case 17:
                                            _r = _x.sent();
                                            _x.label = 18;
                                        case 18:
                                            pngUrl = _r;
                                            bytes = Uint8Array.from(atob(pngUrl.split(',')[1]), function (c) { return c.charCodeAt(0); });
                                            return [4 /*yield*/, pdfDoc.embedPng(bytes)];
                                        case 19:
                                            embedded = _x.sent();
                                            placement = this_1.getPdfPlacement(img.x, img.y, img.width, img.height, width, height, rotationAngle);
                                            page.drawImage(embedded, { x: placement.x, y: placement.y, width: placement.width, height: placement.height, rotate: placement.rotate });
                                            return [3 /*break*/, 21];
                                        case 20:
                                            e_26 = _x.sent();
                                            console.error(e_26);
                                            return [3 /*break*/, 21];
                                        case 21:
                                            imgForPage_1_1 = imgForPage_1.next();
                                            return [3 /*break*/, 14];
                                        case 22: return [3 /*break*/, 25];
                                        case 23:
                                            e_27_1 = _x.sent();
                                            e_27 = { error: e_27_1 };
                                            return [3 /*break*/, 25];
                                        case 24:
                                            try {
                                                if (imgForPage_1_1 && !imgForPage_1_1.done && (_u = imgForPage_1.return)) _u.call(imgForPage_1);
                                            }
                                            finally { if (e_27) throw e_27.error; }
                                            return [7 /*endfinally*/];
                                        case 25:
                                            sigForPage = this_1.signatureStamps.filter(function (s) { return s.page === pageNum; });
                                            _x.label = 26;
                                        case 26:
                                            _x.trys.push([26, 33, 34, 35]);
                                            sigForPage_1 = (e_29 = void 0, __values(sigForPage)), sigForPage_1_1 = sigForPage_1.next();
                                            _x.label = 27;
                                        case 27:
                                            if (!!sigForPage_1_1.done) return [3 /*break*/, 32];
                                            sig = sigForPage_1_1.value;
                                            _x.label = 28;
                                        case 28:
                                            _x.trys.push([28, 30, , 31]);
                                            bytes = Uint8Array.from(atob(sig.dataUrl.split(',')[1]), function (c) { return c.charCodeAt(0); });
                                            return [4 /*yield*/, pdfDoc.embedPng(bytes)];
                                        case 29:
                                            embedded = _x.sent();
                                            placement = this_1.getPdfPlacement(sig.x, sig.y, sig.width, sig.height, width, height, rotationAngle);
                                            page.drawImage(embedded, { x: placement.x, y: placement.y, width: placement.width, height: placement.height, rotate: placement.rotate });
                                            // Draw Digital ID text to the right of signature (vertically centered)
                                            if (this_1.showDigitalId && (sig.digitalId || sig.signDate)) {
                                                idFontSize = 8;
                                                idLines = [];
                                                if (sig.signDate)
                                                    idLines.push(sig.signDate);
                                                if (sig.signTime)
                                                    idLines.push(sig.signTime);
                                                if (sig.digitalId)
                                                    idLines.push(sig.digitalId);
                                                lineHeight = idFontSize + 2;
                                                totalTextHeight = idLines.length * lineHeight;
                                                textVisualXPct = sig.x + sig.width + (4 / vW * 100);
                                                textStartYPct = sig.y + (sig.height / 2) - ((totalTextHeight / 2) / vH * 100);
                                                for (li = 0; li < idLines.length; li++) {
                                                    lineBaselineVPct = textStartYPct + ((li * lineHeight + idFontSize) / vH * 100);
                                                    pt = this_1.getPdfPlacement(textVisualXPct, lineBaselineVPct, 0, 0, width, height, rotationAngle);
                                                    page.drawText(idLines[li], {
                                                        x: pt.x,
                                                        y: pt.y,
                                                        size: idFontSize,
                                                        font: thaiFont,
                                                        color: pdfLib.rgb(0.2, 0.2, 0.2),
                                                        opacity: 1.0,
                                                        rotate: pt.rotate
                                                    });
                                                }
                                            }
                                            return [3 /*break*/, 31];
                                        case 30:
                                            e_28 = _x.sent();
                                            console.error(e_28);
                                            return [3 /*break*/, 31];
                                        case 31:
                                            sigForPage_1_1 = sigForPage_1.next();
                                            return [3 /*break*/, 27];
                                        case 32: return [3 /*break*/, 35];
                                        case 33:
                                            e_29_1 = _x.sent();
                                            e_29 = { error: e_29_1 };
                                            return [3 /*break*/, 35];
                                        case 34:
                                            try {
                                                if (sigForPage_1_1 && !sigForPage_1_1.done && (_v = sigForPage_1.return)) _v.call(sigForPage_1);
                                            }
                                            finally { if (e_29) throw e_29.error; }
                                            return [7 /*endfinally*/];
                                        case 35:
                                            dateForPage = this_1.dateStamps.filter(function (d) { return d.page === pageNum; });
                                            try {
                                                for (dateForPage_1 = (e_32 = void 0, __values(dateForPage)), dateForPage_1_1 = dateForPage_1.next(); !dateForPage_1_1.done; dateForPage_1_1 = dateForPage_1.next()) {
                                                    ds = dateForPage_1_1.value;
                                                    hex = ds.color.replace('#', '');
                                                    r = parseInt(hex.substring(0, 2), 16) / 255;
                                                    g = parseInt(hex.substring(2, 4), 16) / 255;
                                                    b = parseInt(hex.substring(4, 6), 16) / 255;
                                                    baselineVPct = ds.y + (ds.fontSize / vH * 100);
                                                    pt = this_1.getPdfPlacement(ds.x, baselineVPct, 0, 0, width, height, rotationAngle);
                                                    page.drawText(ds.text, {
                                                        x: pt.x, y: pt.y, size: ds.fontSize, font: thaiFont,
                                                        color: pdfLib.rgb(r, g, b), opacity: 1.0, rotate: pt.rotate
                                                    });
                                                }
                                            }
                                            catch (e_32_1) { e_32 = { error: e_32_1 }; }
                                            finally {
                                                try {
                                                    if (dateForPage_1_1 && !dateForPage_1_1.done && (_w = dateForPage_1.return)) _w.call(dateForPage_1);
                                                }
                                                finally { if (e_32) throw e_32.error; }
                                            }
                                            return [2 /*return*/];
                                    }
                                });
                            };
                            this_1 = this;
                            i = 0;
                            _o.label = 7;
                        case 7:
                            if (!(i < pdfPages.length)) return [3 /*break*/, 10];
                            return [5 /*yield**/, _loop_1(i)];
                        case 8:
                            _o.sent();
                            _o.label = 9;
                        case 9:
                            i++;
                            return [3 /*break*/, 7];
                        case 10:
                            // Bake PDF AcroForm fields (interactive text/checkbox/radio)
                            if (this.pdfFormFields.length > 0) {
                                form = pdfDoc.getForm();
                                try {
                                    for (_j = __values(this.pdfFormFields), _k = _j.next(); !_k.done; _k = _j.next()) {
                                        ff = _k.value;
                                        pgIdx = ff.page - 1;
                                        if (pgIdx < 0 || pgIdx >= pdfPages.length)
                                            continue;
                                        pdfPage = pdfPages[pgIdx];
                                        _l = pdfPage.getSize(), pgW = _l.width, pgH = _l.height;
                                        rotAngle = (_f = this.pdfPageRotations.get(ff.page)) !== null && _f !== void 0 ? _f : pdfPage.getRotation().angle;
                                        isRotated = rotAngle === 90 || rotAngle === 270 || rotAngle === -90 || rotAngle === -270;
                                        vW = isRotated ? pgH : pgW;
                                        vH = isRotated ? pgW : pgH;
                                        fx = (ff.x / 100) * vW;
                                        fw = (ff.width / 100) * vW;
                                        fh = (ff.height / 100) * vH;
                                        fy = pgH - (ff.y / 100) * vH - fh;
                                        borderW = ((_g = ff.borderVisible) !== null && _g !== void 0 ? _g : true) ? 1 : 0;
                                        opts = {
                                            x: fx, y: fy, width: fw, height: fh,
                                            borderWidth: borderW,
                                            borderColor: borderW ? pdfLib.rgb(0, 0, 0) : undefined,
                                            backgroundColor: pdfLib.rgb(1, 1, 1),
                                        };
                                        try {
                                            if (ff.type === 'text') {
                                                tf = form.createTextField(ff.fieldName);
                                                tf.addToPage(pdfPage, opts);
                                                if (ff.fontSize)
                                                    tf.setFontSize(ff.fontSize);
                                            }
                                            else if (ff.type === 'checkbox') {
                                                cb = form.createCheckBox(ff.fieldName);
                                                cb.addToPage(pdfPage, opts);
                                            }
                                            else if (ff.type === 'radio') {
                                                rg = void 0;
                                                try {
                                                    rg = form.getRadioGroup(ff.radioGroupName);
                                                }
                                                catch (_h) {
                                                    rg = form.createRadioGroup(ff.radioGroupName);
                                                }
                                                rg.addOptionToPage(ff.id, pdfPage, opts);
                                            }
                                        }
                                        catch (formErr) {
                                            console.warn('Form field error:', formErr);
                                        }
                                    }
                                }
                                catch (e_25_1) { e_25 = { error: e_25_1 }; }
                                finally {
                                    try {
                                        if (_k && !_k.done && (_m = _j.return)) _m.call(_j);
                                    }
                                    finally { if (e_25) throw e_25.error; }
                                }
                            }
                            this.saveProgress = 61;
                            this.loadingMessage = 'กำลัง Serialize PDF...';
                            this.cdr.detectChanges();
                            return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(resolve, 80); })];
                        case 11:
                            _o.sent();
                            this.revNo += 1;
                            return [4 /*yield*/, pdfDoc.save({ objectsPerTick: 20 })];
                        case 12:
                            pdfBytes = _o.sent();
                            this.lastSavedBlob = new Blob([pdfBytes], { type: 'application/pdf' });
                            // Use original filename if provided, otherwise default to "annotated_rev..."
                            if (this.fileName) {
                                this.lastSavedFileName = this.fileName;
                            }
                            else {
                                this.lastSavedFileName = "annotated_rev" + this.revNo + "_" + Date.now() + ".pdf";
                            }
                            // Create preview using pdf.js to render pages as images
                            return [4 /*yield*/, this.generatePreviewPages()];
                        case 13:
                            // Create preview using pdf.js to render pages as images
                            _o.sent();
                            this.showPreviewOverlay = true;
                            return [3 /*break*/, 16];
                        case 14:
                            e_24 = _o.sent();
                            console.error(e_24);
                            this.presentToast('เกิดข้อผิดพลาดในการบันทึกเอกสาร');
                            return [3 /*break*/, 16];
                        case 15:
                            this.isLoading = false;
                            this.loadingMessage = '';
                            this.saveProgress = 0;
                            return [7 /*endfinally*/];
                        case 16: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.generatePreviewPages = function () {
            return __awaiter(this, void 0, void 0, function () {
                var arrayBuffer, pdfDoc, total, pagesToRender, annotated_1, idx, pageNum, page, scale, viewport, canvas, ctx;
                var _this = this;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.lastSavedBlob)
                                return [2 /*return*/];
                            this.previewPages = [];
                            return [4 /*yield*/, this.lastSavedBlob.arrayBuffer()];
                        case 1:
                            arrayBuffer = _j.sent();
                            return [4 /*yield*/, pdfjsLib__namespace.getDocument({ data: arrayBuffer }).promise];
                        case 2:
                            pdfDoc = _j.sent();
                            total = pdfDoc.numPages;
                            this.previewTotalPages = total;
                            if (total > 50) {
                                annotated_1 = new Set();
                                Object.keys(this.strokes).forEach(function (p) {
                                    var _a;
                                    if ((((_a = _this.strokes[+p]) === null || _a === void 0 ? void 0 : _a.length) || 0) > 0)
                                        annotated_1.add(+p);
                                });
                                Object.keys(this.shapes).forEach(function (p) {
                                    var _a;
                                    if ((((_a = _this.shapes[+p]) === null || _a === void 0 ? void 0 : _a.length) || 0) > 0)
                                        annotated_1.add(+p);
                                });
                                this.shapeStamps.forEach(function (ss) { return annotated_1.add(ss.page); });
                                this.textBoxes.forEach(function (t) { return annotated_1.add(t.page); });
                                this.imageStamps.forEach(function (img) { return annotated_1.add(img.page); });
                                this.signatureStamps.forEach(function (s) { return annotated_1.add(s.page); });
                                this.dateStamps.forEach(function (d) { return annotated_1.add(d.page); });
                                pagesToRender = annotated_1.size > 0 ? Array.from(annotated_1).sort(function (a, b) { return a - b; }) : [1];
                                this.previewIsFiltered = pagesToRender.length < total;
                            }
                            else {
                                pagesToRender = Array.from({ length: total }, function (_, i) { return i + 1; });
                                this.previewIsFiltered = false;
                            }
                            idx = 0;
                            _j.label = 3;
                        case 3:
                            if (!(idx < pagesToRender.length)) return [3 /*break*/, 7];
                            pageNum = pagesToRender[idx];
                            return [4 /*yield*/, pdfDoc.getPage(pageNum)];
                        case 4:
                            page = _j.sent();
                            scale = 1.5;
                            viewport = page.getViewport({ scale: scale });
                            canvas = document.createElement('canvas');
                            ctx = canvas.getContext('2d');
                            canvas.width = viewport.width;
                            canvas.height = viewport.height;
                            return [4 /*yield*/, page.render({ canvasContext: ctx, viewport: viewport }).promise];
                        case 5:
                            _j.sent();
                            this.previewPages.push(canvas.toDataURL('image/png'));
                            // Progress phase 2: generating preview (62–100%)
                            this.saveProgress = 62 + Math.round(((idx + 1) / pagesToRender.length) * 38);
                            this.loadingMessage = "\u0E01\u0E33\u0E25\u0E31\u0E07\u0E2A\u0E23\u0E49\u0E32\u0E07 Preview \u0E2B\u0E19\u0E49\u0E32 " + pageNum + " / " + total;
                            this.cdr.detectChanges();
                            _j.label = 6;
                        case 6:
                            idx++;
                            return [3 /*break*/, 3];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.loadAllPreviewPages = function () {
            return __awaiter(this, void 0, void 0, function () {
                var arrayBuffer, pdfDoc, total, i, page, viewport, canvas, ctx;
                return __generator(this, function (_j) {
                    switch (_j.label) {
                        case 0:
                            if (!this.lastSavedBlob || this.isLoadingAllPreview)
                                return [2 /*return*/];
                            this.isLoadingAllPreview = true;
                            this.previewPages = [];
                            this.cdr.detectChanges();
                            return [4 /*yield*/, this.lastSavedBlob.arrayBuffer()];
                        case 1:
                            arrayBuffer = _j.sent();
                            return [4 /*yield*/, pdfjsLib__namespace.getDocument({ data: arrayBuffer }).promise];
                        case 2:
                            pdfDoc = _j.sent();
                            total = pdfDoc.numPages;
                            i = 1;
                            _j.label = 3;
                        case 3:
                            if (!(i <= total)) return [3 /*break*/, 7];
                            return [4 /*yield*/, pdfDoc.getPage(i)];
                        case 4:
                            page = _j.sent();
                            viewport = page.getViewport({ scale: 1.5 });
                            canvas = document.createElement('canvas');
                            ctx = canvas.getContext('2d');
                            canvas.width = viewport.width;
                            canvas.height = viewport.height;
                            return [4 /*yield*/, page.render({ canvasContext: ctx, viewport: viewport }).promise];
                        case 5:
                            _j.sent();
                            this.previewPages.push(canvas.toDataURL('image/png'));
                            this.cdr.detectChanges();
                            _j.label = 6;
                        case 6:
                            i++;
                            return [3 /*break*/, 3];
                        case 7:
                            this.previewIsFiltered = false;
                            this.isLoadingAllPreview = false;
                            this.cdr.detectChanges();
                            return [2 /*return*/];
                    }
                });
            });
        };
        PdfAnnotatorModalComponent.prototype.confirmSave = function () {
            var e_35, _j;
            if (!this.lastSavedBlob)
                return;
            // Log all signature stamps with Digital ID when confirmed and showDigitalId is enabled
            if (this.showDigitalId) {
                try {
                    for (var _k = __values(this.signatureStamps), _l = _k.next(); !_l.done; _l = _k.next()) {
                        var sig = _l.value;
                        if (sig.digitalId) {
                            var now = new Date();
                            this.logSignatureToDatabase(sig.digitalId, now, sig.page);
                        }
                    }
                }
                catch (e_35_1) { e_35 = { error: e_35_1 }; }
                finally {
                    try {
                        if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                    }
                    finally { if (e_35) throw e_35.error; }
                }
            }
            // Log save to history
            this.logHistory('save', {
                signatures: this.signatureStamps.length,
                textBoxes: this.textBoxes.length,
                drawings: Object.values(this.strokes).reduce(function (s, arr) { return s + arr.length; }, 0),
            }, 0);
            this.unlockOrientation();
            this.saved.emit({ blob: this.lastSavedBlob, fileName: this.lastSavedFileName, revNo: this.revNo });
            this.dismissModal({
                success: true,
                saved: true,
                blob: this.lastSavedBlob,
                fileName: this.lastSavedFileName,
                revNo: this.revNo
            });
        };
        PdfAnnotatorModalComponent.prototype.backToEdit = function () {
            this.showPreviewOverlay = false;
            this.previewUrl = null;
            this.previewPages = [];
        };
        return PdfAnnotatorModalComponent;
    }());
    PdfAnnotatorModalComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'app-pdf-annotator-modal',
                    template: "<ion-header [style.display]=\"showPreviewOverlay ? 'none' : ''\">\n  <ion-toolbar>\n    <!-- <ion-title>PDF Annotator</ion-title> -->\n    <ion-buttons slot=\"end\">\n      <ion-button fill=\"clear\" (click)=\"close()\">\n        <svg-icon name=\"close\"></svg-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"annotator-content\" [scrollY]=\"false\">\n\n  <!-- Loading Spinner Overlay -->\n  <div class=\"loading-overlay\" *ngIf=\"isLoading\">\n    <div class=\"loading-content\" [class.loading-content--progress]=\"saveProgress > 0\">\n\n      <!-- Normal spinner when no save progress -->\n      <ng-container *ngIf=\"saveProgress === 0\">\n        <ion-spinner name=\"crescent\"></ion-spinner>\n        <p class=\"loading-msg\">{{ loadingMessage }}</p>\n      </ng-container>\n\n      <!-- Progress bar UI during save -->\n      <ng-container *ngIf=\"saveProgress > 0\">\n        <div class=\"save-progress-icon\">\n          <svg-icon name=\"document-text-outline\"></svg-icon>\n          <span class=\"save-progress-pct\">{{ saveProgress }}%</span>\n        </div>\n        <div class=\"save-progress-bar-track\">\n          <div class=\"save-progress-bar-fill\" [style.width.%]=\"saveProgress\"\n            [class.save-progress-bar-fill--preview]=\"saveProgress > 61\"\n            [class.save-progress-bar-fill--serializing]=\"saveProgress === 61\"></div>\n        </div>\n        <div class=\"save-progress-phases\">\n          <span [class.active]=\"saveProgress > 0 && saveProgress < 61\">\n            <svg-icon name=\"layers-outline\"></svg-icon> \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01 Annotations\n          </span>\n          <span [class.active]=\"saveProgress === 61\">\n            <svg-icon name=\"archive-outline\"></svg-icon> Serialize PDF\n          </span>\n          <span [class.active]=\"saveProgress > 61\">\n            <svg-icon name=\"image-outline\"></svg-icon> \u0E2A\u0E23\u0E49\u0E32\u0E07 Preview\n          </span>\n        </div>\n        <p class=\"loading-msg\">{{ loadingMessage }}</p>\n      </ng-container>\n\n    </div>\n  </div>\n\n  <!-- New Layout: Top Toolbars + Left Thumbnails + Center Viewer -->\n  <div class=\"annotator-layout-v2\">\n\n    <!-- Top Toolbar Row 1: Zoom & Navigation -->\n    <div class=\"toolbar-row toolbar-row--nav\">\n      <div class=\"toolbar-group\">\n        <button class=\"toolbar-btn\" (click)=\"toggleThumbnails()\" title=\"\u0E41\u0E2A\u0E14\u0E07/\u0E0B\u0E48\u0E2D\u0E19 Thumbnails\">\n          <svg-icon name=\"images-outline\"></svg-icon>\n        </button>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <div class=\"toolbar-group toolbar-group--zoom\">\n        <button class=\"toolbar-btn\" (click)=\"zoomOut()\" [disabled]=\"zoom <= 0.5\">\n          <svg-icon name=\"search-outline\"></svg-icon>\n          <svg-icon name=\"remove-outline\" class=\"zoom-icon\"></svg-icon>\n        </button>\n        <span class=\"toolbar-label\">{{ (zoom * 100) | number:'1.0-0' }}%</span>\n        <button class=\"toolbar-btn\" (click)=\"zoomIn()\" [disabled]=\"zoom >= 3\">\n          <svg-icon name=\"search-outline\"></svg-icon>\n          <svg-icon name=\"add-outline\" class=\"zoom-icon\"></svg-icon>\n        </button>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <div class=\"toolbar-group toolbar-group--pager\">\n        <button class=\"toolbar-btn\" (click)=\"firstPage()\" [disabled]=\"pageNo <= 1\" title=\"\u0E2B\u0E19\u0E49\u0E32\u0E41\u0E23\u0E01\">\n          <svg-icon name=\"play-skip-back\"></svg-icon>\n        </button>\n        <button class=\"toolbar-btn\" (click)=\"prevPage()\" [disabled]=\"pageNo <= 1\" title=\"\u0E2B\u0E19\u0E49\u0E32\u0E01\u0E48\u0E2D\u0E19\">\n          <svg-icon name=\"chevron-back\"></svg-icon>\n        </button>\n        <span class=\"toolbar-label\">\n          {{ pageNo }} / {{ pageCount || '?' }}\n          <span *ngIf=\"loadedUntilPage < pageCount\" class=\"chunk-indicator\"\n            [title]=\"'\u0E42\u0E2B\u0E25\u0E14\u0E41\u0E25\u0E49\u0E27 ' + loadedUntilPage + ' / ' + pageCount + ' \u0E2B\u0E19\u0E49\u0E32'\">\n            <ion-spinner *ngIf=\"isLoadingChunk\" name=\"crescent\" style=\"width:10px;height:10px;\"></ion-spinner>\n            <span *ngIf=\"!isLoadingChunk\">({{ loadedUntilPage }}\u2193)</span>\n          </span>\n        </span>\n        <button class=\"toolbar-btn\" (click)=\"nextPage()\" [disabled]=\"pageNo >= pageCount || isLoadingChunk\" title=\"\u0E2B\u0E19\u0E49\u0E32\u0E16\u0E31\u0E14\u0E44\u0E1B\">\n          <svg-icon name=\"chevron-forward\"></svg-icon>\n        </button>\n        <button class=\"toolbar-btn\" (click)=\"lastPage()\" [disabled]=\"pageNo >= pageCount || isLoadingChunk\" title=\"\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E38\u0E14\u0E17\u0E49\u0E32\u0E22 (\u0E42\u0E2B\u0E25\u0E14\u0E41\u0E25\u0E49\u0E27 {{ loadedUntilPage }} \u0E2B\u0E19\u0E49\u0E32)\">\n          <svg-icon name=\"play-skip-forward\"></svg-icon>\n        </button>\n      </div>\n\n      <!-- Pages per view selector -->\n      <div class=\"toolbar-group toolbar-group--ppv\" title=\"\u0E08\u0E33\u0E19\u0E27\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48\u0E41\u0E2A\u0E14\u0E07\">\n        <svg-icon name=\"layers-outline\" style=\"font-size:15px;color:#64748b;flex-shrink:0\"></svg-icon>\n        <select class=\"ppv-select\" [value]=\"pagesPerChunk\" (change)=\"setPagesPerChunk(+$any($event.target).value)\">\n          <option value=\"5\">5 \u0E2B\u0E19\u0E49\u0E32</option>\n          <option value=\"10\" selected>10 \u0E2B\u0E19\u0E49\u0E32</option>\n          <option value=\"20\">20 \u0E2B\u0E19\u0E49\u0E32</option>\n          <option value=\"50\">50 \u0E2B\u0E19\u0E49\u0E32</option>\n          <option value=\"0\">\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14</option>\n        </select>\n      </div>\n\n      <div class=\"toolbar-spacer\"></div>\n\n      <!-- Insert Blank Page + Delete Page -->\n      <div class=\"tool-item insert-page-tool\">\n        <button class=\"toolbar-btn\" (click)=\"showInsertMenu = !showInsertMenu\" title=\"\u0E41\u0E17\u0E23\u0E01/\u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\">\n          <svg-icon name=\"documents-outline\"></svg-icon>\n          <svg-icon name=\"chevron-down-outline\" class=\"shape-chevron\"></svg-icon>\n        </button>\n\n        <!-- Dropdown -->\n        <div class=\"insert-page-dropdown\" *ngIf=\"showInsertMenu\">\n          <div class=\"insert-page-backdrop\" (click)=\"showInsertMenu = false\"></div>\n          <div class=\"insert-page-menu\">\n\n            <!-- Section: \u0E41\u0E17\u0E23\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E48\u0E32 -->\n            <div class=\"insert-page-title\">\n              <svg-icon name=\"add-circle-outline\"></svg-icon> \u0E41\u0E17\u0E23\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E48\u0E32\n            </div>\n\n            <!-- Orientation Toggle -->\n            <div class=\"insert-orient-row\">\n              <span class=\"insert-orient-label\">\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A:</span>\n              <div class=\"insert-orient-group\">\n                <button class=\"insert-orient-btn\"\n                  [class.active]=\"insertOrientation === 'portrait'\"\n                  (click)=\"insertOrientation = 'portrait'\" title=\"\u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07\">\n                  <svg-icon name=\"phone-portrait-outline\"></svg-icon>\n                  <span>\u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07</span>\n                </button>\n                <button class=\"insert-orient-btn\"\n                  [class.active]=\"insertOrientation === 'landscape'\"\n                  (click)=\"insertOrientation = 'landscape'\" title=\"\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19\">\n                  <svg-icon name=\"phone-landscape-outline\"></svg-icon>\n                  <span>\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19</span>\n                </button>\n              </div>\n            </div>\n\n            <!-- Before / After -->\n            <button class=\"insert-page-btn\" (click)=\"insertBlankPage('before')\">\n              <svg-icon name=\"arrow-up-outline\"></svg-icon>\n              <span>\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E35\u0E49 <small>(\u0E2B\u0E19\u0E49\u0E32 {{ pageNo }})</small></span>\n            </button>\n            <button class=\"insert-page-btn\" (click)=\"insertBlankPage('after')\">\n              <svg-icon name=\"arrow-down-outline\"></svg-icon>\n              <span>\u0E2B\u0E25\u0E31\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E35\u0E49 <small>(\u0E2B\u0E19\u0E49\u0E32 {{ pageNo + 1 }})</small></span>\n            </button>\n\n            <div class=\"insert-menu-divider\"></div>\n\n            <!-- Section: \u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32 -->\n            <div class=\"insert-page-title insert-page-title--danger\">\n              <svg-icon name=\"trash-outline\"></svg-icon> \u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\n            </div>\n            <button class=\"insert-page-btn insert-page-btn--danger\"\n              [disabled]=\"pageCount <= 1\"\n              (click)=\"deletePage()\">\n              <svg-icon name=\"close-circle-outline\"></svg-icon>\n              <span>\u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E35\u0E49 <small>(\u0E2B\u0E19\u0E49\u0E32 {{ pageNo }})</small></span>\n            </button>\n\n            <div class=\"insert-menu-divider\"></div>\n\n            <!-- Section: \u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A -->\n            <button class=\"insert-page-btn insert-page-btn--undo\"\n              [disabled]=\"!canUndoPageOp\"\n              (click)=\"undoPageOp()\">\n              <svg-icon name=\"arrow-undo-outline\"></svg-icon>\n              <span>\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A\u0E01\u0E32\u0E23\u0E41\u0E17\u0E23\u0E01/\u0E25\u0E1A <small *ngIf=\"!canUndoPageOp\">(\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34)</small></span>\n            </button>\n\n          </div>\n        </div>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <div class=\"toolbar-group toolbar-group--save\">\n        <button class=\"toolbar-btn toolbar-btn--save\" (click)=\"saveDocument()\">\n          <svg-icon name=\"save-outline\"></svg-icon>\n          <span>\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01</span>\n        </button>\n        <!-- User Guide Toggle -->\n        <button class=\"toolbar-btn toolbar-btn--guide\" [class.active]=\"showUserGuidePanel\" (click)=\"toggleUserGuide($event)\" title=\"\u0E04\u0E39\u0E48\u0E21\u0E37\u0E2D\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19\">\n          <svg-icon name=\"book\"></svg-icon>\n          <span style=\"font-weight: 500; font-size: 13px;\">\u0E41\u0E19\u0E30\u0E19\u0E33\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19</span>\n        </button>\n        <!-- History Panel Toggle -->\n        <button class=\"toolbar-btn\" [class.active]=\"showHistoryPanel\" (click)=\"toggleHistoryPanel()\" title=\"\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02\">\n          <svg-icon name=\"time-outline\"></svg-icon>\n        </button>\n      </div>\n    </div>\n\n    <!-- Top Toolbar Row 2: Tools -->\n    <div class=\"toolbar-row toolbar-row--tools\">\n      <!-- Text Tool -->\n      <div class=\"tool-item\">\n        <button class=\"toolbar-btn\" [class.active]=\"textPlaceMode\" (click)=\"enableTextPlaceMode()\" title=\"\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\">\n          <svg-icon name=\"text\"></svg-icon>\n        </button>\n        <div class=\"tool-options\" *ngIf=\"textPlaceMode\">\n          <button (click)=\"changeTextFontSize(-2)\" [disabled]=\"textFontSize <= 8\"><svg-icon\n              name=\"remove\"></svg-icon></button>\n          <span>{{ textFontSize }}</span>\n          <button (click)=\"changeTextFontSize(2)\" [disabled]=\"textFontSize >= 100\"><svg-icon\n              name=\"add\"></svg-icon></button>\n          <div class=\"color-dots\">\n            <div class=\"color-dot\" style=\"background:#000\" (click)=\"setTextColor('#000000')\"\n              [class.active]=\"textColor === '#000000'\"></div>\n            <div class=\"color-dot\" style=\"background:#00f\" (click)=\"setTextColor('#0000FF')\"\n              [class.active]=\"textColor === '#0000FF'\"></div>\n            <div class=\"color-dot\" style=\"background:#f00\" (click)=\"setTextColor('#FF0000')\"\n              [class.active]=\"textColor === '#FF0000'\"></div>\n            <div class=\"color-dot color-dot--custom\" [style.background]=\"textColor\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\">\n              <svg-icon name=\"color-palette\" style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; color: #fff; text-shadow: 0 0 2px rgba(0,0,0,0.5); mix-blend-mode: difference; pointer-events: none;\"></svg-icon>\n              <input type=\"color\" [value]=\"textColor\" (input)=\"setTextColor($any($event.target).value)\">\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- Quick Mark Stamps + Form Fields -->\n      <div class=\"tool-item mark-tool-item\">\n        <button class=\"toolbar-btn mark-toolbar-btn\" [class.active]=\"showMarkOptions || toolMode === 'mark'\"\n          (click)=\"showMarkOptions = !showMarkOptions\" title=\"\u0E41\u0E1A\u0E1A\u0E1F\u0E2D\u0E23\u0E4C\u0E21\">\n          <!-- Fixed form icon: shows checkbox + radio + text rows -->\n          <svg width=\"22\" height=\"22\" viewBox=\"0 0 22 22\" fill=\"none\">\n            <rect x=\"1\" y=\"2\" width=\"7\" height=\"6\" rx=\"1.2\" stroke=\"currentColor\" stroke-width=\"1.6\"/>\n            <polyline points=\"2.5,5 4.2,7 7.5,3\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>\n            <line x1=\"10\" y1=\"5\" x2=\"21\" y2=\"5\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n            <circle cx=\"4.5\" cy=\"14\" r=\"3.2\" stroke=\"currentColor\" stroke-width=\"1.6\"/>\n            <circle cx=\"4.5\" cy=\"14\" r=\"1.5\" fill=\"currentColor\"/>\n            <line x1=\"10\" y1=\"14\" x2=\"21\" y2=\"14\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n            <line x1=\"10\" y1=\"20\" x2=\"21\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n            <line x1=\"1\" y1=\"20\" x2=\"7.5\" y2=\"20\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n            <line x1=\"1\" y1=\"17.5\" x2=\"5\" y2=\"17.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/>\n          </svg>\n          <span class=\"mark-btn-label\">\u0E41\u0E1A\u0E1A\u0E1F\u0E2D\u0E23\u0E4C\u0E21</span>\n          <svg-icon name=\"chevron-down-outline\" class=\"mark-chevron\"></svg-icon>\n        </button>\n\n        <div class=\"mark-popup\" *ngIf=\"showMarkOptions\">\n          <!-- Quick Marks section -->\n          <div class=\"mark-popup-section-label\">\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E14\u0E48\u0E27\u0E19</div>\n          <div class=\"mark-quick-row\">\n            <button class=\"mark-quick-btn\" [class.active]=\"toolMode === 'mark' && markType === 'check'\"\n              (click)=\"enableMarkMode('check')\" title=\"\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E16\u0E39\u0E01\">\n              <svg width=\"28\" height=\"28\" viewBox=\"0 0 28 28\"><polyline points=\"4,14 11,21 24,7\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" fill=\"none\"/></svg>\n            </button>\n            <button class=\"mark-quick-btn\" [class.active]=\"toolMode === 'mark' && markType === 'cross'\"\n              (click)=\"enableMarkMode('cross')\" title=\"\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E2B\u0E21\u0E32\u0E22\u0E1C\u0E34\u0E14\">\n              <svg width=\"28\" height=\"28\" viewBox=\"0 0 28 28\"><line x1=\"5\" y1=\"5\" x2=\"23\" y2=\"23\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\"/><line x1=\"23\" y1=\"5\" x2=\"5\" y2=\"23\" stroke=\"currentColor\" stroke-width=\"3\" stroke-linecap=\"round\"/></svg>\n            </button>\n            <button class=\"mark-quick-btn\" [class.active]=\"toolMode === 'mark' && markType === 'dot'\"\n              (click)=\"enableMarkMode('dot')\" title=\"\u0E08\u0E38\u0E14\">\n              <svg width=\"28\" height=\"28\" viewBox=\"0 0 28 28\"><circle cx=\"14\" cy=\"14\" r=\"9\" fill=\"currentColor\"/></svg>\n            </button>\n          </div>\n\n          <!-- Form Fields section -->\n          <div class=\"mark-popup-divider\"></div>\n          <div class=\"mark-popup-section-label\">\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E1F\u0E34\u0E25\u0E14\u0E4C\u0E41\u0E1A\u0E1A\u0E1F\u0E2D\u0E23\u0E4C\u0E21\u0E43\u0E2B\u0E21\u0E48</div>\n          <div class=\"mark-form-list\">\n            <button class=\"mark-form-row-btn\" [class.active]=\"toolMode === 'formfield' && formFieldType === 'text'\"\n              (click)=\"enableFormFieldMode('text')\" title=\"Text Field\">\n              <span class=\"mark-form-row-icon mark-form-row-icon--text\">Aa</span>\n              <span>Text Field</span>\n            </button>\n            <button class=\"mark-form-row-btn\" [class.active]=\"toolMode === 'formfield' && formFieldType === 'checkbox'\"\n              (click)=\"enableFormFieldMode('checkbox')\" title=\"Checkbox\">\n              <span class=\"mark-form-row-icon\">\n                <svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\"><rect x=\"1\" y=\"1\" width=\"16\" height=\"16\" rx=\"2.5\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><polyline points=\"4,9 7,13 14,5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" fill=\"none\"/></svg>\n              </span>\n              <span>Checkbox</span>\n            </button>\n            <button class=\"mark-form-row-btn\" [class.active]=\"toolMode === 'formfield' && formFieldType === 'radio'\"\n              (click)=\"enableFormFieldMode('radio')\" title=\"Radio Button\">\n              <span class=\"mark-form-row-icon\">\n                <svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\"><circle cx=\"9\" cy=\"9\" r=\"8\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\"/><circle cx=\"9\" cy=\"9\" r=\"4\" fill=\"currentColor\"/></svg>\n              </span>\n              <span>Radio Button</span>\n            </button>\n          </div>\n\n          <!-- Size + Color controls (compact, below fold) -->\n          <div class=\"mark-popup-divider\"></div>\n          <div class=\"mark-controls-row\">\n            <button (click)=\"changeMarkSize(-4)\" [disabled]=\"markSize <= 12\"><svg-icon name=\"remove\"></svg-icon></button>\n            <span class=\"mark-size-val\">{{ markSize }}</span>\n            <button (click)=\"changeMarkSize(4)\" [disabled]=\"markSize >= 96\"><svg-icon name=\"add\"></svg-icon></button>\n            <div class=\"color-dots\" style=\"margin-left: 6px;\">\n              <div class=\"color-dot\" style=\"background:#000\" (click)=\"setMarkColor('#000000')\" [class.active]=\"markColor === '#000000'\"></div>\n              <div class=\"color-dot\" style=\"background:#00f\" (click)=\"setMarkColor('#0000FF')\" [class.active]=\"markColor === '#0000FF'\"></div>\n              <div class=\"color-dot\" style=\"background:#f00\" (click)=\"setMarkColor('#FF0000')\" [class.active]=\"markColor === '#FF0000'\"></div>\n              <div class=\"color-dot\" style=\"background:#009900\" (click)=\"setMarkColor('#009900')\" [class.active]=\"markColor === '#009900'\"></div>\n              <div class=\"color-dot color-dot--custom\" [style.background]=\"markColor\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\">\n                <svg-icon name=\"color-palette\" style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; color: #fff; text-shadow: 0 0 2px rgba(0,0,0,0.5); mix-blend-mode: difference; pointer-events: none;\"></svg-icon>\n                <input type=\"color\" [value]=\"markColor\" (input)=\"setMarkColor($any($event.target).value)\">\n              </div>\n            </div>\n          </div>\n\n          <!-- Cancel / close popup -->\n          <div class=\"mark-popup-divider\"></div>\n          <button class=\"mark-cancel-btn\" (click)=\"showMarkOptions = false; toolMode = 'none'; updateCursor()\">\n            <svg-icon name=\"close-outline\"></svg-icon>\n            \u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\n          </button>\n        </div>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <!-- Shapes \u2014 Dropdown -->\n      <div class=\"tool-item shape-tool-item\">\n        <!-- Main shape button: shows current shape icon, click to activate/toggle dropdown -->\n        <button class=\"toolbar-btn\" [class.active]=\"shapeMode\"\n          (click)=\"toolMode='shape'; showShapeDropdown=!showShapeDropdown\" title=\"\u0E23\u0E39\u0E1B\u0E17\u0E23\u0E07\">\n          <svg-icon [name]=\"shapeType === 'rect' ? 'square-outline'\n                          : shapeType === 'circle' ? 'ellipse-outline'\n                          : shapeType === 'line' ? 'remove-outline'\n                          : 'arrow-forward-outline'\"></svg-icon>\n          <svg-icon name=\"chevron-down-outline\" class=\"shape-chevron\"></svg-icon>\n        </button>\n\n        <!-- Dropdown: choose shape type -->\n        <div class=\"shape-dropdown\" *ngIf=\"showShapeDropdown\">\n          <button class=\"shape-dd-btn\" [class.active]=\"shapeType === 'rect'\" (click)=\"selectShape('rect')\"\n            title=\"\u0E2A\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E35\u0E48\u0E22\u0E21\">\n            <svg-icon name=\"square-outline\"></svg-icon>\n          </button>\n          <button class=\"shape-dd-btn\" [class.active]=\"shapeType === 'circle'\" (click)=\"selectShape('circle')\"\n            title=\"\u0E27\u0E07\u0E01\u0E25\u0E21\">\n            <svg-icon name=\"ellipse-outline\"></svg-icon>\n          </button>\n          <button class=\"shape-dd-btn\" [class.active]=\"shapeType === 'line'\" (click)=\"selectShape('line')\" title=\"\u0E40\u0E2A\u0E49\u0E19\">\n            <svg-icon name=\"remove-outline\"></svg-icon>\n          </button>\n          <button class=\"shape-dd-btn\" [class.active]=\"shapeType === 'arrow'\" (click)=\"selectShape('arrow')\"\n            title=\"\u0E25\u0E39\u0E01\u0E28\u0E23\">\n            <svg-icon name=\"arrow-forward-outline\"></svg-icon>\n          </button>\n        </div>\n\n        <!-- Options panel: stroke width, stroke color, fill color -->\n        <div class=\"shape-options-panel\" *ngIf=\"shapeMode\">\n\n          <!-- Stroke width -->\n          <div class=\"shape-opt-group\">\n            <span class=\"shape-opt-label\">\u0E02\u0E19\u0E32\u0E14</span>\n            <button class=\"sopt-btn\" (click)=\"changeShapeStrokeSize(-1)\" [disabled]=\"shapeStrokeSize <= 1\">\n              <svg-icon name=\"remove\"></svg-icon>\n            </button>\n            <span class=\"sopt-val\">{{ shapeStrokeSize }}</span>\n            <button class=\"sopt-btn\" (click)=\"changeShapeStrokeSize(1)\" [disabled]=\"shapeStrokeSize >= 20\">\n              <svg-icon name=\"add\"></svg-icon>\n            </button>\n          </div>\n\n          <div class=\"sopt-divider\"></div>\n\n          <!-- Stroke color (disabled when no-stroke is on) -->\n          <div class=\"shape-opt-group\">\n            <span class=\"shape-opt-label\">\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A</span>\n            <!-- No stroke toggle -->\n            <button class=\"sopt-fill-toggle\" [class.active]=\"shapeNoStroke\" (click)=\"toggleShapeNoStroke()\"\n              title=\"\u0E44\u0E21\u0E48\u0E21\u0E35\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A\">\n              <svg-icon name=\"ban-outline\"></svg-icon>\n            </button>\n            <div class=\"mac-color-grid\" [class.disabled]=\"shapeNoStroke\">\n              <div class=\"mac-swatch\" *ngFor=\"let c of shapeColorSwatches\" [style.background]=\"c\"\n                [class.active]=\"shapeStrokeColor === c && !shapeNoStroke\"\n                (click)=\"!shapeNoStroke && setShapeStrokeColor(c)\" [title]=\"c\"></div>\n            </div>\n            <div class=\"mac-custom-color\" [class.disabled]=\"shapeNoStroke\">\n              <div class=\"mac-swatch mac-swatch--current\" [style.background]=\"shapeStrokeColor\"></div>\n              <input type=\"color\" [value]=\"shapeStrokeColor\" (input)=\"setShapeStrokeColor($any($event.target).value)\"\n                [disabled]=\"shapeNoStroke\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\" />\n            </div>\n          </div>\n\n          <div class=\"sopt-divider\"></div>\n\n          <!-- Fill color -->\n          <div class=\"shape-opt-group\">\n            <span class=\"shape-opt-label\">\u0E2A\u0E35\u0E1E\u0E37\u0E49\u0E19</span>\n            <button class=\"sopt-fill-toggle\" [class.active]=\"shapeFillEnabled\" (click)=\"toggleShapeFill()\"\n              title=\"\u0E40\u0E1B\u0E34\u0E14/\u0E1B\u0E34\u0E14\u0E2A\u0E35\u0E1E\u0E37\u0E49\u0E19\">\n              <svg-icon [name]=\"shapeFillEnabled ? 'color-fill' : 'color-fill-outline'\"></svg-icon>\n            </button>\n            <div class=\"mac-color-grid\" [class.disabled]=\"!shapeFillEnabled\">\n              <div class=\"mac-swatch\" *ngFor=\"let c of shapeFillSwatches\" [style.background]=\"c\"\n                [class.active]=\"shapeFillColor === c && shapeFillEnabled\"\n                (click)=\"shapeFillEnabled && setShapeFillColor(c)\" [title]=\"c\"></div>\n            </div>\n            <div class=\"mac-custom-color\" [class.disabled]=\"!shapeFillEnabled\">\n              <div class=\"mac-swatch mac-swatch--current\" [style.background]=\"shapeFillColor\"></div>\n              <input type=\"color\" [value]=\"shapeFillColor\" (input)=\"setShapeFillColor($any($event.target).value)\"\n                [disabled]=\"!shapeFillEnabled\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E1E\u0E37\u0E49\u0E19\u0E40\u0E2D\u0E07\" />\n            </div>\n          </div>\n\n        </div>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <!-- Draw Tool -->\n      <div class=\"tool-item\">\n        <button class=\"toolbar-btn\" [class.active]=\"drawMode\" (click)=\"toggleDraw()\" title=\"\u0E27\u0E32\u0E14\">\n          <svg-icon name=\"brush\"></svg-icon>\n        </button>\n        <div class=\"tool-options\" *ngIf=\"drawMode\">\n          <button (click)=\"changeBrushSize(-1)\" [disabled]=\"brushSize <= 1\"><svg-icon name=\"remove\"></svg-icon></button>\n          <span>{{ brushSize }}</span>\n          <button (click)=\"changeBrushSize(1)\" [disabled]=\"brushSize >= 50\"><svg-icon name=\"add\"></svg-icon></button>\n          <div class=\"color-dots\">\n            <div class=\"color-dot\" style=\"background:#000\" (click)=\"setBrushColor('#000000')\"\n              [class.active]=\"brushColor === '#000000'\"></div>\n            <div class=\"color-dot\" style=\"background:#00f\" (click)=\"setBrushColor('#0000FF')\"\n              [class.active]=\"brushColor === '#0000FF'\"></div>\n            <div class=\"color-dot\" style=\"background:#f00\" (click)=\"setBrushColor('#FF0000')\"\n              [class.active]=\"brushColor === '#FF0000'\"></div>\n            <div class=\"color-dot color-dot--custom\" [style.background]=\"brushColor\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\">\n              <svg-icon name=\"color-palette\" style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; color: #fff; text-shadow: 0 0 2px rgba(0,0,0,0.5); mix-blend-mode: difference; pointer-events: none;\"></svg-icon>\n              <input type=\"color\" [value]=\"brushColor\" (input)=\"setBrushColor($any($event.target).value)\">\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- Highlight Tool -->\n      <div class=\"tool-item\">\n        <button class=\"toolbar-btn\" [class.active]=\"highlightMode\" (click)=\"toggleHighlight()\" title=\"\u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C\">\n          <svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <!-- Marker Body -->\n            <path d=\"M18 2l4 4L9 19H5v-4L18 2z\"></path>\n            <path d=\"M14 6l4 4\"></path>\n            <!-- Highlight Line -->\n            <line x1=\"3\" y1=\"22\" x2=\"21\" y2=\"22\" stroke-width=\"3\"></line>\n          </svg>\n        </button>\n        <div class=\"tool-options\" *ngIf=\"highlightMode\">\n          <button (click)=\"changeHighlightSize(-5)\" [disabled]=\"highlightSize <= 5\"><svg-icon\n              name=\"remove\"></svg-icon></button>\n          <span>{{ highlightSize }}</span>\n          <button (click)=\"changeHighlightSize(5)\" [disabled]=\"highlightSize >= 100\"><svg-icon\n              name=\"add\"></svg-icon></button>\n          <div class=\"color-dots\">\n            <div class=\"color-dot\" style=\"background:#ffff00\" (click)=\"setHighlightColor('#ffff00')\"\n              [class.active]=\"highlightColor === '#ffff00'\" title=\"\u0E40\u0E2B\u0E25\u0E37\u0E2D\u0E07\"></div>\n            <div class=\"color-dot\" style=\"background:#00ff00\" (click)=\"setHighlightColor('#00ff00')\"\n              [class.active]=\"highlightColor === '#00ff00'\" title=\"\u0E40\u0E02\u0E35\u0E22\u0E27\"></div>\n            <div class=\"color-dot\" style=\"background:#00ffff\" (click)=\"setHighlightColor('#00ffff')\"\n              [class.active]=\"highlightColor === '#00ffff'\" title=\"\u0E1F\u0E49\u0E32\"></div>\n            <div class=\"color-dot\" style=\"background:#ff99c2\" (click)=\"setHighlightColor('#ff99c2')\"\n              [class.active]=\"highlightColor === '#ff99c2'\" title=\"\u0E0A\u0E21\u0E1E\u0E39\"></div>\n            <div class=\"color-dot\" style=\"background:#ffb366\" (click)=\"setHighlightColor('#ffb366')\"\n              [class.active]=\"highlightColor === '#ffb366'\" title=\"\u0E2A\u0E49\u0E21\"></div>\n            <div class=\"color-dot\" style=\"background:#d9b3ff\" (click)=\"setHighlightColor('#d9b3ff')\"\n              [class.active]=\"highlightColor === '#d9b3ff'\" title=\"\u0E21\u0E48\u0E27\u0E07\"></div>\n            <div class=\"color-dot color-dot--custom\" [style.background]=\"highlightColor\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\u0E23\u0E2B\u0E31\u0E2A HEX\">\n              <svg-icon name=\"color-palette\" style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; color: #fff; text-shadow: 0 0 2px rgba(0,0,0,0.5); mix-blend-mode: difference; pointer-events: none;\"></svg-icon>\n              <input type=\"color\" [value]=\"highlightColor\" (input)=\"setHighlightColor($any($event.target).value)\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\">\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- Eraser -->\n      <div class=\"tool-item\">\n        <button class=\"toolbar-btn\" [class.active]=\"eraserMode\" (click)=\"toggleEraser()\" title=\"\u0E22\u0E32\u0E07\u0E25\u0E1A (\u0E25\u0E1A\u0E40\u0E2A\u0E49\u0E19\u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E17\u0E23\u0E07)\">\n          <svg width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n            <path d=\"M20 20H7L3 16C2.5 15.5 2.5 14.5 3 14L13 4C13.5 3.5 14.5 3.5 15 4L20 9C20.5 9.5 20.5 10.5 20 11L11 20H20V20Z\"/>\n            <path d=\"M17.5 15L9 6.5\"/>\n          </svg>\n        </button>\n        <div class=\"tool-options\" *ngIf=\"eraserMode\">\n          <button (click)=\"changeEraserSize(-5)\" [disabled]=\"eraserSize <= 5\"><svg-icon name=\"remove\"></svg-icon></button>\n          <span>{{ eraserSize }}</span>\n          <button (click)=\"changeEraserSize(5)\" [disabled]=\"eraserSize >= 200\"><svg-icon name=\"add\"></svg-icon></button>\n        </div>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <!-- Insert Tools -->\n      <button class=\"toolbar-btn\" (click)=\"openSignaturePickerOrPad()\" title=\"\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\">\n        <svg-icon name=\"finger-print\"></svg-icon>\n      </button>\n      <button class=\"toolbar-btn toolbar-btn--toggle\" [class.active]=\"showDigitalId\"\n        (click)=\"showDigitalId = !showDigitalId\" title=\"\u0E41\u0E2A\u0E14\u0E07/\u0E0B\u0E48\u0E2D\u0E19 Digital ID\">\n        <svg-icon [name]=\"showDigitalId ? 'shield-checkmark' : 'shield-checkmark-outline'\"></svg-icon>\n        <span class=\"toggle-label\">DID</span>\n      </button>\n\n      <!-- Date Stamp with Options -->\n      <div class=\"tool-item\">\n        <button class=\"toolbar-btn\" [class.active]=\"showDateOptions\" (click)=\"addDateStampAndShowOptions()\"\n          title=\"\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\">\n          <svg-icon name=\"calendar\"></svg-icon>\n        </button>\n        <div class=\"tool-options\" *ngIf=\"showDateOptions\">\n          <button (click)=\"changeDateFontSize(-2)\" [disabled]=\"dateFontSize <= 8\"><svg-icon\n              name=\"remove\"></svg-icon></button>\n          <span>{{ dateFontSize }}</span>\n          <button (click)=\"changeDateFontSize(2)\" [disabled]=\"dateFontSize >= 100\"><svg-icon\n              name=\"add\"></svg-icon></button>\n          <div class=\"color-dots\">\n            <div class=\"color-dot\" style=\"background:#000\" (click)=\"setDateColor('#000000')\"\n              [class.active]=\"dateColor === '#000000'\"></div>\n            <div class=\"color-dot\" style=\"background:#00f\" (click)=\"setDateColor('#0000FF')\"\n              [class.active]=\"dateColor === '#0000FF'\"></div>\n            <div class=\"color-dot\" style=\"background:#f00\" (click)=\"setDateColor('#FF0000')\"\n              [class.active]=\"dateColor === '#FF0000'\"></div>\n            <div class=\"color-dot color-dot--custom\" [style.background]=\"dateColor\" title=\"\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\">\n              <svg-icon name=\"color-palette\" style=\"position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 12px; color: #fff; text-shadow: 0 0 2px rgba(0,0,0,0.5); mix-blend-mode: difference; pointer-events: none;\"></svg-icon>\n              <input type=\"color\" [value]=\"dateColor\" (input)=\"setDateColor($any($event.target).value)\">\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <button class=\"toolbar-btn\" (click)=\"triggerImageUpload()\" title=\"\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\">\n        <svg-icon name=\"image\"></svg-icon>\n      </button>\n      <input type=\"file\" #fileInput accept=\"image/*\" style=\"display:none\" (change)=\"onImageSelected($event)\">\n\n      <!-- Stamp Tool -->\n      <button class=\"toolbar-btn toolbar-btn--labeled\" (click)=\"openStampPicker()\" title=\"\u0E15\u0E23\u0E32\u0E22\u0E32\u0E07/\u0E15\u0E23\u0E32\u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A\">\n        <svg-icon name=\"business-outline\"></svg-icon>\n        <small>\u0E15\u0E23\u0E32\u0E22\u0E32\u0E07</small>\n      </button>\n      <input type=\"file\" #stampFileInput accept=\"image/*\" style=\"display:none\" (change)=\"onStampFileSelected($event)\">\n\n      <div class=\"toolbar-divider\"></div>\n\n      <!-- Page Flip -->\n      <div class=\"tool-item flip-tool-item\">\n        <button class=\"toolbar-btn toolbar-btn--labeled\" [class.active]=\"showFlipPanel\" (click)=\"toggleFlipPanel()\" title=\"\u0E1E\u0E25\u0E34\u0E01\u0E01\u0E23\u0E30\u0E14\u0E32\u0E29\">\n          <svg-icon name=\"swap-horizontal-outline\"></svg-icon>\n          <small>\u0E1E\u0E25\u0E34\u0E01\u0E01\u0E23\u0E30\u0E14\u0E32\u0E29</small>\n        </button>\n\n        <!-- Flip Panel (floating) -->\n        <div class=\"flip-panel\" *ngIf=\"showFlipPanel\">\n          <div class=\"flip-panel__header\">\n            <svg-icon name=\"swap-horizontal-outline\"></svg-icon> \u0E1E\u0E25\u0E34\u0E01\u0E01\u0E23\u0E30\u0E14\u0E32\u0E29\n            <button class=\"flip-panel__close\" (click)=\"closeFlipPanel()\">\u2715</button>\n          </div>\n          <div class=\"flip-panel__body\">\n            <div class=\"flip-scope\">\n              <label [class.active]=\"flipScope === 'current'\" (click)=\"flipScope = 'current'\">\n                <svg-icon name=\"document-outline\"></svg-icon> \u0E2B\u0E19\u0E49\u0E32\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19 ({{ pageNo }})\n              </label>\n              <label [class.active]=\"flipScope === 'all'\" (click)=\"flipScope = 'all'\">\n                <svg-icon name=\"documents-outline\"></svg-icon> \u0E17\u0E38\u0E01\u0E2B\u0E19\u0E49\u0E32\n              </label>\n            </div>\n            <div class=\"flip-current-label\">\n              \u0E21\u0E38\u0E21\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19: <strong>{{ getPageFlip(pageNo) }}\u00B0</strong>\n            </div>\n            <div class=\"flip-angle-btns\">\n              <button class=\"flip-btn\" [class.active]=\"getPageFlip(pageNo) === 0\" (click)=\"setFlipAngle(0)\" title=\"0\u00B0 (\u0E1B\u0E01\u0E15\u0E34)\">0\u00B0</button>\n              <button class=\"flip-btn\" [class.active]=\"getPageFlip(pageNo) === 90\" (click)=\"setFlipAngle(90)\" title=\"90\u00B0 (\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19\u0E02\u0E27\u0E32)\">90\u00B0</button>\n              <button class=\"flip-btn\" [class.active]=\"getPageFlip(pageNo) === 180\" (click)=\"setFlipAngle(180)\" title=\"180\u00B0 (\u0E01\u0E25\u0E31\u0E1A\u0E2B\u0E31\u0E27)\">180\u00B0</button>\n              <button class=\"flip-btn\" [class.active]=\"getPageFlip(pageNo) === 270\" (click)=\"setFlipAngle(270)\" title=\"270\u00B0 (\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19\u0E0B\u0E49\u0E32\u0E22)\">270\u00B0</button>\n            </div>\n            <div class=\"flip-rotate-btns\">\n              <button class=\"flip-action-btn\" (click)=\"flipPageCCW()\" title=\"\u0E2B\u0E21\u0E38\u0E19\u0E17\u0E27\u0E19\u0E40\u0E02\u0E47\u0E21\">\n                <svg-icon name=\"return-up-back-outline\"></svg-icon> \u0E2B\u0E21\u0E38\u0E19\u0E0B\u0E49\u0E32\u0E22\n              </button>\n              <button class=\"flip-action-btn\" (click)=\"flipPageCW()\" title=\"\u0E2B\u0E21\u0E38\u0E19\u0E15\u0E32\u0E21\u0E40\u0E02\u0E47\u0E21\">\n                \u0E2B\u0E21\u0E38\u0E19\u0E02\u0E27\u0E32 <svg-icon name=\"return-up-forward-outline\"></svg-icon>\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n\n      <!-- Deskew (Page Straightening) -->\n      <button class=\"toolbar-btn toolbar-btn--labeled\" [class.active]=\"showDeskewPanel\" (click)=\"toggleDeskewPanel()\" title=\"\u0E2B\u0E21\u0E38\u0E19\u0E2B\u0E19\u0E49\u0E32/\u0E08\u0E31\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E23\u0E07\">\n        <svg-icon name=\"sync-outline\"></svg-icon>\n        <small>\u0E08\u0E31\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E23\u0E07</small>\n      </button>\n\n      <!-- Watermark -->\n      <div class=\"tool-item wm-tool-item\">\n        <button class=\"toolbar-btn toolbar-btn--labeled\" [class.active]=\"showWatermarkPanel || watermark.enabled\" (click)=\"toggleWatermarkPanel()\" title=\"\u0E25\u0E32\u0E22\u0E19\u0E49\u0E33\">\n          <svg-icon name=\"water-outline\"></svg-icon>\n          <small>\u0E25\u0E32\u0E22\u0E19\u0E49\u0E33</small>\n        </button>\n\n        <!-- Watermark Settings Panel -->\n        <div class=\"wm-panel\" *ngIf=\"showWatermarkPanel\">\n          <div class=\"wm-panel__header\">\n            <svg-icon name=\"water-outline\"></svg-icon> \u0E25\u0E32\u0E22\u0E19\u0E49\u0E33 (Watermark)\n            <button class=\"wm-panel__close\" (click)=\"closeWatermarkPanel()\">\u2715</button>\n          </div>\n          <div class=\"wm-panel__body\">\n            <div class=\"wm-row\">\n              <label>\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17</label>\n              <select [(ngModel)]=\"watermark.type\" class=\"wm-input\">\n                <option value=\"text\">\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21</option>\n                <option value=\"image\">\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E</option>\n              </select>\n            </div>\n            <div *ngIf=\"watermark.type === 'text'\">\n              <div class=\"wm-row\">\n                <label>\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21</label>\n                <input type=\"text\" [(ngModel)]=\"watermark.text\" class=\"wm-input\" placeholder=\"\u0E2A\u0E33\u0E40\u0E19\u0E32\" />\n              </div>\n              <div class=\"wm-row\">\n                <label>\u0E1F\u0E2D\u0E19\u0E15\u0E4C</label>\n                <select [(ngModel)]=\"watermark.fontFamily\" class=\"wm-input\">\n                  <option value=\"TH Sarabun New\">TH Sarabun New</option>\n                  <option value=\"TH Sarabun IT9\">TH Sarabun IT9</option>\n                  <option value=\"Noto Sans Thai\">Noto Sans Thai</option>\n                </select>\n              </div>\n              <div class=\"wm-row\">\n                <label>\u0E02\u0E19\u0E32\u0E14</label>\n                <input type=\"number\" [(ngModel)]=\"watermark.fontSize\" min=\"10\" max=\"120\" class=\"wm-input wm-input--sm\" />\n              </div>\n              <div class=\"wm-row\">\n                <label>\u0E2A\u0E35</label>\n                <div class=\"wm-color-wrap\">\n                  <div class=\"wm-color-swatch\" [style.background]=\"watermark.color\"></div>\n                  <input type=\"color\" [(ngModel)]=\"watermark.color\" />\n                </div>\n              </div>\n            </div>\n            <div *ngIf=\"watermark.type === 'image'\">\n              <div class=\"wm-row\">\n                <label>\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B</label>\n                <input type=\"file\" accept=\"image/*\" (change)=\"onWatermarkImageSelected($event)\" class=\"wm-file-input\" />\n              </div>\n              <div *ngIf=\"watermark.imageDataUrl\" class=\"wm-img-preview\">\n                <img [src]=\"watermark.imageDataUrl\" />\n              </div>\n            </div>\n            <div class=\"wm-section-title\">\u0E01\u0E32\u0E23\u0E41\u0E2A\u0E14\u0E07\u0E1C\u0E25</div>\n            <div class=\"wm-row\">\n              <label>\u0E04\u0E27\u0E32\u0E21\u0E42\u0E1B\u0E23\u0E48\u0E07\u0E43\u0E2A</label>\n              <input type=\"range\" min=\"5\" max=\"100\" [(ngModel)]=\"watermark.opacity\" class=\"wm-slider\" />\n              <span class=\"wm-val\">{{ watermark.opacity }}%</span>\n            </div>\n            <div class=\"wm-row\">\n              <label>\u0E21\u0E38\u0E21\u0E2B\u0E21\u0E38\u0E19</label>\n              <input type=\"range\" min=\"0\" max=\"360\" [(ngModel)]=\"watermark.rotation\" class=\"wm-slider\" />\n              <span class=\"wm-val\">{{ watermark.rotation }}\u00B0</span>\n            </div>\n            <div class=\"wm-row\">\n              <label>\u0E42\u0E2B\u0E21\u0E14</label>\n              <div class=\"wm-radio-group\">\n                <label><input type=\"radio\" [(ngModel)]=\"watermark.mode\" value=\"center\" /> \u0E01\u0E36\u0E48\u0E07\u0E01\u0E25\u0E32\u0E07</label>\n                <label><input type=\"radio\" [(ngModel)]=\"watermark.mode\" value=\"tiled\" /> \u0E01\u0E23\u0E30\u0E08\u0E32\u0E22\u0E40\u0E15\u0E47\u0E21\u0E2B\u0E19\u0E49\u0E32</label>\n              </div>\n            </div>\n            <div *ngIf=\"watermark.mode === 'tiled'\" class=\"wm-row\">\n              <label>\u0E23\u0E30\u0E22\u0E30\u0E2B\u0E48\u0E32\u0E07</label>\n              <div class=\"wm-spacing-group\">\n                <span>X</span>\n                <input type=\"number\" [(ngModel)]=\"watermark.spacingX\" min=\"50\" max=\"500\" class=\"wm-input wm-input--xs\" />\n                <span>Y</span>\n                <input type=\"number\" [(ngModel)]=\"watermark.spacingY\" min=\"50\" max=\"500\" class=\"wm-input wm-input--xs\" />\n              </div>\n            </div>\n            <div class=\"wm-row\">\n              <label>\u0E02\u0E2D\u0E1A\u0E40\u0E02\u0E15</label>\n              <div class=\"wm-radio-group\">\n                <label><input type=\"radio\" [(ngModel)]=\"watermark.scope\" value=\"all\" /> \u0E17\u0E38\u0E01\u0E2B\u0E19\u0E49\u0E32</label>\n                <label><input type=\"radio\" [(ngModel)]=\"watermark.scope\" value=\"current\" /> \u0E2B\u0E19\u0E49\u0E32\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19</label>\n              </div>\n            </div>\n          </div>\n          <div class=\"wm-panel__footer\">\n            <button class=\"wm-btn wm-btn--cancel\" (click)=\"removeWatermark(); closeWatermarkPanel()\">\n              <svg-icon name=\"close-outline\"></svg-icon> \u0E25\u0E1A\u0E25\u0E32\u0E22\u0E19\u0E49\u0E33\n            </button>\n            <button class=\"wm-btn wm-btn--apply\" (click)=\"applyWatermark()\">\n              <svg-icon name=\"checkmark-outline\"></svg-icon> \u0E43\u0E2A\u0E48\u0E25\u0E32\u0E22\u0E19\u0E49\u0E33\n            </button>\n          </div>\n        </div>\n      </div>\n\n      <!-- Page Numbers -->\n      <div class=\"tool-item pn-tool-item\">\n        <button class=\"toolbar-btn toolbar-btn--labeled\" [class.active]=\"showPageNumberPanel || pageNumber.enabled\" (click)=\"togglePageNumberPanel()\" title=\"\u0E40\u0E25\u0E02\u0E2B\u0E19\u0E49\u0E32\">\n          <svg-icon name=\"list-outline\"></svg-icon>\n          <small>\u0E40\u0E25\u0E02\u0E2B\u0E19\u0E49\u0E32</small>\n        </button>\n\n        <!-- Page Number Panel -->\n        <div class=\"pn-panel\" *ngIf=\"showPageNumberPanel\">\n          <div class=\"pn-panel__header\">\n            <svg-icon name=\"list-outline\"></svg-icon> \u0E40\u0E25\u0E02\u0E2B\u0E19\u0E49\u0E32\n            <button class=\"pn-panel__close\" (click)=\"closePageNumberPanel()\">\u2715</button>\n          </div>\n          <div class=\"pn-panel__body\" style=\"max-height: 60vh; overflow-y: auto;\">\n            <div class=\"pn-section-title\">\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02</div>\n            <div class=\"pn-format-btns\" style=\"flex-wrap: wrap;\">\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.format === 'arabic'\" (click)=\"pageNumber.format = 'arabic'\" style=\"flex:1; min-width:70px;\">123 (\u0E2D\u0E32\u0E23\u0E32\u0E1A\u0E34\u0E01)</button>\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.format === 'thai'\" (click)=\"pageNumber.format = 'thai'\" style=\"flex:1; min-width:70px;\">\u0E51\u0E52\u0E53 (\u0E44\u0E17\u0E22)</button>\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.format === 'roman'\" (click)=\"pageNumber.format = 'roman'\" style=\"flex:1; min-width:70px;\">i, ii, iii</button>\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.format === 'roman-upper'\" (click)=\"pageNumber.format = 'roman-upper'\" style=\"flex:1; min-width:70px;\">I, II, III</button>\n            </div>\n\n            <div class=\"pn-section-title\">\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07</div>\n            <div class=\"pn-pos-grid\">\n              <button class=\"pn-pos-btn\" [class.active]=\"pageNumber.position === 'top-left'\" (click)=\"pageNumber.position = 'top-left'\" title=\"\u0E1A\u0E19\u0E0B\u0E49\u0E32\u0E22\"><svg-icon name=\"arrow-up-outline\"></svg-icon> \u0E1A\u0E19\u0E0B\u0E49\u0E32\u0E22</button>\n              <button class=\"pn-pos-btn\" [class.active]=\"pageNumber.position === 'top-center'\" (click)=\"pageNumber.position = 'top-center'\" title=\"\u0E1A\u0E19\u0E01\u0E25\u0E32\u0E07\"><svg-icon name=\"remove-outline\"></svg-icon> \u0E1A\u0E19\u0E01\u0E25\u0E32\u0E07</button>\n              <button class=\"pn-pos-btn\" [class.active]=\"pageNumber.position === 'top-right'\" (click)=\"pageNumber.position = 'top-right'\" title=\"\u0E1A\u0E19\u0E02\u0E27\u0E32\"><svg-icon name=\"arrow-up-outline\"></svg-icon> \u0E1A\u0E19\u0E02\u0E27\u0E32</button>\n              <button class=\"pn-pos-btn\" [class.active]=\"pageNumber.position === 'bottom-left'\" (click)=\"pageNumber.position = 'bottom-left'\" title=\"\u0E25\u0E48\u0E32\u0E07\u0E0B\u0E49\u0E32\u0E22\"><svg-icon name=\"arrow-down-outline\"></svg-icon> \u0E25\u0E48\u0E32\u0E07\u0E0B\u0E49\u0E32\u0E22</button>\n              <button class=\"pn-pos-btn\" [class.active]=\"pageNumber.position === 'bottom-center'\" (click)=\"pageNumber.position = 'bottom-center'\" title=\"\u0E25\u0E48\u0E32\u0E07\u0E01\u0E25\u0E32\u0E07\"><svg-icon name=\"remove-outline\"></svg-icon> \u0E25\u0E48\u0E32\u0E07\u0E01\u0E25\u0E32\u0E07</button>\n              <button class=\"pn-pos-btn\" [class.active]=\"pageNumber.position === 'bottom-right'\" (click)=\"pageNumber.position = 'bottom-right'\" title=\"\u0E25\u0E48\u0E32\u0E07\u0E02\u0E27\u0E32\"><svg-icon name=\"arrow-down-outline\"></svg-icon> \u0E25\u0E48\u0E32\u0E07\u0E02\u0E27\u0E32</button>\n            </div>\n\n            <div class=\"pn-row\" style=\"margin-top: 6px;\">\n              <label class=\"pn-checkbox\">\n                <input type=\"checkbox\" [(ngModel)]=\"pageNumber.mirror\" /> \u0E2A\u0E25\u0E31\u0E1A\u0E0B\u0E49\u0E32\u0E22-\u0E02\u0E27\u0E32 (\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E2A\u0E2D\u0E07\u0E2B\u0E19\u0E49\u0E32)\n              </label>\n            </div>\n\n            <div class=\"pn-section-title\" style=\"margin-top: 10px;\">\u0E0A\u0E48\u0E27\u0E07\u0E2B\u0E19\u0E49\u0E32</div>\n            <div class=\"pn-row\">\n              <label>\u0E40\u0E23\u0E34\u0E48\u0E21\u0E19\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E2B\u0E19\u0E49\u0E32\u0E08\u0E23\u0E34\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48</label>\n              <input type=\"number\" [(ngModel)]=\"pageNumber.startAtPage\" min=\"1\" [max]=\"pageCount\" class=\"pn-input pn-input--sm\" />\n            </div>\n            <div class=\"pn-row\">\n              <label>\u0E40\u0E25\u0E02\u0E40\u0E23\u0E34\u0E48\u0E21\u0E15\u0E49\u0E19</label>\n              <input type=\"number\" [(ngModel)]=\"pageNumber.startFrom\" min=\"1\" class=\"pn-input pn-input--sm\" />\n            </div>\n            <div class=\"pn-row\">\n              <label class=\"pn-checkbox\">\n                <input type=\"checkbox\" [(ngModel)]=\"pageNumber.skipFirstPage\" /> \u0E44\u0E21\u0E48\u0E41\u0E2A\u0E14\u0E07\u0E17\u0E35\u0E48\u0E2B\u0E19\u0E49\u0E32\u0E41\u0E23\u0E01 (\u0E2B\u0E19\u0E49\u0E32\u0E1B\u0E01)\n              </label>\n            </div>\n\n            <div class=\"pn-section-title\" style=\"margin-top: 10px;\">\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48\u0E41\u0E2A\u0E14\u0E07</div>\n            <div class=\"pn-format-btns\" style=\"flex-wrap: wrap;\">\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.pageScope === 'all'\" (click)=\"pageNumber.pageScope = 'all'\" style=\"flex:1; min-width:60px;\">\u0E17\u0E38\u0E01\u0E2B\u0E19\u0E49\u0E32</button>\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.pageScope === 'odd'\" (click)=\"pageNumber.pageScope = 'odd'\" style=\"flex:1; min-width:60px;\">\u0E2B\u0E19\u0E49\u0E32\u0E04\u0E35\u0E48</button>\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.pageScope === 'even'\" (click)=\"pageNumber.pageScope = 'even'\" style=\"flex:1; min-width:60px;\">\u0E2B\u0E19\u0E49\u0E32\u0E04\u0E39\u0E48</button>\n              <button class=\"pn-format-btn\" [class.active]=\"pageNumber.pageScope === 'custom'\" (click)=\"pageNumber.pageScope = 'custom'\" style=\"flex:1; min-width:60px;\">\u0E23\u0E30\u0E1A\u0E38\u0E40\u0E2D\u0E07</button>\n            </div>\n            <div class=\"pn-row\" *ngIf=\"pageNumber.pageScope === 'custom'\">\n              <label>\u0E23\u0E30\u0E1A\u0E38\u0E2B\u0E19\u0E49\u0E32</label>\n              <input type=\"text\" [(ngModel)]=\"pageNumber.customPages\" class=\"pn-input\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 1,3,5-10\" style=\"font-size: 13px;\" />\n            </div>\n\n            <div class=\"pn-section-title\" style=\"margin-top: 10px;\">\u0E04\u0E33\u0E19\u0E33\u0E2B\u0E19\u0E49\u0E32 / \u0E04\u0E33\u0E15\u0E48\u0E2D\u0E17\u0E49\u0E32\u0E22</div>\n            <div class=\"pn-row\">\n              <label class=\"pn-checkbox\">\n                <input type=\"checkbox\" [(ngModel)]=\"pageNumber.showPrefix\" /> \u0E41\u0E2A\u0E14\u0E07\u0E04\u0E33\u0E19\u0E33\u0E2B\u0E19\u0E49\u0E32\n              </label>\n            </div>\n            <div class=\"pn-row\" *ngIf=\"pageNumber.showPrefix\">\n              <label>\u0E04\u0E33\u0E19\u0E33\u0E2B\u0E19\u0E49\u0E32</label>\n              <input type=\"text\" [(ngModel)]=\"pageNumber.prefixText\" class=\"pn-input\" placeholder=\"\u0E2B\u0E19\u0E49\u0E32 \" style=\"font-size: 13px;\" />\n            </div>\n            <div class=\"pn-row\">\n              <label>\u0E04\u0E33\u0E15\u0E48\u0E2D\u0E17\u0E49\u0E32\u0E22</label>\n              <input type=\"text\" [(ngModel)]=\"pageNumber.suffixText\" class=\"pn-input\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 /{{ pageCount }}\" style=\"font-size: 13px;\" />\n            </div>\n\n            <div class=\"pn-section-title\" style=\"margin-top: 10px;\">\u0E2A\u0E48\u0E27\u0E19\u0E2B\u0E31\u0E27 / \u0E2A\u0E48\u0E27\u0E19\u0E17\u0E49\u0E32\u0E22</div>\n            <div class=\"pn-row\">\n              <label>\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E48\u0E27\u0E19\u0E2B\u0E31\u0E27</label>\n              <input type=\"text\" [(ngModel)]=\"pageNumber.headerText\" class=\"pn-input\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 \u0E0A\u0E37\u0E48\u0E2D\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\" style=\"font-size: 13px;\" />\n            </div>\n            <div class=\"pn-row\" *ngIf=\"pageNumber.headerText\">\n              <label>\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07\u0E2B\u0E31\u0E27</label>\n              <div class=\"pn-format-btns\" style=\"flex-wrap: wrap;\">\n                <button class=\"pn-format-btn\" [class.active]=\"pageNumber.headerPosition === 'top-left'\" (click)=\"pageNumber.headerPosition = 'top-left'\" style=\"flex:1; min-width:50px; font-size: 11px;\">\u0E0B\u0E49\u0E32\u0E22</button>\n                <button class=\"pn-format-btn\" [class.active]=\"pageNumber.headerPosition === 'top-center'\" (click)=\"pageNumber.headerPosition = 'top-center'\" style=\"flex:1; min-width:50px; font-size: 11px;\">\u0E01\u0E25\u0E32\u0E07</button>\n                <button class=\"pn-format-btn\" [class.active]=\"pageNumber.headerPosition === 'top-right'\" (click)=\"pageNumber.headerPosition = 'top-right'\" style=\"flex:1; min-width:50px; font-size: 11px;\">\u0E02\u0E27\u0E32</button>\n              </div>\n            </div>\n            <div class=\"pn-row\">\n              <label>\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2A\u0E48\u0E27\u0E19\u0E17\u0E49\u0E32\u0E22</label>\n              <input type=\"text\" [(ngModel)]=\"pageNumber.footerText\" class=\"pn-input\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 \u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E1E\u0E34\u0E21\u0E1E\u0E4C\" style=\"font-size: 13px;\" />\n            </div>\n            <div class=\"pn-row\" *ngIf=\"pageNumber.footerText\">\n              <label>\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07\u0E17\u0E49\u0E32\u0E22</label>\n              <div class=\"pn-format-btns\" style=\"flex-wrap: wrap;\">\n                <button class=\"pn-format-btn\" [class.active]=\"pageNumber.footerPosition === 'bottom-left'\" (click)=\"pageNumber.footerPosition = 'bottom-left'\" style=\"flex:1; min-width:50px; font-size: 11px;\">\u0E0B\u0E49\u0E32\u0E22</button>\n                <button class=\"pn-format-btn\" [class.active]=\"pageNumber.footerPosition === 'bottom-center'\" (click)=\"pageNumber.footerPosition = 'bottom-center'\" style=\"flex:1; min-width:50px; font-size: 11px;\">\u0E01\u0E25\u0E32\u0E07</button>\n                <button class=\"pn-format-btn\" [class.active]=\"pageNumber.footerPosition === 'bottom-right'\" (click)=\"pageNumber.footerPosition = 'bottom-right'\" style=\"flex:1; min-width:50px; font-size: 11px;\">\u0E02\u0E27\u0E32</button>\n              </div>\n            </div>\n\n            <div class=\"pn-section-title\" style=\"margin-top: 10px;\">\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23</div>\n            <div class=\"pn-row\">\n              <label>\u0E1F\u0E2D\u0E19\u0E15\u0E4C</label>\n              <select [(ngModel)]=\"pageNumber.fontFamily\" class=\"pn-input\">\n                <option value=\"TH Sarabun New\">TH Sarabun New</option>\n                <option value=\"TH Sarabun IT9\">TH Sarabun IT9</option>\n                <option value=\"Noto Sans Thai\">Noto Sans Thai</option>\n              </select>\n            </div>\n            <div class=\"pn-row\">\n              <label>\u0E02\u0E19\u0E32\u0E14</label>\n              <input type=\"number\" [(ngModel)]=\"pageNumber.fontSize\" min=\"8\" max=\"36\" class=\"pn-input pn-input--sm\" />\n            </div>\n            <div class=\"pn-row\">\n              <label>\u0E2A\u0E35</label>\n              <div class=\"wm-color-wrap\">\n                <div class=\"wm-color-swatch\" [style.background]=\"pageNumber.color\"></div>\n                <input type=\"color\" [(ngModel)]=\"pageNumber.color\" />\n              </div>\n            </div>\n\n            <div class=\"pn-preview-box\" style=\"margin-top: 8px;\">\n              \u0E15\u0E31\u0E27\u0E2D\u0E22\u0E48\u0E32\u0E07: <strong [style.font-family]=\"pageNumber.fontFamily\" [style.font-size.px]=\"pageNumber.fontSize\" [style.color]=\"pageNumber.color\">{{ formatPageNum(pageNumber.startAtPage) }}</strong>\n            </div>\n          </div>\n          <div class=\"pn-panel__footer\">\n            <button class=\"wm-btn wm-btn--cancel\" (click)=\"removePageNumbers(); closePageNumberPanel()\">\n              <svg-icon name=\"trash-outline\"></svg-icon> \u0E25\u0E1A\n            </button>\n            <button class=\"wm-btn wm-btn--apply\" (click)=\"applyPageNumbers()\">\n              <svg-icon name=\"checkmark-outline\"></svg-icon> \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E15\u0E32\u0E21\u0E19\u0E35\u0E49\n            </button>\n          </div>\n        </div>\n      </div>\n\n      <!-- Split PDF -->\n      <div class=\"tool-item split-tool-item\" style=\"position: relative;\">\n        <button class=\"toolbar-btn toolbar-btn--labeled\" [class.active]=\"showSplitPanel\" (click)=\"toggleSplitPanel()\" title=\"\u0E41\u0E22\u0E01 PDF (\u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\u0E1A\u0E32\u0E07\u0E2B\u0E19\u0E49\u0E32)\">\n          <svg-icon name=\"cut-outline\"></svg-icon>\n          <small>\u0E41\u0E22\u0E01 PDF</small>\n        </button>\n\n        <div class=\"split-panel\" *ngIf=\"showSplitPanel\" style=\"position: absolute; top: calc(100% + 6px); right: 0; z-index: 1000; background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 280px; padding: 16px;\">\n          <div style=\"display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; padding-bottom:8px; margin-bottom:12px;\">\n            <strong style=\"color:#1e293b; display:flex; align-items:center; gap:6px;\">\n              <svg-icon name=\"cut-outline\"></svg-icon> \u0E41\u0E22\u0E01 PDF\n            </strong>\n            <button (click)=\"showSplitPanel = false\" style=\"background:none; border:none; cursor:pointer; font-size:18px;\">&times;</button>\n          </div>\n          <div style=\"margin-bottom:12px;\">\n            <label style=\"display:block; font-size:13px; color:#64748b; margin-bottom:6px;\">\u0E23\u0E30\u0E1A\u0E38\u0E2B\u0E19\u0E49\u0E32 (\u0E40\u0E0A\u0E48\u0E19 1, 3, 5-10):</label>\n            <input type=\"text\" [(ngModel)]=\"splitPageRange\" placeholder=\"1-{{ pageCount }}\" style=\"width:100%; padding:8px; border:1px solid #cbd5e1; border-radius:4px;\">\n          </div>\n          <button class=\"toolbar-btn toolbar-btn--save\" (click)=\"executeSplitPdf()\" style=\"width:100%; background:#10b981; color:#fff; border:none; border-radius:6px; padding:8px; font-weight:bold; justify-content:center;\">\n            \u0E14\u0E32\u0E27\u0E19\u0E4C\u0E42\u0E2B\u0E25\u0E14\n          </button>\n        </div>\n      </div>\n\n      <div class=\"toolbar-divider\"></div>\n\n      <!-- Undo/Redo -->\n      <button class=\"toolbar-btn\" (click)=\"undo()\" [disabled]=\"!canUndo()\" title=\"\u0E40\u0E25\u0E34\u0E01\u0E17\u0E33\">\n        <svg-icon name=\"arrow-undo\"></svg-icon>\n      </button>\n      <button class=\"toolbar-btn\" (click)=\"redo()\" [disabled]=\"!canRedo()\" title=\"\u0E17\u0E33\u0E0B\u0E49\u0E33\">\n        <svg-icon name=\"arrow-redo\"></svg-icon>\n      </button>\n      <button class=\"toolbar-btn toolbar-btn--danger\" (click)=\"clearAnnotations()\" title=\"\u0E25\u0E49\u0E32\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14\">\n        <svg-icon name=\"trash\"></svg-icon>\n      </button>\n    </div>\n\n    <!-- Main Content Area: Thumbnails + Viewer -->\n    <div class=\"main-area\">\n\n      <!-- Left Thumbnails Sidebar -->\n      <aside class=\"thumbnails-sidebar\" *ngIf=\"showThumbnails\">\n        <div class=\"thumb-list\" (scroll)=\"onThumbScroll($event)\">\n\n          <!-- Top insert button (before page 1) -->\n          <div class=\"thumb-insert-row\">\n            <button class=\"thumb-add-btn\" (click)=\"toggleThumbInsert(0, $event)\" title=\"\u0E41\u0E17\u0E23\u0E01\u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E19\u0E49\u0E32 1\">\n              <svg-icon name=\"add\"></svg-icon>\n            </button>\n          </div>\n\n          <!-- Each thumbnail + its action bar + insert button after it -->\n          <ng-container *ngFor=\"let thumb of pageThumbnails; let i = index\">\n\n            <!-- Thumbnail card wrapper -->\n            <div class=\"thumb-card-wrap\"\n              draggable=\"true\"\n              [class.thumb-card-wrap--dragging]=\"thumbDragFromIndex === i\"\n              [class.thumb-card-wrap--drop-top]=\"thumbDragOverIndex === i && thumbDragFromIndex !== null && thumbDragFromIndex > i\"\n              [class.thumb-card-wrap--drop-bot]=\"thumbDragOverIndex === i && thumbDragFromIndex !== null && thumbDragFromIndex < i\"\n              (dragstart)=\"onThumbDragStart(i)\"\n              (dragover)=\"$event.preventDefault(); onThumbDragOver(i)\"\n              (dragleave)=\"onThumbDragLeave()\"\n              (drop)=\"$event.preventDefault(); onThumbDrop(i)\"\n              (dragend)=\"onThumbDragEnd()\">\n              <!-- Clickable thumbnail -->\n              <div class=\"thumb-card\" [class.active]=\"pageNo === i + 1\"\n                [id]=\"'thumb-' + (i + 1)\" (click)=\"goToPage(i + 1)\">\n                <div class=\"thumb-card__img-wrap\">\n                  <img [src]=\"thumb\" [alt]=\"'Page ' + (i + 1)\">\n                </div>\n                <span class=\"thumb-card__label\">{{ i + 1 }}</span>\n              </div>\n\n              <!-- Per-page action bar -->\n              <div class=\"thumb-card__actions\" (click)=\"$event.stopPropagation()\">\n                <button class=\"thumb-action-btn\" (click)=\"movePageToIndex(i + 1, 'up')\"\n                  [disabled]=\"i === 0\" title=\"\u0E40\u0E25\u0E37\u0E48\u0E2D\u0E19\u0E02\u0E36\u0E49\u0E19\">\n                  <svg-icon name=\"chevron-up-outline\"></svg-icon>\n                </button>\n                <button class=\"thumb-action-btn\" (click)=\"movePageToIndex(i + 1, 'down')\"\n                  [disabled]=\"i === pageThumbnails.length - 1\" title=\"\u0E40\u0E25\u0E37\u0E48\u0E2D\u0E19\u0E25\u0E07\">\n                  <svg-icon name=\"chevron-down-outline\"></svg-icon>\n                </button>\n                <button class=\"thumb-action-btn\" (click)=\"promptMovePage(i + 1)\"\n                  [disabled]=\"pageCount <= 1\" title=\"\u0E22\u0E49\u0E32\u0E22\u0E44\u0E1B\u0E2B\u0E19\u0E49\u0E32...\">\n                  <svg-icon name=\"move-outline\"></svg-icon>\n                </button>\n                <button class=\"thumb-action-btn\" (click)=\"undoPageOp()\"\n                  [disabled]=\"!canUndoPageOp\" title=\"\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A\">\n                  <svg-icon name=\"arrow-undo-outline\"></svg-icon>\n                </button>\n                <button class=\"thumb-action-btn thumb-action-btn--danger\"\n                  (click)=\"deleteSpecificPage(i + 1)\" [disabled]=\"pageCount <= 1\" title=\"\u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\">\n                  <svg-icon name=\"trash-outline\"></svg-icon>\n                </button>\n              </div>\n            </div>\n\n            <!-- Insert button after each page -->\n            <div class=\"thumb-insert-row\">\n              <button class=\"thumb-add-btn\" (click)=\"toggleThumbInsert(i + 1, $event)\" title=\"\u0E41\u0E17\u0E23\u0E01\u0E2B\u0E19\u0E49\u0E32\">\n                <svg-icon name=\"add\"></svg-icon>\n              </button>\n            </div>\n\n          </ng-container>\n\n        </div>\n\n        <!-- Hidden file input -->\n        <input type=\"file\" #thumbFileInput accept=\"image/*,.pdf\" style=\"display:none\"\n          (change)=\"onThumbFileSelected($event)\">\n\n      </aside>\n\n      <!-- Insert Dropdown Overlay (outside aside \u2014 fixed position, no clipping) -->\n      <div class=\"thumb-insert-overlay\" *ngIf=\"thumbInsertIndex >= 0\"\n        [style.top.px]=\"thumbDropdownTop\">\n        <div class=\"thumb-insert-backdrop\" (click)=\"thumbInsertIndex = -1\"></div>\n        <div class=\"thumb-insert-menu\">\n          <button class=\"thumb-insert-opt\" (click)=\"insertAtThumb(thumbInsertIndex, 'portrait')\">\n            <svg-icon name=\"phone-portrait-outline\"></svg-icon>\n            \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E48\u0E32 \u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07\n          </button>\n          <button class=\"thumb-insert-opt\" (click)=\"insertAtThumb(thumbInsertIndex, 'landscape')\">\n            <svg-icon name=\"phone-landscape-outline\"></svg-icon>\n            \u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E48\u0E32 \u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19\n          </button>\n          <button class=\"thumb-insert-opt\" (click)=\"triggerThumbFileUpload(thumbInsertIndex)\">\n            <svg-icon name=\"document-outline\"></svg-icon>\n            \u0E41\u0E17\u0E23\u0E01\u0E44\u0E1F\u0E25\u0E4C PDF/\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\n          </button>\n        </div>\n      </div>\n\n      <!-- Viewer -->\n      <div class=\"viewer-wrapper\">\n        <!-- Stamp placement banner -->\n        <div class=\"stamp-place-banner\" *ngIf=\"pendingStamp\">\n          <span><svg-icon name=\"business-outline\"></svg-icon> \u0E04\u0E25\u0E34\u0E01\u0E1A\u0E19 PDF \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E27\u0E32\u0E07\u0E15\u0E23\u0E32\u0E22\u0E32\u0E07</span>\n          <button (click)=\"cancelPendingStamp()\"><svg-icon name=\"close-outline\"></svg-icon> \u0E22\u0E01\u0E40\u0E25\u0E34\u0E01 (ESC)</button>\n        </div>\n\n        <!-- Deskew Panel Overlay -->\n        <div class=\"deskew-panel\" *ngIf=\"showDeskewPanel\">\n          <div class=\"deskew-panel__header\">\n            <svg-icon name=\"sync-outline\"></svg-icon> \u0E2B\u0E21\u0E38\u0E19\u0E08\u0E31\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E23\u0E07 (\u0E2B\u0E19\u0E49\u0E32 {{ pageNo }})\n          </div>\n          <div class=\"deskew-panel__body\">\n            <button class=\"toolbar-btn\" (click)=\"setPageRotation(pageNo, (pageRotations[pageNo] || 0) - 90)\" title=\"\u0E2B\u0E21\u0E38\u0E19\u0E0B\u0E49\u0E32\u0E22 90\u00B0\">\n              <svg-icon name=\"refresh-outline\" style=\"transform: scaleX(-1);\"></svg-icon>\n            </button>\n\n            <div class=\"deskew-slider-container\">\n              <span class=\"deskew-angle\">{{ (pageRotations[pageNo] || 0) | number:'1.1-1' }}\u00B0</span>\n              <input type=\"range\" min=\"-15\" max=\"15\" step=\"0.1\"\n                     [ngModel]=\"pageRotations[pageNo] || 0\"\n                     (ngModelChange)=\"setPageRotation(pageNo, $event)\"\n                     class=\"deskew-slider\">\n              <div class=\"deskew-slider-ticks\">\n                <span>-15</span><span>0</span><span>+15</span>\n              </div>\n            </div>\n\n            <button class=\"toolbar-btn\" (click)=\"setPageRotation(pageNo, (pageRotations[pageNo] || 0) + 90)\" title=\"\u0E2B\u0E21\u0E38\u0E19\u0E02\u0E27\u0E32 90\u00B0\">\n              <svg-icon name=\"refresh-outline\"></svg-icon>\n            </button>\n          </div>\n          <div class=\"deskew-panel__footer\">\n            <button class=\"toolbar-btn toolbar-btn--danger\" (click)=\"resetPageRotation(pageNo)\">\u0E04\u0E37\u0E19\u0E04\u0E48\u0E32\u0E40\u0E14\u0E34\u0E21</button>\n            <button class=\"toolbar-btn toolbar-btn--save\" (click)=\"applyDeskew()\">\u0E15\u0E01\u0E25\u0E07</button>\n          </div>\n        </div>\n\n        <div class=\"viewer-container\" #viewerContainer (scroll)=\"onViewerScroll($event)\">\n          <!-- Render all pages for continuous scroll -->\n          <div *ngFor=\"let p of pages\" class=\"page-container\" [attr.data-page]=\"p\" [id]=\"'page-' + p\"\n            [class.stamp-place-mode]=\"!!pendingStamp\"\n            [class.flip-mode]=\"!!getPageFlip(p)\"\n            [class.deskew-mode]=\"showDeskewPanel\"\n            [style.transform]=\"getPageRotation(p) ? 'rotate(' + getPageRotation(p) + 'deg)' : null\"\n            (pointermove)=\"onStampGhostMove($event, p)\"\n            (pointerdown)=\"onStampGhostClick($event, p)\">\n            <canvas [id]=\"'pdfCanvas-' + p\" class=\"pdf-canvas\"></canvas>\n            <canvas [id]=\"'annotCanvas-' + p\" class=\"annot-canvas\" [class.tools-active]=\"toolMode !== 'none'\"></canvas>\n\n            <!-- Watermark Preview Overlay -->\n            <div class=\"wm-preview-overlay\" [ngStyle]=\"getWatermarkPreviewStyle(p)\">\n              <div class=\"wm-preview-content\"\n                [style.opacity]=\"watermark.opacity / 100\"\n                [style.transform]=\"'rotate(-' + watermark.rotation + 'deg)'\"\n                [style.color]=\"watermark.color\"\n                [style.font-size.px]=\"watermark.type === 'text' ? watermark.fontSize * zoom : 0\"\n                [style.font-family]=\"watermark.fontFamily\">\n                <ng-container *ngIf=\"watermark.type === 'text'\">\n                  <ng-container *ngIf=\"watermark.mode === 'center'\">\n                    <span class=\"wm-text-center\">{{ watermark.text }}</span>\n                  </ng-container>\n                  <ng-container *ngIf=\"watermark.mode === 'tiled'\">\n                    <span class=\"wm-text-tiled\">{{ watermark.text }}</span>\n                  </ng-container>\n                </ng-container>\n                <ng-container *ngIf=\"watermark.type === 'image' && watermark.imageDataUrl\">\n                  <img [src]=\"watermark.imageDataUrl\" class=\"wm-preview-img\" />\n                </ng-container>\n              </div>\n            </div>\n\n            <!-- Page Number Preview -->\n            <div class=\"pn-preview\" *ngIf=\"pageNumber.enabled && shouldShowPageNum(p)\" [ngStyle]=\"getPageNumPositionStyle(p)\">\n              <span [style.font-family]=\"pageNumber.fontFamily\"\n                [style.font-size.px]=\"pageNumber.fontSize * zoom\"\n                [style.color]=\"pageNumber.color\">{{ formatPageNum(p) }}</span>\n            </div>\n\n            <!-- TextBoxes for this page -->\n            <div *ngFor=\"let tb of getTextBoxesForPage(p)\" class=\"text-box\" [attr.data-tbid]=\"tb.id\" [class.active]=\"activeTextBoxId === tb.id\"\n              [style.left.%]=\"tb.x\" [style.top.%]=\"tb.y\" [style.width.%]=\"tb.width\" [style.height.%]=\"tb.height\"\n              [style.color]=\"tb.color\" [style.font-size.px]=\"tb.fontSize * zoom\"\n              [style.font-weight]=\"tb.bold ? 'bold' : 'normal'\" [style.font-style]=\"tb.italic ? 'italic' : 'normal'\"\n              [style.text-align]=\"tb.align\" [style.z-index]=\"tb.zIndex || 10\"\n              [style.font-family]=\"(tb.fontFamily || 'THSarabunNew') + ', sans-serif'\"\n              [style.opacity]=\"tb.opacity !== undefined ? tb.opacity : 1\"\n              [style.transform]=\"tb.rotation ? 'rotate(' + tb.rotation + 'deg)' : null\"\n              [style.letter-spacing.px]=\"tb.letterSpacing || 0\"\n              [style.line-height]=\"tb.lineHeight || 1.4\"\n              (pointerdown)=\"startDrag($event, tb.id)\" (contextmenu)=\"onContextMenu($event, tb.id, 'text')\">\n\n              <!-- Floating toolbar \u2014 shown above the text box when active -->\n              <div class=\"tb-floating-bar\" *ngIf=\"activeTextBoxId === tb.id\" (pointerdown)=\"$event.stopPropagation()\" (click)=\"lsDropOpenId = null; $event.stopPropagation()\">\n                <!-- Bold / Italic -->\n                <button class=\"tb-bar-btn\" [class.tb-bar-btn--active]=\"tb.bold\" (click)=\"toggleBold()\" title=\"\u0E15\u0E31\u0E27\u0E2B\u0E19\u0E32\"><b>B</b></button>\n                <button class=\"tb-bar-btn tb-bar-btn--italic\" [class.tb-bar-btn--active]=\"tb.italic\" (click)=\"toggleItalic()\" title=\"\u0E15\u0E31\u0E27\u0E40\u0E2D\u0E35\u0E22\u0E07\"><i>I</i></button>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Alignment -->\n                <button class=\"tb-bar-btn\" [class.tb-bar-btn--active]=\"tb.align === 'left'\" (click)=\"setAlign('left')\" title=\"\u0E0A\u0E34\u0E14\u0E0B\u0E49\u0E32\u0E22\">\n                  <svg width=\"15\" height=\"13\" viewBox=\"0 0 15 13\"><line x1=\"0\" y1=\"1.5\" x2=\"15\" y2=\"1.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"0\" y1=\"6.5\" x2=\"10\" y2=\"6.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"0\" y1=\"11.5\" x2=\"13\" y2=\"11.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>\n                </button>\n                <button class=\"tb-bar-btn\" [class.tb-bar-btn--active]=\"tb.align === 'center'\" (click)=\"setAlign('center')\" title=\"\u0E01\u0E36\u0E48\u0E07\u0E01\u0E25\u0E32\u0E07\">\n                  <svg width=\"15\" height=\"13\" viewBox=\"0 0 15 13\"><line x1=\"0\" y1=\"1.5\" x2=\"15\" y2=\"1.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"2.5\" y1=\"6.5\" x2=\"12.5\" y2=\"6.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"1\" y1=\"11.5\" x2=\"14\" y2=\"11.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>\n                </button>\n                <button class=\"tb-bar-btn\" [class.tb-bar-btn--active]=\"tb.align === 'right'\" (click)=\"setAlign('right')\" title=\"\u0E0A\u0E34\u0E14\u0E02\u0E27\u0E32\">\n                  <svg width=\"15\" height=\"13\" viewBox=\"0 0 15 13\"><line x1=\"0\" y1=\"1.5\" x2=\"15\" y2=\"1.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"5\" y1=\"6.5\" x2=\"15\" y2=\"6.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"2\" y1=\"11.5\" x2=\"15\" y2=\"11.5\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/></svg>\n                </button>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Font family -->\n                <select class=\"tb-bar-select\" [ngModel]=\"tb.fontFamily || 'THSarabunNew'\" (ngModelChange)=\"setTbFontFamily(tb, $event)\">\n                  <option value=\"THSarabunNew\">TH Sarabun New</option>\n                  <option value=\"Noto Sans Thai Looped\">Noto Sans Thai</option>\n                  <option value=\"Arial\">Arial</option>\n                  <option value=\"sans-serif\">Sans-serif</option>\n                </select>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Font size -->\n                <button class=\"tb-bar-btn\" (click)=\"changeTextFontSize(-2)\" [disabled]=\"tb.fontSize <= 8\" title=\"\u0E25\u0E14\u0E02\u0E19\u0E32\u0E14\"><svg-icon name=\"remove\"></svg-icon></button>\n                <span class=\"tb-bar-val\">{{ tb.fontSize }}</span>\n                <button class=\"tb-bar-btn\" (click)=\"changeTextFontSize(2)\" [disabled]=\"tb.fontSize >= 100\" title=\"\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E02\u0E19\u0E32\u0E14\"><svg-icon name=\"add\"></svg-icon></button>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Letter spacing -->\n                <span class=\"tb-bar-lbl\" title=\"\u0E23\u0E30\u0E22\u0E30\u0E2B\u0E48\u0E32\u0E07\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23\">AZ</span>\n                <div class=\"tb-ls-wrap\" (click)=\"$event.stopPropagation()\">\n                  <button class=\"tb-ls-trigger\" (click)=\"toggleLsDrop(tb.id)\" title=\"\u0E23\u0E30\u0E22\u0E30\u0E2B\u0E48\u0E32\u0E07\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23\">\n                    <span>{{ (tb.letterSpacing ?? 0) >= 0 ? '+' : '' }}{{ tb.letterSpacing ?? 0 }}</span>\n                    <svg width=\"8\" height=\"5\" viewBox=\"0 0 8 5\"><polyline points=\"0.5,0.5 4,4.5 7.5,0.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></svg>\n                  </button>\n                  <div class=\"tb-ls-drop\" *ngIf=\"lsDropOpenId === tb.id\">\n                    <button class=\"tb-ls-opt\" *ngFor=\"let v of lsPresets\"\n                            [class.tb-ls-opt--checked]=\"(tb.letterSpacing ?? 0) === v\"\n                            (click)=\"pickLetterSpacing(tb, v)\">\n                      <svg-icon name=\"checkmark\" *ngIf=\"(tb.letterSpacing ?? 0) === v\"></svg-icon>\n                      <span *ngIf=\"(tb.letterSpacing ?? 0) !== v\" class=\"tb-ls-spacer\"></span>\n                      <span>{{ v >= 0 ? '+' + v : v }}</span>\n                    </button>\n                  </div>\n                </div>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Line height -->\n                <span class=\"tb-bar-lbl\" title=\"\u0E23\u0E30\u0E22\u0E30\u0E2B\u0E48\u0E32\u0E07\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\">\n                  <svg width=\"16\" height=\"14\" viewBox=\"0 0 16 14\" style=\"display:block\">\n                    <line x1=\"5\" y1=\"1.5\" x2=\"16\" y2=\"1.5\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n                    <line x1=\"5\" y1=\"7\"   x2=\"16\" y2=\"7\"   stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n                    <line x1=\"5\" y1=\"12.5\" x2=\"16\" y2=\"12.5\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>\n                    <line x1=\"2\" y1=\"1.5\" x2=\"2\" y2=\"12.5\" stroke=\"currentColor\" stroke-width=\"1.2\"/>\n                    <polyline points=\"0.5,4 2,1.5 3.5,4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linejoin=\"round\"/>\n                    <polyline points=\"0.5,10 2,12.5 3.5,10\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.2\" stroke-linejoin=\"round\"/>\n                  </svg>\n                </span>\n                <div class=\"tb-bar-stepper\">\n                  <span class=\"tb-bar-stepper-val\">{{ (tb.lineHeight ?? 1.4) | number:'1.1-1' }}</span>\n                  <div class=\"tb-bar-stepper-arrows\">\n                    <button class=\"tb-bar-stepper-up\" (click)=\"changeTbLineHeight(tb, 0.1)\" [disabled]=\"(tb.lineHeight ?? 1.4) >= 4\">\n                      <svg width=\"8\" height=\"5\" viewBox=\"0 0 8 5\"><polyline points=\"0.5,4.5 4,0.5 7.5,4.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></svg>\n                    </button>\n                    <button class=\"tb-bar-stepper-dn\" (click)=\"changeTbLineHeight(tb, -0.1)\" [disabled]=\"(tb.lineHeight ?? 1.4) <= 1\">\n                      <svg width=\"8\" height=\"5\" viewBox=\"0 0 8 5\"><polyline points=\"0.5,0.5 4,4.5 7.5,0.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></svg>\n                    </button>\n                  </div>\n                </div>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Color -->\n                <div class=\"tb-bar-color\" [style.background]=\"tb.color\" title=\"\u0E2A\u0E35\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\">\n                  <input type=\"color\" [value]=\"tb.color\" (input)=\"setTextColor($any($event.target).value)\" />\n                </div>\n                <span class=\"tb-bar-sep\"></span>\n                <!-- Delete -->\n                <button class=\"tb-bar-btn tb-bar-btn--delete\" (click)=\"removeTextBox(tb.id)\" title=\"\u0E25\u0E1A\">\n                  <svg-icon name=\"trash\"></svg-icon>\n                </button>\n              </div>\n\n              <div class=\"tb-handle tb-handle--left\" (pointerdown)=\"startResizeLeft($event, tb.id)\"></div>\n              <textarea [(ngModel)]=\"tb.text\" (focus)=\"activeTextBoxId = tb.id\" (input)=\"onTextBoxInput($event, tb)\"\n                spellcheck=\"false\"></textarea>\n              <div class=\"tb-handle tb-handle--right\" (pointerdown)=\"startResizeRight($event, tb.id)\"></div>\n              <!-- BR corner: resize width + height -->\n              <div class=\"tb-handle tb-handle--br\" (pointerdown)=\"startResize($event, tb.id)\" title=\"\u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14\"></div>\n            </div>\n            <!-- ShapeStamps for this page (draggable/resizable SVG overlays) -->\n            <div *ngFor=\"let ss of getShapeStampsForPage(p)\" class=\"shape-stamp\" [style.left.%]=\"ss.x\"\n              [style.top.%]=\"ss.y\" [style.width.%]=\"ss.width\" [style.height.%]=\"ss.height\"\n              [style.z-index]=\"ss.zIndex || 10\" (pointerdown)=\"startShapeDrag($event, ss.id)\"\n              (contextmenu)=\"onContextMenu($event, ss.id, 'shape')\">\n              <button class=\"remove-btn\" (click)=\"removeShapeStamp(ss.id); $event.stopPropagation()\"><svg-icon name=\"close-outline\"></svg-icon></button>\n\n              <!-- SVG renders the actual shape inside the bounding box -->\n              <svg width=\"100%\" height=\"100%\" [attr.viewBox]=\"'0 0 100 100'\" preserveAspectRatio=\"none\"\n                style=\"overflow:visible; pointer-events:none\">\n                <!-- rect -->\n                <rect *ngIf=\"ss.type === 'rect'\" x=\"0\" y=\"0\" width=\"100\" height=\"100\"\n                  [attr.stroke]=\"ss.strokeColor || 'none'\" [attr.stroke-width]=\"ss.strokeWidth\"\n                  vector-effect=\"non-scaling-stroke\" [attr.fill]=\"ss.fillColor || 'none'\"></rect>\n                <!-- circle -->\n                <ellipse *ngIf=\"ss.type === 'circle'\" cx=\"50\" cy=\"50\" rx=\"50\" ry=\"50\"\n                  [attr.stroke]=\"ss.strokeColor || 'none'\" [attr.stroke-width]=\"ss.strokeWidth\"\n                  vector-effect=\"non-scaling-stroke\" [attr.fill]=\"ss.fillColor || 'none'\"></ellipse>\n                <!-- line -->\n                <line *ngIf=\"ss.type === 'line'\" [attr.x1]=\"ss.startFracX * 100\" [attr.y1]=\"ss.startFracY * 100\"\n                  [attr.x2]=\"ss.endFracX * 100\" [attr.y2]=\"ss.endFracY * 100\" [attr.stroke]=\"ss.strokeColor || '#000'\"\n                  [attr.stroke-width]=\"ss.strokeWidth\" vector-effect=\"non-scaling-stroke\" fill=\"none\"></line>\n                <!-- arrow -->\n                <g *ngIf=\"ss.type === 'arrow'\">\n                  <line [attr.x1]=\"ss.startFracX * 100\" [attr.y1]=\"ss.startFracY * 100\" [attr.x2]=\"ss.endFracX * 100\"\n                    [attr.y2]=\"ss.endFracY * 100\" [attr.stroke]=\"ss.strokeColor || '#000'\"\n                    [attr.stroke-width]=\"ss.strokeWidth\" vector-effect=\"non-scaling-stroke\" fill=\"none\">\n                  </line>\n                  <polygon [attr.points]=\"'0,-6 12,0 0,6'\" [attr.fill]=\"ss.strokeColor || '#000'\"\n                    [attr.transform]=\"'translate(' + (ss.endFracX*100) + ',' + (ss.endFracY*100) + ') rotate(' + getArrowAngleDeg(ss) + ')'\">\n                  </polygon>\n                </g>\n              </svg>\n\n              <!-- Resize handles (corner + edge) -->\n              <div class=\"resize-handle rh-nw\" (pointerdown)=\"startShapeResize($event, ss.id, 'nw')\"></div>\n              <div class=\"resize-handle rh-n\" (pointerdown)=\"startShapeResize($event, ss.id, 'n')\"></div>\n              <div class=\"resize-handle rh-ne\" (pointerdown)=\"startShapeResize($event, ss.id, 'ne')\"></div>\n              <div class=\"resize-handle rh-e\" (pointerdown)=\"startShapeResize($event, ss.id, 'e')\"></div>\n              <div class=\"resize-handle rh-se\" (pointerdown)=\"startShapeResize($event, ss.id, 'se')\"></div>\n              <div class=\"resize-handle rh-s\" (pointerdown)=\"startShapeResize($event, ss.id, 's')\"></div>\n              <div class=\"resize-handle rh-sw\" (pointerdown)=\"startShapeResize($event, ss.id, 'sw')\"></div>\n              <div class=\"resize-handle rh-w\" (pointerdown)=\"startShapeResize($event, ss.id, 'w')\"></div>\n            </div>\n\n            <!-- Regular image stamps (uploaded images, not marks) -->\n            <div *ngFor=\"let img of getRegularImageStampsForPage(p)\" class=\"image-stamp\"\n              [style.left.%]=\"img.x\"\n              [style.top.%]=\"img.y\" [style.width.%]=\"img.width\" [style.height.%]=\"img.height\"\n              [style.z-index]=\"img.zIndex || 10\" (pointerdown)=\"startImageDrag($event, img.id)\"\n              (contextmenu)=\"onContextMenu($event, img.id, 'image')\">\n              <button class=\"remove-btn\" (click)=\"removeImage(img.id); $event.stopPropagation()\"><svg-icon name=\"close-outline\"></svg-icon></button>\n              <img [src]=\"img.dataUrl\" />\n              <div class=\"resize-handle rh-nw\" (pointerdown)=\"startImageResize($event, img.id, 'nw')\"></div>\n              <div class=\"resize-handle rh-n\" (pointerdown)=\"startImageResize($event, img.id, 'n')\"></div>\n              <div class=\"resize-handle rh-ne\" (pointerdown)=\"startImageResize($event, img.id, 'ne')\"></div>\n              <div class=\"resize-handle rh-e\" (pointerdown)=\"startImageResize($event, img.id, 'e')\"></div>\n              <div class=\"resize-handle rh-se\" (pointerdown)=\"startImageResize($event, img.id, 'se')\"></div>\n              <div class=\"resize-handle rh-s\" (pointerdown)=\"startImageResize($event, img.id, 's')\"></div>\n              <div class=\"resize-handle rh-sw\" (pointerdown)=\"startImageResize($event, img.id, 'sw')\"></div>\n              <div class=\"resize-handle rh-w\" (pointerdown)=\"startImageResize($event, img.id, 'w')\"></div>\n            </div>\n\n            <!-- Mark stamps (check/cross/dot) \u2014 rendered as SVG, behaves like form field checkbox -->\n            <div *ngFor=\"let mk of getMarkStampsForPage(p)\" class=\"pdf-form-field pff-mark\"\n              [class.pff-active]=\"activeObjectId === mk.id\"\n              [style.left.%]=\"mk.x\" [style.top.%]=\"mk.y\"\n              [style.width.%]=\"mk.width\" [style.height.%]=\"mk.height\"\n              [style.z-index]=\"mk.zIndex || 10\"\n              (pointerdown)=\"startMarkDrag($event, mk.id)\"\n              (contextmenu)=\"onContextMenu($event, mk.id, 'image')\">\n\n              <!-- Options bar when active -->\n              <div class=\"pff-options-bar\" *ngIf=\"activeObjectId === mk.id\" (pointerdown)=\"$event.stopPropagation()\">\n                <span class=\"pff-opt-label\"><svg-icon name=\"resize-outline\"></svg-icon></span>\n                <button class=\"pff-opt-btn\" (click)=\"changeMarkStampSize(mk.id, -1)\" [disabled]=\"mk.width <= 1\" title=\"\u0E25\u0E14\u0E02\u0E19\u0E32\u0E14\">\n                  <svg-icon name=\"remove\"></svg-icon>\n                </button>\n                <span class=\"pff-opt-val\">{{ mk.width | number:'1.0-1' }}</span>\n                <button class=\"pff-opt-btn\" (click)=\"changeMarkStampSize(mk.id, 1)\" [disabled]=\"mk.width >= 25\" title=\"\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E02\u0E19\u0E32\u0E14\">\n                  <svg-icon name=\"add\"></svg-icon>\n                </button>\n                <div class=\"pff-opt-sep\"></div>\n                <button class=\"pff-opt-btn pff-opt-delete\" (click)=\"removeImage(mk.id); $event.stopPropagation()\" title=\"\u0E25\u0E1A\">\n                  <svg-icon name=\"trash-outline\"></svg-icon>\n                </button>\n              </div>\n\n              <!-- SVG mark symbol fills the bounding box exactly -->\n              <div class=\"pff-inner\">\n                <svg width=\"100%\" height=\"100%\" viewBox=\"0 0 100 100\" style=\"pointer-events:none; overflow:visible\">\n                  <ng-container *ngIf=\"mk.markType === 'check'\">\n                    <polyline points=\"12,52 42,82 88,18\" [attr.stroke]=\"mk.markColor || '#000000'\" stroke-width=\"10\" stroke-linecap=\"round\" stroke-linejoin=\"round\" fill=\"none\"/>\n                  </ng-container>\n                  <ng-container *ngIf=\"mk.markType === 'cross'\">\n                    <line x1=\"15\" y1=\"15\" x2=\"85\" y2=\"85\" [attr.stroke]=\"mk.markColor || '#000000'\" stroke-width=\"10\" stroke-linecap=\"round\"/>\n                    <line x1=\"85\" y1=\"15\" x2=\"15\" y2=\"85\" [attr.stroke]=\"mk.markColor || '#000000'\" stroke-width=\"10\" stroke-linecap=\"round\"/>\n                  </ng-container>\n                  <ng-container *ngIf=\"mk.markType === 'dot' || !mk.markType\">\n                    <circle cx=\"50\" cy=\"50\" r=\"38\" [attr.fill]=\"mk.markColor || '#000000'\"/>\n                  </ng-container>\n                </svg>\n              </div>\n\n              <div class=\"pff-resize-handle rh-nw\" (pointerdown)=\"startImageResize($event, mk.id, 'nw')\"></div>\n              <div class=\"pff-resize-handle rh-n\"  (pointerdown)=\"startImageResize($event, mk.id, 'n')\"></div>\n              <div class=\"pff-resize-handle rh-ne\" (pointerdown)=\"startImageResize($event, mk.id, 'ne')\"></div>\n              <div class=\"pff-resize-handle rh-e\"  (pointerdown)=\"startImageResize($event, mk.id, 'e')\"></div>\n              <div class=\"pff-resize-handle rh-se\" (pointerdown)=\"startImageResize($event, mk.id, 'se')\"></div>\n              <div class=\"pff-resize-handle rh-s\"  (pointerdown)=\"startImageResize($event, mk.id, 's')\"></div>\n              <div class=\"pff-resize-handle rh-sw\" (pointerdown)=\"startImageResize($event, mk.id, 'sw')\"></div>\n              <div class=\"pff-resize-handle rh-w\"  (pointerdown)=\"startImageResize($event, mk.id, 'w')\"></div>\n            </div>\n\n            <div *ngFor=\"let sig of getSignatureStampsForPage(p)\" class=\"signature-stamp\" [style.left.%]=\"sig.x\"\n              [style.top.%]=\"sig.y\" [style.width.%]=\"sig.width\" [style.height.%]=\"sig.height\"\n              [style.z-index]=\"sig.zIndex || 10\" (pointerdown)=\"startSignatureDrag($event, sig.id)\"\n              (contextmenu)=\"onContextMenu($event, sig.id, 'signature')\">\n              <button class=\"remove-btn\" (click)=\"removeSignature(sig.id); $event.stopPropagation()\"><svg-icon name=\"close-outline\"></svg-icon></button>\n              <img [src]=\"sig.dataUrl\" />\n              <div class=\"digital-id-label\" *ngIf=\"showDigitalId && (sig.digitalId || sig.signDate)\">\n                <span *ngIf=\"sig.signDate\">{{ sig.signDate }}</span>\n                <span *ngIf=\"sig.signTime\">{{ sig.signTime }}</span>\n                <span *ngIf=\"sig.digitalId\" class=\"did-text\">{{ sig.digitalId }}</span>\n              </div>\n              <div class=\"resize-handle rh-nw\" (pointerdown)=\"startSignatureResize($event, sig.id, 'nw')\"></div>\n              <div class=\"resize-handle rh-n\" (pointerdown)=\"startSignatureResize($event, sig.id, 'n')\"></div>\n              <div class=\"resize-handle rh-ne\" (pointerdown)=\"startSignatureResize($event, sig.id, 'ne')\"></div>\n              <div class=\"resize-handle rh-e\" (pointerdown)=\"startSignatureResize($event, sig.id, 'e')\"></div>\n              <div class=\"resize-handle rh-se\" (pointerdown)=\"startSignatureResize($event, sig.id, 'se')\"></div>\n              <div class=\"resize-handle rh-s\" (pointerdown)=\"startSignatureResize($event, sig.id, 's')\"></div>\n              <div class=\"resize-handle rh-sw\" (pointerdown)=\"startSignatureResize($event, sig.id, 'sw')\"></div>\n              <div class=\"resize-handle rh-w\" (pointerdown)=\"startSignatureResize($event, sig.id, 'w')\"></div>\n            </div>\n\n            <!-- PDF Form Fields for this page -->\n            <div *ngFor=\"let ff of getFormFieldsForPage(p)\" class=\"pdf-form-field\"\n              [class.pff-text]=\"ff.type === 'text'\"\n              [class.pff-checkbox]=\"ff.type === 'checkbox'\"\n              [class.pff-radio]=\"ff.type === 'radio'\"\n              [class.pff-no-border]=\"ff.borderVisible === false\"\n              [class.pff-active]=\"activeFormFieldId === ff.id\"\n              [style.left.%]=\"ff.x\" [style.top.%]=\"ff.y\"\n              [style.width.%]=\"ff.width\" [style.height.%]=\"ff.height\"\n              [style.z-index]=\"ff.zIndex || 20\"\n              (pointerdown)=\"startFormFieldDrag($event, ff.id)\">\n\n              <!-- Options bar (shown when active) -->\n              <div class=\"pff-options-bar\" *ngIf=\"activeFormFieldId === ff.id\" (pointerdown)=\"$event.stopPropagation()\">\n                <!-- Element size: all 3 types -->\n                <span class=\"pff-opt-label\">\n                  <svg-icon name=\"resize-outline\"></svg-icon>\n                </span>\n                <button class=\"pff-opt-btn\" (click)=\"changeFormFieldSize(ff.id, -0.5)\" [disabled]=\"(ff.type === 'text' ? ff.height : ff.width) <= 1.5\" title=\"\u0E25\u0E14\u0E02\u0E19\u0E32\u0E14\">\n                  <svg-icon name=\"remove\"></svg-icon>\n                </button>\n                <span class=\"pff-opt-val\">{{ (ff.type === 'text' ? ff.height : ff.width) | number:'1.0-1' }}</span>\n                <button class=\"pff-opt-btn\" (click)=\"changeFormFieldSize(ff.id, 0.5)\" [disabled]=\"(ff.type === 'text' ? ff.height : ff.width) >= 30\" title=\"\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E02\u0E19\u0E32\u0E14\">\n                  <svg-icon name=\"add\"></svg-icon>\n                </button>\n                <div class=\"pff-opt-sep\"></div>\n                <!-- Font size: text only -->\n                <ng-container *ngIf=\"ff.type === 'text'\">\n                  <span class=\"pff-opt-label\">A</span>\n                  <button class=\"pff-opt-btn\" (click)=\"changeFormFieldFontSize(ff.id, -2)\" [disabled]=\"(ff.fontSize || 12) <= 6\" title=\"\u0E25\u0E14\u0E02\u0E19\u0E32\u0E14\u0E2D\u0E31\u0E01\u0E29\u0E23\">\n                    <svg-icon name=\"remove\"></svg-icon>\n                  </button>\n                  <span class=\"pff-opt-val\">{{ ff.fontSize || 12 }}</span>\n                  <button class=\"pff-opt-btn\" (click)=\"changeFormFieldFontSize(ff.id, 2)\" [disabled]=\"(ff.fontSize || 12) >= 72\" title=\"\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E02\u0E19\u0E32\u0E14\u0E2D\u0E31\u0E01\u0E29\u0E23\">\n                    <svg-icon name=\"add\"></svg-icon>\n                  </button>\n                  <div class=\"pff-opt-sep\"></div>\n                </ng-container>\n                <!-- Border toggle -->\n                <button class=\"pff-opt-btn\" [class.pff-opt-active]=\"ff.borderVisible !== false\"\n                  (click)=\"toggleFormFieldBorder(ff.id)\" title=\"\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A\">\n                  <svg-icon [name]=\"ff.borderVisible !== false ? 'square-outline' : 'square'\"></svg-icon>\n                </button>\n                <!-- Delete -->\n                <button class=\"pff-opt-btn pff-opt-delete\" (click)=\"removeFormField(ff.id)\" title=\"\u0E25\u0E1A\">\n                  <svg-icon name=\"trash-outline\"></svg-icon>\n                </button>\n              </div>\n\n              <div class=\"pff-inner\">\n                <span *ngIf=\"ff.type === 'text'\" class=\"pff-text-hint\">Aa {{ ff.fontSize || 12 }}pt</span>\n                <svg *ngIf=\"ff.type === 'checkbox'\" width=\"55%\" height=\"55%\" viewBox=\"0 0 18 18\" style=\"pointer-events:none\"><rect x=\"1\" y=\"1\" width=\"16\" height=\"16\" rx=\"2\" stroke=\"#3b82f6\" stroke-width=\"2\" fill=\"none\"/></svg>\n                <svg *ngIf=\"ff.type === 'radio'\" width=\"55%\" height=\"55%\" viewBox=\"0 0 18 18\" style=\"pointer-events:none\"><circle cx=\"9\" cy=\"9\" r=\"8\" stroke=\"#3b82f6\" stroke-width=\"2\" fill=\"none\"/></svg>\n              </div>\n\n              <div class=\"pff-resize-handle rh-nw\" (pointerdown)=\"startFormFieldResize($event, ff.id, 'nw')\"></div>\n              <div class=\"pff-resize-handle rh-n\"  (pointerdown)=\"startFormFieldResize($event, ff.id, 'n')\"></div>\n              <div class=\"pff-resize-handle rh-ne\" (pointerdown)=\"startFormFieldResize($event, ff.id, 'ne')\"></div>\n              <div class=\"pff-resize-handle rh-e\"  (pointerdown)=\"startFormFieldResize($event, ff.id, 'e')\"></div>\n              <div class=\"pff-resize-handle rh-se\" (pointerdown)=\"startFormFieldResize($event, ff.id, 'se')\"></div>\n              <div class=\"pff-resize-handle rh-s\"  (pointerdown)=\"startFormFieldResize($event, ff.id, 's')\"></div>\n              <div class=\"pff-resize-handle rh-sw\" (pointerdown)=\"startFormFieldResize($event, ff.id, 'sw')\"></div>\n              <div class=\"pff-resize-handle rh-w\"  (pointerdown)=\"startFormFieldResize($event, ff.id, 'w')\"></div>\n            </div>\n\n            <!-- Date Stamps for this page -->\n            <div *ngFor=\"let ds of getDateStampsForPage(p)\" class=\"date-stamp\" [style.left.%]=\"ds.x\"\n              [style.top.%]=\"ds.y\" [style.color]=\"ds.color\" [style.font-size.px]=\"ds.fontSize * zoom\"\n              [style.z-index]=\"ds.zIndex || 10\" (pointerdown)=\"startDateDrag($event, ds.id)\"\n              (contextmenu)=\"onContextMenu($event, ds.id, 'date')\">\n              <button class=\"remove-btn\" (click)=\"removeDateStamp(ds.id); $event.stopPropagation()\"><svg-icon name=\"close-outline\"></svg-icon></button>\n              {{ ds.text }}\n            </div>\n\n            <!-- Ghost stamp preview when placement mode active -->\n            <img *ngIf=\"pendingStamp && stampGhostPage === p\"\n              [src]=\"pendingStamp.dataUrl\"\n              class=\"stamp-ghost-img\"\n              [style.left.px]=\"stampGhostX - pendingStamp.defaultWidth / 2\"\n              [style.top.px]=\"stampGhostY - (pendingStamp.defaultWidth * 0.5) / 2\"\n              [style.width.px]=\"pendingStamp.defaultWidth\"\n              draggable=\"false\" />\n          </div>\n        </div>\n\n        <div class=\"hint\">\n          <div>\u2022 Keyboard: Ctrl+Z (Undo), Ctrl+Y (Redo), Escape (Exit mode), Delete (Remove selected)</div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- User Guide Panel (right slide-in drawer) -->\n  <div class=\"user-guide-drawer\" [class.open]=\"showUserGuidePanel\">\n    <div class=\"user-guide-drawer__backdrop\" (click)=\"showUserGuidePanel = false\"></div>\n    <div class=\"user-guide-drawer__panel\">\n      <div class=\"user-guide-drawer__header\">\n        <span><svg-icon name=\"book-outline\"></svg-icon> \u0E04\u0E39\u0E48\u0E21\u0E37\u0E2D\u0E01\u0E32\u0E23\u0E43\u0E0A\u0E49\u0E07\u0E32\u0E19</span>\n        <button (click)=\"showUserGuidePanel = false\"><svg-icon name=\"close-outline\"></svg-icon></button>\n      </div>\n\n      <div class=\"user-guide-content-area\" *ngIf=\"!isLoadingGuide\">\n        <div *ngIf=\"!isEditingGuide\" class=\"guide-view-mode\">\n\n          <!-- Banner -->\n          <div class=\"guide-banner\">\n            <svg-icon name=\"rocket\"></svg-icon>\n            <div>\n              <strong>\u0E40\u0E23\u0E34\u0E48\u0E21\u0E15\u0E49\u0E19\u0E07\u0E48\u0E32\u0E22\u0E21\u0E32\u0E01!</strong> \u0E40\u0E25\u0E37\u0E2D\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D\u0E08\u0E32\u0E01\u0E41\u0E16\u0E1A\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19 \u0E41\u0E25\u0E49\u0E27\u0E04\u0E25\u0E34\u0E01\u0E2B\u0E23\u0E37\u0E2D\u0E25\u0E32\u0E01\u0E1A\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22\n              \u2014 \u0E01\u0E14 <code>Ctrl+Z</code> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A\u0E40\u0E2A\u0E21\u0E2D\u0E2B\u0E32\u0E01\u0E17\u0E33\u0E1E\u0E25\u0E32\u0E14\n            </div>\n          </div>\n\n          <!-- \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"text\" style=\"color:#60a5fa;\"></svg-icon> \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21 (Text)\n            </h4>\n            <div class=\"guide-list\">\n              <div class=\"guide-item\">\n                <div class=\"guide-step\">1</div>\n                <div class=\"guide-item__text\">\u0E01\u0E14\u0E44\u0E2D\u0E04\u0E2D\u0E19 <svg-icon name=\"text\" style=\"vertical-align:-2px;color:#60a5fa;\"></svg-icon> \u0E41\u0E25\u0E49\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01 <strong>\u0E02\u0E19\u0E32\u0E14\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23</strong> \u0E41\u0E25\u0E30 <strong>\u0E2A\u0E35</strong> \u0E17\u0E35\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23\u0E01\u0E48\u0E2D\u0E19\u0E27\u0E32\u0E07</div>\n              </div>\n              <div class=\"guide-item\">\n                <div class=\"guide-step\">2</div>\n                <div class=\"guide-item__text\">\u0E04\u0E25\u0E34\u0E01\u0E1A\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 PDF \u2014 \u0E01\u0E25\u0E48\u0E2D\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E08\u0E30\u0E1B\u0E23\u0E32\u0E01\u0E0F\u0E17\u0E31\u0E19\u0E17\u0E35 \u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E44\u0E14\u0E49\u0E40\u0E25\u0E22 <strong>\u0E01\u0E25\u0E48\u0E2D\u0E07\u0E08\u0E30\u0E02\u0E22\u0E32\u0E22\u0E15\u0E32\u0E21\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34</strong></div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"move-outline\" class=\"guide-item__icon\" style=\"color:#60a5fa;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E22\u0E49\u0E32\u0E22\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07:</strong> \u0E08\u0E31\u0E1A\u0E17\u0E35\u0E48 <em>\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A</em> \u0E01\u0E25\u0E48\u0E2D\u0E07\u0E41\u0E25\u0E49\u0E27\u0E25\u0E32\u0E01\u0E44\u0E1B\u0E27\u0E32\u0E07\u0E44\u0E14\u0E49\u0E17\u0E38\u0E01\u0E17\u0E35\u0E48 (cursor \u0E08\u0E30\u0E40\u0E1B\u0E25\u0E35\u0E48\u0E22\u0E19\u0E40\u0E1B\u0E47\u0E19\u0E25\u0E39\u0E01\u0E28\u0E23 4 \u0E17\u0E34\u0E28)</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"contract-outline\" class=\"guide-item__icon\" style=\"color:#60a5fa;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E1B\u0E23\u0E31\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E01\u0E27\u0E49\u0E32\u0E07:</strong> \u0E25\u0E32\u0E01\u0E27\u0E07\u0E01\u0E25\u0E21\u0E2A\u0E35\u0E1F\u0E49\u0E32 <span class=\"guide-dot-demo\"></span> \u0E17\u0E35\u0E48\u0E0B\u0E49\u0E32\u0E22\u0E2B\u0E23\u0E37\u0E2D\u0E02\u0E27\u0E32\u0E01\u0E25\u0E48\u0E2D\u0E07 \u2014 \u0E04\u0E27\u0E32\u0E21\u0E2A\u0E39\u0E07\u0E08\u0E30\u0E1B\u0E23\u0E31\u0E1A\u0E15\u0E32\u0E21\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E40\u0E2D\u0E07</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"trash-outline\" class=\"guide-item__icon\" style=\"color:#f87171;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E25\u0E1A\u0E01\u0E25\u0E48\u0E2D\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21:</strong> \u0E04\u0E25\u0E34\u0E01\u0E17\u0E35\u0E48\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A\u0E01\u0E25\u0E48\u0E2D\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E25\u0E37\u0E2D\u0E01 \u0E41\u0E25\u0E49\u0E27\u0E01\u0E14 <code>Delete</code> \u0E2B\u0E23\u0E37\u0E2D\u0E04\u0E25\u0E34\u0E01\u0E02\u0E27\u0E32\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E14\u0E39\u0E40\u0E21\u0E19\u0E39</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- \u0E27\u0E32\u0E14\u0E41\u0E25\u0E30\u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"brush\" style=\"color:#fb7185;\"></svg-icon> \u0E27\u0E32\u0E14 / \u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C / \u0E22\u0E32\u0E07\u0E25\u0E1A\n            </h4>\n            <div class=\"guide-list\">\n              <div class=\"guide-item\">\n                <svg-icon name=\"brush\" class=\"guide-item__icon\" style=\"color:#fb7185;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E1B\u0E32\u0E01\u0E01\u0E32 / \u0E14\u0E34\u0E19\u0E2A\u0E2D:</strong> \u0E25\u0E32\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E27\u0E32\u0E14\u0E2D\u0E34\u0E2A\u0E23\u0E30 \u2014 \u0E1B\u0E23\u0E31\u0E1A <strong>\u0E02\u0E19\u0E32\u0E14\u0E40\u0E2A\u0E49\u0E19</strong> \u0E41\u0E25\u0E30 <strong>\u0E2A\u0E35</strong> \u0E08\u0E32\u0E01\u0E41\u0E16\u0E1A\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19 \u0E40\u0E2A\u0E49\u0E19\u0E08\u0E30\u0E23\u0E27\u0E21\u0E40\u0E1B\u0E47\u0E19 object \u0E40\u0E14\u0E35\u0E22\u0E27\u0E40\u0E21\u0E37\u0E48\u0E2D\u0E22\u0E01\u0E1B\u0E32\u0E01\u0E01\u0E32</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"color-filter-outline\" class=\"guide-item__icon\" style=\"color:#fde68a;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C:</strong> \u0E25\u0E32\u0E01\u0E17\u0E31\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E19\u0E49\u0E19\u0E2A\u0E35 \u2014 \u0E21\u0E35\u0E2A\u0E35\u0E43\u0E2B\u0E49\u0E40\u0E25\u0E37\u0E2D\u0E01 6 \u0E2A\u0E35 \u0E2B\u0E23\u0E37\u0E2D\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E2A\u0E35\u0E40\u0E2D\u0E07\u0E44\u0E14\u0E49 \u0E1B\u0E23\u0E31\u0E1A\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E19\u0E32\u0E44\u0E14\u0E49\u0E15\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"cut-outline\" class=\"guide-item__icon\" style=\"color:#94a3b8;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E22\u0E32\u0E07\u0E25\u0E1A:</strong> \u0E25\u0E32\u0E01\u0E1C\u0E48\u0E32\u0E19\u0E40\u0E2A\u0E49\u0E19\u0E27\u0E32\u0E14\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E25\u0E1A \u2014 \u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14\u0E22\u0E32\u0E07\u0E25\u0E1A\u0E44\u0E14\u0E49\u0E08\u0E32\u0E01\u0E41\u0E16\u0E1A\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- \u0E23\u0E39\u0E1B\u0E23\u0E48\u0E32\u0E07 -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"shapes\" style=\"color:#a78bfa;\"></svg-icon> \u0E23\u0E39\u0E1B\u0E23\u0E48\u0E32\u0E07\u0E41\u0E25\u0E30\u0E40\u0E2A\u0E49\u0E19 (Shapes)\n            </h4>\n            <div class=\"guide-list\">\n              <div class=\"guide-item\">\n                <svg-icon name=\"square-outline\" class=\"guide-item__icon\" style=\"color:#a78bfa;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>4 \u0E41\u0E1A\u0E1A:</strong> \u0E2A\u0E35\u0E48\u0E40\u0E2B\u0E25\u0E35\u0E48\u0E22\u0E21 <svg-icon name=\"square-outline\" style=\"vertical-align:-2px;font-size:13px;\"></svg-icon> \u0E27\u0E07\u0E01\u0E25\u0E21 <svg-icon name=\"ellipse-outline\" style=\"vertical-align:-2px;font-size:13px;\"></svg-icon> \u0E40\u0E2A\u0E49\u0E19\u0E15\u0E23\u0E07 <svg-icon name=\"remove-outline\" style=\"vertical-align:-2px;font-size:13px;\"></svg-icon> \u0E25\u0E39\u0E01\u0E28\u0E23 <svg-icon name=\"arrow-forward-outline\" style=\"vertical-align:-2px;font-size:13px;\"></svg-icon> \u2014 \u0E01\u0E14\u0E25\u0E39\u0E01\u0E28\u0E23\u0E40\u0E25\u0E47\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E41\u0E1A\u0E1A \u0E41\u0E25\u0E49\u0E27<strong>\u0E25\u0E32\u0E01\u0E1A\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23</strong></div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"color-palette\" class=\"guide-item__icon\" style=\"color:#fbbf24;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E1B\u0E23\u0E31\u0E1A\u0E2A\u0E35\u0E41\u0E25\u0E30\u0E02\u0E19\u0E32\u0E14\u0E40\u0E2A\u0E49\u0E19:</strong> \u0E15\u0E31\u0E49\u0E07\u0E04\u0E48\u0E32\u0E2A\u0E35\u0E02\u0E2D\u0E1A, \u0E2A\u0E35\u0E1E\u0E37\u0E49\u0E19, \u0E41\u0E25\u0E30\u0E04\u0E27\u0E32\u0E21\u0E2B\u0E19\u0E32\u0E40\u0E2A\u0E49\u0E19\u0E44\u0E14\u0E49\u0E08\u0E32\u0E01\u0E41\u0E16\u0E1A\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19 \u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E01\u0E32\u0E23\u0E1B\u0E34\u0E14\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A\u0E2B\u0E23\u0E37\u0E2D\u0E1B\u0E34\u0E14\u0E2A\u0E35\u0E1E\u0E37\u0E49\u0E19\u0E41\u0E22\u0E01\u0E01\u0E31\u0E19\u0E44\u0E14\u0E49</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"resize\" class=\"guide-item__icon\" style=\"color:#a78bfa;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E22\u0E49\u0E32\u0E22\u0E41\u0E25\u0E30\u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14:</strong> \u0E25\u0E32\u0E01\u0E15\u0E23\u0E07\u0E01\u0E25\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E22\u0E49\u0E32\u0E22 \u2014 \u0E25\u0E32\u0E01 handle 8 \u0E08\u0E38\u0E14\u0E23\u0E2D\u0E1A\u0E23\u0E39\u0E1B\u0E23\u0E48\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14 \u2014 \u0E04\u0E25\u0E34\u0E01\u0E02\u0E27\u0E32\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E08\u0E31\u0E14\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E0A\u0E31\u0E49\u0E19</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- \u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19 -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"finger-print\" style=\"color:#34d399;\"></svg-icon> \u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19 (Signature)\n            </h4>\n            <div class=\"guide-list\">\n              <div class=\"guide-item\">\n                <svg-icon name=\"create-outline\" class=\"guide-item__icon\" style=\"color:#34d399;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E27\u0E32\u0E14\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19:</strong> \u0E01\u0E14 <svg-icon name=\"finger-print\" style=\"vertical-align:-2px;font-size:13px;color:#34d399;\"></svg-icon> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E1B\u0E34\u0E14\u0E2B\u0E19\u0E49\u0E32\u0E15\u0E48\u0E32\u0E07\u0E27\u0E32\u0E14 \u2014 \u0E1B\u0E23\u0E31\u0E1A\u0E2A\u0E35\u0E41\u0E25\u0E30\u0E02\u0E19\u0E32\u0E14\u0E1B\u0E32\u0E01\u0E01\u0E32 \u2014 \u0E01\u0E14 <strong>\"\u0E43\u0E0A\u0E49\u0E04\u0E23\u0E31\u0E49\u0E07\u0E19\u0E35\u0E49\"</strong> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E27\u0E32\u0E07\u0E1A\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"cloud-upload-outline\" class=\"guide-item__icon\" style=\"color:#34d399;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19:</strong> \u0E01\u0E14 <strong>\"\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49\u0E43\u0E0A\u0E49\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07\"</strong> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E01\u0E47\u0E1A\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E44\u0E27\u0E49\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A \u2014 \u0E04\u0E23\u0E31\u0E49\u0E07\u0E16\u0E31\u0E14\u0E44\u0E1B\u0E01\u0E14\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23\u0E44\u0E14\u0E49\u0E17\u0E31\u0E19\u0E17\u0E35</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"shield-checkmark-outline\" class=\"guide-item__icon\" style=\"color:#34d399;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>Digital ID (DID):</strong> \u0E01\u0E14\u0E1B\u0E38\u0E48\u0E21 <code>DID</code> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E41\u0E2A\u0E14\u0E07/\u0E0B\u0E48\u0E2D\u0E19\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25 Digital ID \u0E43\u0E15\u0E49\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19 (\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48, \u0E40\u0E27\u0E25\u0E32, \u0E23\u0E2B\u0E31\u0E2A\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49)</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- \u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 \u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"calendar\" style=\"color:#fb923c;\"></svg-icon> \u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 \u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E\n            </h4>\n            <div class=\"guide-list\">\n              <div class=\"guide-item\">\n                <svg-icon name=\"calendar-outline\" class=\"guide-item__icon\" style=\"color:#fb923c;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E2D\u0E31\u0E15\u0E42\u0E19\u0E21\u0E31\u0E15\u0E34:</strong> \u0E01\u0E14 <svg-icon name=\"calendar\" style=\"vertical-align:-2px;font-size:13px;color:#fb923c;\"></svg-icon> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E41\u0E17\u0E23\u0E01\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19 \u2014 \u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14\u0E41\u0E25\u0E30\u0E2A\u0E35\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23\u0E44\u0E14\u0E49 \u2014 \u0E25\u0E32\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E22\u0E49\u0E32\u0E22\u0E15\u0E33\u0E41\u0E2B\u0E19\u0E48\u0E07</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"image-outline\" class=\"guide-item__icon\" style=\"color:#fb923c;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E41\u0E17\u0E23\u0E01\u0E23\u0E39\u0E1B\u0E20\u0E32\u0E1E:</strong> \u0E01\u0E14 <svg-icon name=\"image\" style=\"vertical-align:-2px;font-size:13px;color:#fb923c;\"></svg-icon> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E1F\u0E25\u0E4C\u0E23\u0E39\u0E1B\u0E08\u0E32\u0E01\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07 \u2014 \u0E25\u0E32\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E22\u0E49\u0E32\u0E22 \u0E25\u0E32\u0E01 handle 8 \u0E08\u0E38\u0E14\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E1B\u0E23\u0E31\u0E1A\u0E02\u0E19\u0E32\u0E14</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- \u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2B\u0E19\u0E49\u0E32 -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"documents\" style=\"color:#f59e0b;\"></svg-icon> \u0E08\u0E31\u0E14\u0E01\u0E32\u0E23\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\n            </h4>\n            <div class=\"guide-list\">\n              <div class=\"guide-item\">\n                <svg-icon name=\"images-outline\" class=\"guide-item__icon\" style=\"color:#f59e0b;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>Thumbnail \u0E14\u0E49\u0E32\u0E19\u0E0B\u0E49\u0E32\u0E22:</strong> \u0E01\u0E14 <svg-icon name=\"images-outline\" style=\"vertical-align:-2px;font-size:13px;\"></svg-icon> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E41\u0E2A\u0E14\u0E07 \u2014 \u0E04\u0E25\u0E34\u0E01 thumbnail \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E01\u0E23\u0E30\u0E42\u0E14\u0E14\u0E44\u0E1B\u0E2B\u0E19\u0E49\u0E32\u0E19\u0E31\u0E49\u0E19 \u2014 \u0E25\u0E32\u0E01 <svg-icon name=\"chevron-up-outline\" style=\"vertical-align:-2px;font-size:12px;\"></svg-icon><svg-icon name=\"chevron-down-outline\" style=\"vertical-align:-2px;font-size:12px;\"></svg-icon> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E23\u0E35\u0E22\u0E07\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E2B\u0E19\u0E49\u0E32</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"add-circle-outline\" class=\"guide-item__icon\" style=\"color:#f59e0b;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E41\u0E17\u0E23\u0E01/\u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32:</strong> \u0E01\u0E14\u0E44\u0E2D\u0E04\u0E2D\u0E19 <svg-icon name=\"documents-outline\" style=\"vertical-align:-2px;font-size:13px;\"></svg-icon> \u0E1A\u0E19\u0E41\u0E16\u0E1A\u0E14\u0E49\u0E32\u0E19\u0E1A\u0E19 \u2014 \u0E41\u0E17\u0E23\u0E01\u0E2B\u0E19\u0E49\u0E32\u0E40\u0E1B\u0E25\u0E48\u0E32\u0E41\u0E19\u0E27\u0E15\u0E31\u0E49\u0E07/\u0E41\u0E19\u0E27\u0E19\u0E2D\u0E19 \u0E01\u0E48\u0E2D\u0E19\u0E2B\u0E23\u0E37\u0E2D\u0E2B\u0E25\u0E31\u0E07\u0E2B\u0E19\u0E49\u0E32\u0E1B\u0E31\u0E08\u0E08\u0E38\u0E1A\u0E31\u0E19 \u2014 \u0E25\u0E1A\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E15\u0E49\u0E2D\u0E07\u0E01\u0E32\u0E23 \u2014 \u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A\u0E44\u0E14\u0E49</div>\n              </div>\n              <div class=\"guide-item\">\n                <svg-icon name=\"search-outline\" class=\"guide-item__icon\" style=\"color:#f59e0b;\"></svg-icon>\n                <div class=\"guide-item__text\"><strong>\u0E0B\u0E39\u0E21:</strong> \u0E01\u0E14\u0E1B\u0E38\u0E48\u0E21 <code>+</code> / <code>\u2212</code> \u0E2B\u0E23\u0E37\u0E2D\u0E43\u0E0A\u0E49\u0E1B\u0E38\u0E48\u0E21\u0E0B\u0E39\u0E21\u0E1A\u0E19\u0E41\u0E16\u0E1A\u0E19\u0E33\u0E17\u0E32\u0E07 \u2014 \u0E23\u0E2D\u0E07\u0E23\u0E31\u0E1A\u0E15\u0E31\u0E49\u0E07\u0E41\u0E15\u0E48 50% \u0E16\u0E36\u0E07 300%</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- Keyboard Shortcuts -->\n          <div class=\"guide-section\">\n            <h4 class=\"guide-section__title\">\n              <svg-icon name=\"keypad\" style=\"color:#e2e8f0;\"></svg-icon> \u0E04\u0E35\u0E22\u0E4C\u0E25\u0E31\u0E14\u0E17\u0E35\u0E48\u0E04\u0E27\u0E23\u0E23\u0E39\u0E49\n            </h4>\n            <div class=\"guide-shortcuts-grid\">\n              <div class=\"guide-shortcut-card\">\n                <div class=\"guide-shortcut-card__keys\"><kbd>Ctrl</kbd><span>+</span><kbd>Z</kbd></div>\n                <div class=\"guide-shortcut-card__label\">\u0E22\u0E49\u0E2D\u0E19\u0E01\u0E25\u0E31\u0E1A (Undo)</div>\n              </div>\n              <div class=\"guide-shortcut-card\">\n                <div class=\"guide-shortcut-card__keys\"><kbd>Ctrl</kbd><span>+</span><kbd>Y</kbd></div>\n                <div class=\"guide-shortcut-card__label\">\u0E17\u0E33\u0E0B\u0E49\u0E33 (Redo)</div>\n              </div>\n              <div class=\"guide-shortcut-card\">\n                <div class=\"guide-shortcut-card__keys\"><kbd>Delete</kbd></div>\n                <div class=\"guide-shortcut-card__label\">\u0E25\u0E1A object \u0E17\u0E35\u0E48\u0E40\u0E25\u0E37\u0E2D\u0E01</div>\n              </div>\n              <div class=\"guide-shortcut-card\">\n                <div class=\"guide-shortcut-card__keys\"><kbd>Esc</kbd></div>\n                <div class=\"guide-shortcut-card__label\">\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E42\u0E2B\u0E21\u0E14\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D</div>\n              </div>\n            </div>\n          </div>\n\n          <!-- Pro Tips -->\n          <div class=\"guide-protip\">\n            <div class=\"guide-protip__icon\"><svg-icon name=\"bulb\"></svg-icon></div>\n            <div class=\"guide-protip__body\">\n              <div class=\"guide-protip__title\">Pro Tips</div>\n              <ul class=\"guide-protip__list\">\n                <li>\u0E04\u0E25\u0E34\u0E01\u0E02\u0E27\u0E32\u0E1A\u0E19 object \u0E43\u0E14 \u0E46 \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E08\u0E31\u0E14\u0E25\u0E33\u0E14\u0E31\u0E1A\u0E0A\u0E31\u0E49\u0E19 (Bring to Front / Send to Back)</li>\n                <li>\u0E01\u0E14 <code>Esc</code> \u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E2D\u0E2D\u0E01\u0E08\u0E32\u0E01\u0E42\u0E2B\u0E21\u0E14\u0E40\u0E04\u0E23\u0E37\u0E48\u0E2D\u0E07\u0E21\u0E37\u0E2D\u0E41\u0E25\u0E30\u0E01\u0E25\u0E31\u0E1A\u0E2A\u0E39\u0E48\u0E42\u0E2B\u0E21\u0E14\u0E1B\u0E01\u0E15\u0E34</li>\n                <li>\u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C\u0E17\u0E35\u0E48\u0E27\u0E32\u0E14\u0E14\u0E49\u0E27\u0E22 opacity \u0E15\u0E48\u0E33 \u2014 \u0E43\u0E0A\u0E49\u0E44\u0E2E\u0E44\u0E25\u0E17\u0E4C\u0E0B\u0E49\u0E2D\u0E19\u0E01\u0E31\u0E19\u0E2B\u0E25\u0E32\u0E22\u0E0A\u0E31\u0E49\u0E19\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E19\u0E49\u0E19\u0E2A\u0E35\u0E40\u0E02\u0E49\u0E21\u0E02\u0E36\u0E49\u0E19</li>\n                <li>\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E44\u0E27\u0E49\u0E43\u0E19\u0E23\u0E30\u0E1A\u0E1A\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E43\u0E0A\u0E49\u0E0B\u0E49\u0E33\u0E43\u0E19\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E2D\u0E37\u0E48\u0E19 \u0E46 \u0E44\u0E14\u0E49\u0E2A\u0E30\u0E14\u0E27\u0E01</li>\n              </ul>\n            </div>\n          </div>\n\n          <div class=\"guide-section\" *ngIf=\"userGuideContent && userGuideContent.trim() !== ''\">\n            <h4 class=\"guide-section__title\"><svg-icon name=\"megaphone\" style=\"color:#10b981;\"></svg-icon> \u0E1B\u0E23\u0E30\u0E01\u0E32\u0E28\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21</h4>\n            <div class=\"guide-raw-content\">{{ userGuideContent }}</div>\n          </div>\n\n          <button *ngIf=\"canManageGuide\" (click)=\"editGuide()\" class=\"guide-edit-btn\">\n            <svg-icon name=\"create-outline\"></svg-icon> \u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15\u0E1B\u0E23\u0E30\u0E01\u0E32\u0E28\u0E40\u0E1E\u0E34\u0E48\u0E21\u0E40\u0E15\u0E34\u0E21\n          </button>\n        </div>\n\n        <div *ngIf=\"isEditingGuide\" style=\"display: flex; flex-direction: column; height: 100%;\">\n          <div style=\"font-size: 12px; color: #94a3b8; margin-bottom: 8px;\">\u0E04\u0E38\u0E13\u0E2A\u0E32\u0E21\u0E32\u0E23\u0E16\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E43\u0E19\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E18\u0E23\u0E23\u0E21\u0E14\u0E32 \u0E2B\u0E23\u0E37\u0E2D Markdown (\u0E16\u0E49\u0E32\u0E21\u0E35\u0E01\u0E32\u0E23\u0E40\u0E0A\u0E37\u0E48\u0E2D\u0E21\u0E15\u0E48\u0E2D\u0E15\u0E31\u0E27\u0E41\u0E1B\u0E25\u0E07)</div>\n          <textarea [(ngModel)]=\"tempGuideContent\" style=\"flex: 1; min-height: 300px; width: 100%; padding: 12px; background: rgba(0,0,0,0.2); border: 1px solid #334155; border-radius: 6px; color: #e8eaf6; font-size: 13.5px; resize: none; line-height: 1.5; outline: none; font-family: sans-serif;\" placeholder=\"\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E04\u0E39\u0E48\u0E21\u0E37\u0E2D\u0E17\u0E35\u0E48\u0E19\u0E35\u0E48...\"></textarea>\n          \n          <div style=\"display: flex; gap: 8px; margin-top: 16px; padding-bottom: 20px;\">\n            <button (click)=\"cancelEditGuide()\" style=\"flex: 1; padding: 10px; background: transparent; border: 1px solid #475569; color: #94a3b8; border-radius: 6px; cursor: pointer; font-weight: 500;\">\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01</button>\n            <button (click)=\"saveGuide()\" style=\"flex: 1; padding: 10px; background: #3b82f6; border: none; color: #fff; border-radius: 6px; cursor: pointer; font-weight: 600; transition: background 0.2s;\">\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E2D\u0E31\u0E1B\u0E40\u0E14\u0E15</button>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- History Panel (right slide-in drawer) -->\n  <div class=\"annot-history-drawer\" [class.open]=\"showHistoryPanel\">\n    <div class=\"annot-history-drawer__backdrop\" (click)=\"showHistoryPanel = false\"></div>\n    <div class=\"annot-history-drawer__panel\">\n      <div class=\"annot-history-drawer__header\">\n        <span><svg-icon name=\"time-outline\"></svg-icon> \u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02</span>\n        <button (click)=\"showHistoryPanel = false\"><svg-icon name=\"close-outline\"></svg-icon></button>\n      </div>\n\n      <div class=\"annot-history-loading\" *ngIf=\"isLoadingHistory\">\n        <ion-spinner name=\"dots\"></ion-spinner>\n      </div>\n\n      <div class=\"annot-history-list\" *ngIf=\"!isLoadingHistory\">\n        <div class=\"annot-history-entry\" *ngFor=\"let h of historyEntries\">\n          <div class=\"annot-history-entry__icon\" [class]=\"'hi-' + h.action_type\">\n            <svg-icon [name]=\"getHistoryActionIcon(h.action_type)\"></svg-icon>\n          </div>\n          <div class=\"annot-history-entry__body\">\n            <div class=\"annot-history-entry__title\">\n              {{ getHistoryActionLabel(h.action_type) }}\n              <span class=\"annot-history-entry__page\" *ngIf=\"h.page_number > 0\">\u0E2B\u0E19\u0E49\u0E32 {{ h.page_number }}</span>\n            </div>\n            <div class=\"annot-history-entry__user\">{{ h.user_name || h.user_id || '\u0E1C\u0E39\u0E49\u0E43\u0E0A\u0E49' }}</div>\n            <div class=\"annot-history-entry__time\">{{ h.created_at | date:'dd/MM/yyyy HH:mm' }}</div>\n          </div>\n        </div>\n        <div class=\"annot-history-empty\" *ngIf=\"historyEntries.length === 0\">\n          <svg-icon name=\"time-outline\"></svg-icon>\n          <p>\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E1B\u0E23\u0E30\u0E27\u0E31\u0E15\u0E34</p>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- Hidden file input for signature upload (always in DOM) -->\n  <input type=\"file\" #signatureFileInput accept=\"image/*\" style=\"display:none\"\n    (change)=\"onSignatureFileSelected($event)\">\n\n  <!-- Stamp Picker Modal -->\n  <div class=\"signature-picker-modal\" *ngIf=\"showStampPickerModal\">\n    <div class=\"signature-picker-modal__backdrop\" (click)=\"closeStampPicker()\"></div>\n    <div class=\"signature-picker-modal__content\">\n\n      <!-- Stamp List -->\n      <div *ngIf=\"!showStampGenerator\">\n        <h3>\u0E15\u0E23\u0E32\u0E22\u0E32\u0E07/\u0E15\u0E23\u0E32\u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A</h3>\n        <p class=\"signature-picker-modal__hint\">\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E15\u0E23\u0E32\u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48</p>\n\n        <div class=\"signature-picker-modal__loading\" *ngIf=\"isLoadingSignatures\">\n          <ion-spinner name=\"crescent\"></ion-spinner><span>\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14...</span>\n        </div>\n\n        <div class=\"signature-picker-modal__list\" *ngIf=\"!isLoadingSignatures && savedStamps.length > 0\">\n          <div class=\"signature-item\" *ngFor=\"let stamp of savedStamps\" (click)=\"$event.stopPropagation()\">\n            <img [src]=\"stamp.dataUrl\" (click)=\"useSavedStamp(stamp)\" style=\"cursor:pointer; max-height:50px; width:auto; object-fit:contain;\">\n            <div class=\"signature-item__info\">\n              <div class=\"stamp-name-row\" *ngIf=\"stampEditingId !== stamp.id\" (click)=\"startStampRename(stamp, $event)\">\n                <span class=\"signature-item__name\">{{ stamp.name }}</span>\n                <svg-icon name=\"pencil-outline\" class=\"stamp-edit-icon\"></svg-icon>\n              </div>\n              <input class=\"stamp-name-input\" *ngIf=\"stampEditingId === stamp.id\"\n                type=\"text\" [(ngModel)]=\"stampEditingName\"\n                (keyup.enter)=\"saveStampRename(stamp)\"\n                (blur)=\"saveStampRename(stamp)\"\n                (click)=\"$event.stopPropagation()\" />\n              <span class=\"signature-item__badge\">{{ stamp.type === 'receive' ? '\u0E23\u0E31\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23' : '\u0E17\u0E31\u0E48\u0E27\u0E44\u0E1B' }}</span>\n            </div>\n            <div class=\"signature-item__actions\">\n              <button class=\"signature-item__btn\" (click)=\"useSavedStamp(stamp)\" title=\"\u0E43\u0E0A\u0E49\u0E15\u0E23\u0E32\u0E19\u0E35\u0E49\">\n                <svg-icon name=\"checkmark\"></svg-icon>\n              </button>\n              <button class=\"signature-item__btn signature-item__btn--delete\" (click)=\"deleteSavedStamp(stamp, $event)\" title=\"\u0E25\u0E1A\">\n                <svg-icon name=\"trash\"></svg-icon>\n              </button>\n            </div>\n          </div>\n        </div>\n\n        <div class=\"signature-picker-modal__empty\" *ngIf=\"!isLoadingSignatures && savedStamps.length === 0\">\n          <svg-icon name=\"business-outline\"></svg-icon>\n          <p>\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E15\u0E23\u0E32\u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49 \u0E01\u0E14 \"\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E15\u0E23\u0E32\u0E22\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48\" \u0E14\u0E49\u0E32\u0E19\u0E25\u0E48\u0E32\u0E07</p>\n        </div>\n\n        <div class=\"signature-picker-modal__actions\">\n          <ion-button fill=\"outline\" color=\"medium\" (click)=\"closeStampPicker()\">\u0E22\u0E01\u0E40\u0E25\u0E34\u0E01</ion-button>\n          <ion-button fill=\"outline\" color=\"secondary\" (click)=\"triggerStampUpload()\">\n            <svg-icon name=\"cloud-upload-outline\" slot=\"start\"></svg-icon>\u0E2D\u0E31\u0E1B\u0E42\u0E2B\u0E25\u0E14\u0E44\u0E1F\u0E25\u0E4C\n          </ion-button>\n          <ion-button color=\"primary\" (click)=\"openStampGenerator()\">\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E15\u0E23\u0E32\u0E22\u0E32\u0E07\u0E43\u0E2B\u0E21\u0E48</ion-button>\n        </div>\n      </div>\n\n      <!-- Stamp Generator UI -->\n      <div *ngIf=\"showStampGenerator\" style=\"text-align: left;\">\n        <h3 style=\"text-align: center;\">\u0E2A\u0E23\u0E49\u0E32\u0E07\u0E15\u0E23\u0E32\u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A\u0E43\u0E2B\u0E21\u0E48</h3>\n        <p class=\"signature-picker-modal__hint\" style=\"text-align: center;\">\u0E1B\u0E23\u0E31\u0E1A\u0E41\u0E15\u0E48\u0E07\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E25\u0E30\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A</p>\n\n        <div style=\"margin-bottom: 16px;\">\n          <ion-item lines=\"none\" class=\"input-item\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n            <svg-icon name=\"options-outline\" slot=\"start\" style=\"color:#92949c\"></svg-icon>\n            <ion-select [(ngModel)]=\"stampGenType\" interface=\"popover\" placeholder=\"\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\">\n              <ion-select-option value=\"receive\">\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17: \u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A\u0E23\u0E31\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23 (\u0E21\u0E35 \u0E40\u0E25\u0E02\u0E23\u0E31\u0E1A/\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48/\u0E40\u0E27\u0E25\u0E32)</ion-select-option>\n              <ion-select-option value=\"custom\">\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17: \u0E15\u0E23\u0E32\u0E1B\u0E23\u0E30\u0E17\u0E31\u0E1A\u0E17\u0E31\u0E48\u0E27\u0E44\u0E1B (\u0E44\u0E21\u0E48\u0E21\u0E35\u0E0A\u0E48\u0E2D\u0E07\u0E01\u0E23\u0E2D\u0E01)</ion-select-option>\n            </ion-select>\n          </ion-item>\n\n          <ion-item lines=\"none\" class=\"input-item\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n            <ion-label position=\"floating\" style=\"font-size:14px;\">\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E17\u0E35\u0E48 1 (\u0E15\u0E31\u0E27\u0E2B\u0E19\u0E32\u0E1A\u0E19\u0E2A\u0E38\u0E14)</ion-label>\n            <ion-input type=\"text\" [(ngModel)]=\"stampGenText1\"></ion-input>\n          </ion-item>\n\n          <ion-item lines=\"none\" class=\"input-item\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n            <ion-label position=\"floating\" style=\"font-size:14px;\">\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E17\u0E35\u0E48 2 (\u0E23\u0E2D\u0E07\u0E25\u0E07\u0E21\u0E32)</ion-label>\n            <ion-input type=\"text\" [(ngModel)]=\"stampGenText2\"></ion-input>\n          </ion-item>\n\n          <ion-item lines=\"none\" class=\"input-item\" *ngIf=\"stampGenType !== 'receive'\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n            <ion-label position=\"floating\" style=\"font-size:14px;\">\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E17\u0E35\u0E48 3 (\u0E16\u0E49\u0E32\u0E21\u0E35)</ion-label>\n            <ion-input type=\"text\" [(ngModel)]=\"stampGenText3\"></ion-input>\n          </ion-item>\n\n          <ng-container *ngIf=\"stampGenType === 'receive'\">\n            <div class=\"stamp-row-hint\" style=\"font-size:12px; color:#64748b; margin:6px 2px 2px;\">\n              <svg-icon name=\"information-circle-outline\" style=\"vertical-align:-2px;\"></svg-icon>\n              \u0E15\u0E34\u0E4A\u0E01\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E27\u0E48\u0E32\u0E08\u0E30\u0E41\u0E2A\u0E14\u0E07\u0E1A\u0E23\u0E23\u0E17\u0E31\u0E14\u0E19\u0E31\u0E49\u0E19\u0E1A\u0E19\u0E15\u0E23\u0E32\u0E2B\u0E23\u0E37\u0E2D\u0E44\u0E21\u0E48\n            </div>\n            <ion-item lines=\"none\" class=\"input-item\" [class.input-item--off]=\"!stampGenShowDocNo\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n              <ion-checkbox slot=\"start\" [(ngModel)]=\"stampGenShowDocNo\" style=\"margin-right: 10px;\" title=\"\u0E41\u0E2A\u0E14\u0E07\u0E40\u0E25\u0E02\u0E23\u0E31\u0E1A\"></ion-checkbox>\n              <ion-label position=\"floating\" style=\"font-size:14px; color:#3b82f6;\">\u0E40\u0E25\u0E02\u0E23\u0E31\u0E1A\u0E17\u0E35\u0E48 (\u0E1B\u0E25\u0E48\u0E2D\u0E22\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E15\u0E34\u0E21\u0E17\u0E35\u0E2B\u0E25\u0E31\u0E07)</ion-label>\n              <ion-input type=\"text\" [(ngModel)]=\"stampGenDocNo\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 1234/2569\" [disabled]=\"!stampGenShowDocNo\"></ion-input>\n            </ion-item>\n            <ion-item lines=\"none\" class=\"input-item\" [class.input-item--off]=\"!stampGenShowDate\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n              <ion-checkbox slot=\"start\" [(ngModel)]=\"stampGenShowDate\" style=\"margin-right: 10px;\" title=\"\u0E41\u0E2A\u0E14\u0E07\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\"></ion-checkbox>\n              <ion-label position=\"floating\" style=\"font-size:14px; color:#3b82f6;\">\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48 (\u0E1B\u0E25\u0E48\u0E2D\u0E22\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E15\u0E34\u0E21\u0E17\u0E35\u0E2B\u0E25\u0E31\u0E07)</ion-label>\n              <ion-input type=\"text\" [(ngModel)]=\"stampGenDate\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 6 \u0E1E.\u0E04. 2569\" [disabled]=\"!stampGenShowDate\"></ion-input>\n            </ion-item>\n            <ion-item lines=\"none\" class=\"input-item\" [class.input-item--off]=\"!stampGenShowTime\" style=\"--background: #f8fafc; --color: #0f172a; color: #0f172a; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 2px;\">\n              <ion-checkbox slot=\"start\" [(ngModel)]=\"stampGenShowTime\" style=\"margin-right: 10px;\" title=\"\u0E41\u0E2A\u0E14\u0E07\u0E40\u0E27\u0E25\u0E32\"></ion-checkbox>\n              <ion-label position=\"floating\" style=\"font-size:14px; color:#3b82f6;\">\u0E40\u0E27\u0E25\u0E32 (\u0E1B\u0E25\u0E48\u0E2D\u0E22\u0E27\u0E48\u0E32\u0E07\u0E40\u0E1E\u0E37\u0E48\u0E2D\u0E40\u0E15\u0E34\u0E21\u0E17\u0E35\u0E2B\u0E25\u0E31\u0E07)</ion-label>\n              <ion-input type=\"text\" [(ngModel)]=\"stampGenTime\" placeholder=\"\u0E40\u0E0A\u0E48\u0E19 09.00\" [disabled]=\"!stampGenShowTime\"></ion-input>\n            </ion-item>\n          </ng-container>\n\n          <div style=\"margin-top: 10px; display: flex; gap: 8px; justify-content: center;\">\n            <div class=\"color-dot\" style=\"background:#ef4444; width: 30px; height: 30px;\" (click)=\"stampGenColor='#ef4444'\" [class.active]=\"stampGenColor === '#ef4444'\"></div>\n            <div class=\"color-dot\" style=\"background:#3b82f6; width: 30px; height: 30px;\" (click)=\"stampGenColor='#3b82f6'\" [class.active]=\"stampGenColor === '#3b82f6'\"></div>\n            <div class=\"color-dot\" style=\"background:#10b981; width: 30px; height: 30px;\" (click)=\"stampGenColor='#10b981'\" [class.active]=\"stampGenColor === '#10b981'\"></div>\n            <div class=\"color-dot\" style=\"background:#000000; width: 30px; height: 30px;\" (click)=\"stampGenColor='#000000'\" [class.active]=\"stampGenColor === '#000000'\"></div>\n          </div>\n\n          <ion-item lines=\"none\" style=\"--background: transparent; --padding-start: 0; margin-top: 8px;\">\n            <ion-checkbox [(ngModel)]=\"stampGenNoBorder\" slot=\"start\" style=\"margin-right: 8px;\"></ion-checkbox>\n            <ion-label style=\"font-size: 14px; color: #64748b;\">\u0E44\u0E21\u0E48\u0E41\u0E2A\u0E14\u0E07\u0E40\u0E2A\u0E49\u0E19\u0E02\u0E2D\u0E1A</ion-label>\n          </ion-item>\n        </div>\n\n        <div class=\"signature-picker-modal__actions\" style=\"justify-content: center;\">\n          <ion-button fill=\"outline\" color=\"medium\" (click)=\"cancelStampGenerator()\" style=\"margin-right: 8px;\">\u0E01\u0E25\u0E31\u0E1A</ion-button>\n          <ion-button color=\"primary\" (click)=\"saveGeneratedStamp()\"><svg-icon name=\"save-outline\" slot=\"start\"></svg-icon> \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E41\u0E25\u0E30\u0E19\u0E33\u0E44\u0E1B\u0E43\u0E0A\u0E49</ion-button>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <!-- Signature Pad Modal -->\n  <div class=\"signature-modal\" *ngIf=\"showSignaturePad\">\n    <div class=\"signature-modal__backdrop\" (click)=\"closeSignaturePad()\"></div>\n    <div class=\"signature-modal__content\">\n      <h3>\u0E25\u0E07\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19</h3>\n\n      <!-- Mode Tabs -->\n      <div class=\"sig-mode-tabs\">\n        <button class=\"sig-mode-tab\" [class.active]=\"sigMode === 'draw'\" (click)=\"switchSigMode('draw')\">\n          <svg-icon name=\"pencil-outline\"></svg-icon>\n          \u0E27\u0E32\u0E14\n        </button>\n        <button class=\"sig-mode-tab\" [class.active]=\"sigMode === 'type'\" (click)=\"switchSigMode('type')\">\n          <svg-icon name=\"text-outline\"></svg-icon>\n          \u0E1E\u0E34\u0E21\u0E1E\u0E4C\n        </button>\n      </div>\n\n      <p class=\"signature-modal__hint\" *ngIf=\"sigMode === 'draw'\">\u0E27\u0E32\u0E14\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13\u0E43\u0E19\u0E01\u0E23\u0E2D\u0E1A\u0E14\u0E49\u0E32\u0E19\u0E25\u0E48\u0E32\u0E07 (\u0E22\u0E01\u0E1B\u0E32\u0E01\u0E01\u0E32\u0E41\u0E25\u0E49\u0E27\u0E27\u0E32\u0E14\u0E15\u0E48\u0E2D\u0E44\u0E14\u0E49)</p>\n      <p class=\"signature-modal__hint\" *ngIf=\"sigMode === 'type'\">\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E0A\u0E37\u0E48\u0E2D\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13\u0E41\u0E25\u0E49\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23</p>\n\n      <!-- Draw mode: Pen Options -->\n      <div class=\"signature-modal__pen-options\" *ngIf=\"sigMode === 'draw'\">\n        <div class=\"pen-option-group\">\n          <span class=\"pen-option-label\">\u0E2A\u0E35:</span>\n          <div class=\"color-dots\">\n            <div class=\"color-dot\" style=\"background:#000\" (click)=\"setSignaturePenColor('#000000')\"\n              [class.active]=\"signaturePenColor === '#000000'\"></div>\n            <div class=\"color-dot\" style=\"background:#00f\" (click)=\"setSignaturePenColor('#0000FF')\"\n              [class.active]=\"signaturePenColor === '#0000FF'\"></div>\n            <div class=\"color-dot\" style=\"background:#f00\" (click)=\"setSignaturePenColor('#FF0000')\"\n              [class.active]=\"signaturePenColor === '#FF0000'\"></div>\n          </div>\n        </div>\n        <div class=\"pen-option-group\">\n          <span class=\"pen-option-label\">\u0E02\u0E19\u0E32\u0E14:</span>\n          <button class=\"pen-size-btn\" (click)=\"changeSignaturePenSize(-0.5)\" [disabled]=\"signaturePenSize <= 1\">\n            <svg-icon name=\"remove\"></svg-icon>\n          </button>\n          <span class=\"pen-size-val\">{{ signaturePenSize }}</span>\n          <button class=\"pen-size-btn\" (click)=\"changeSignaturePenSize(0.5)\" [disabled]=\"signaturePenSize >= 10\">\n            <svg-icon name=\"add\"></svg-icon>\n          </button>\n        </div>\n      </div>\n\n      <!-- Type mode: Text + Font Options -->\n      <div class=\"signature-modal__type-opts\" *ngIf=\"sigMode === 'type'\">\n        <div class=\"signature-modal__type-top\">\n          <input class=\"signature-modal__type-input\" type=\"text\"\n            placeholder=\"\u0E1E\u0E34\u0E21\u0E1E\u0E4C\u0E0A\u0E37\u0E48\u0E2D\u0E02\u0E2D\u0E07\u0E04\u0E38\u0E13...\"\n            [(ngModel)]=\"typedText\"\n            (input)=\"onTypedInput()\" />\n          <div class=\"signature-modal__type-color\">\n            <span class=\"pen-option-label\">\u0E2A\u0E35:</span>\n            <div class=\"color-dots\">\n              <div class=\"color-dot\" style=\"background:#000\"\n                (click)=\"setSignaturePenColor('#000000'); renderTypedCanvas()\"\n                [class.active]=\"signaturePenColor === '#000000'\"></div>\n              <div class=\"color-dot\" style=\"background:#00f\"\n                (click)=\"setSignaturePenColor('#0000FF'); renderTypedCanvas()\"\n                [class.active]=\"signaturePenColor === '#0000FF'\"></div>\n              <div class=\"color-dot\" style=\"background:#f00\"\n                (click)=\"setSignaturePenColor('#FF0000'); renderTypedCanvas()\"\n                [class.active]=\"signaturePenColor === '#FF0000'\"></div>\n            </div>\n          </div>\n        </div>\n        <div class=\"signature-modal__type-fonts\">\n          <button class=\"type-font-btn\" *ngFor=\"let f of typedFontOptions; let i = index\"\n            [class.active]=\"typedFontIndex === i\"\n            [style.fontFamily]=\"f.family\"\n            [style.fontWeight]=\"f.weight\"\n            [style.fontStyle]=\"f.style\"\n            (click)=\"pickTypedFont(i)\">\n            {{ typedText || '\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19' }}\n          </button>\n        </div>\n      </div>\n\n      <canvas #signatureCanvas class=\"signature-modal__canvas\"\n        [class.signature-modal__canvas--preview]=\"sigMode === 'type'\"></canvas>\n\n      <div class=\"signature-modal__actions\">\n        <ion-button fill=\"outline\" color=\"medium\" (click)=\"clearSignaturePad()\" *ngIf=\"sigMode === 'draw'\">\n          <svg-icon name=\"refresh\" slot=\"start\"></svg-icon>\n          \u0E25\u0E49\u0E32\u0E07\n        </ion-button>\n        <ion-button fill=\"outline\" color=\"danger\" (click)=\"closeSignaturePad()\">\n          <svg-icon name=\"close\" slot=\"start\"></svg-icon>\n          \u0E22\u0E01\u0E40\u0E25\u0E34\u0E01\n        </ion-button>\n        <ion-button fill=\"outline\" color=\"tertiary\" (click)=\"triggerSignatureUpload()\" *ngIf=\"sigMode === 'draw'\">\n          <svg-icon name=\"image-outline\" slot=\"start\"></svg-icon>\n          \u0E2D\u0E31\u0E1E\u0E42\u0E2B\u0E25\u0E14\u0E23\u0E39\u0E1B\n        </ion-button>\n        <ion-button fill=\"outline\" color=\"success\" (click)=\"saveSignatureToDatabase()\">\n          <svg-icon name=\"cloud-upload\" slot=\"start\"></svg-icon>\n          \u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49\u0E43\u0E0A\u0E49\u0E20\u0E32\u0E22\u0E2B\u0E25\u0E31\u0E07\n        </ion-button>\n        <ion-button color=\"primary\" (click)=\"saveSignature()\">\n          <svg-icon name=\"checkmark\" slot=\"start\"></svg-icon>\n          \u0E43\u0E0A\u0E49\u0E04\u0E23\u0E31\u0E49\u0E07\u0E19\u0E35\u0E49\n        </ion-button>\n      </div>\n    </div>\n  </div>\n\n  <!-- Signature Picker Modal -->\n  <div class=\"signature-picker-modal\" *ngIf=\"showSignaturePicker\">\n    <div class=\"signature-picker-modal__backdrop\" (click)=\"closeSignaturePicker()\"></div>\n    <div class=\"signature-picker-modal__content\">\n      <h3>\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19</h3>\n      <p class=\"signature-picker-modal__hint\">\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49 \u0E2B\u0E23\u0E37\u0E2D\u0E27\u0E32\u0E14\u0E43\u0E2B\u0E21\u0E48</p>\n\n      <div class=\"signature-picker-modal__loading\" *ngIf=\"isLoadingSignatures\">\n        <ion-spinner name=\"crescent\"></ion-spinner>\n        <span>\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14...</span>\n      </div>\n\n      <div class=\"signature-picker-modal__list\" *ngIf=\"!isLoadingSignatures\">\n        <div class=\"signature-item\" *ngFor=\"let sig of savedSignatures\" (click)=\"useSavedSignature(sig)\">\n          <img [src]=\"sig.signature_data\" [alt]=\"sig.signature_name\" />\n          <div class=\"signature-item__info\">\n            <span class=\"signature-item__name\">{{ sig.signature_name }}</span>\n            <span class=\"signature-item__badge\" *ngIf=\"sig.is_default\">\u0E2B\u0E25\u0E31\u0E01</span>\n          </div>\n          <div class=\"signature-item__actions\">\n            <button class=\"signature-item__btn\" (click)=\"setDefaultSignature(sig, $event)\"\n              [class.active]=\"sig.is_default\" title=\"\u0E15\u0E31\u0E49\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E25\u0E31\u0E01\">\n              <svg-icon name=\"star\"></svg-icon>\n            </button>\n            <button class=\"signature-item__btn signature-item__btn--delete\" (click)=\"deleteSavedSignature(sig, $event)\"\n              title=\"\u0E25\u0E1A\">\n              <svg-icon name=\"trash\"></svg-icon>\n            </button>\n          </div>\n        </div>\n\n        <div class=\"signature-picker-modal__empty\" *ngIf=\"savedSignatures.length === 0\">\n          <svg-icon name=\"create-outline\"></svg-icon>\n          <p>\u0E22\u0E31\u0E07\u0E44\u0E21\u0E48\u0E21\u0E35\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E17\u0E35\u0E48\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01\u0E44\u0E27\u0E49</p>\n        </div>\n      </div>\n\n      <div class=\"signature-picker-modal__actions\">\n        <ion-button fill=\"outline\" color=\"medium\" (click)=\"closeSignaturePicker()\">\n          <svg-icon name=\"close\" slot=\"start\"></svg-icon>\n          \u0E1B\u0E34\u0E14\n        </ion-button>\n        <ion-button fill=\"outline\" color=\"secondary\" (click)=\"triggerSignatureUpload()\">\n          <svg-icon name=\"cloud-upload\" slot=\"start\"></svg-icon>\n          \u0E2D\u0E31\u0E1E\u0E42\u0E2B\u0E25\u0E14\u0E23\u0E39\u0E1B\n        </ion-button>\n        <ion-button color=\"primary\" (click)=\"openSignaturePadFromPicker()\">\n          <svg-icon name=\"create\" slot=\"start\"></svg-icon>\n          \u0E27\u0E32\u0E14\u0E25\u0E32\u0E22\u0E40\u0E0B\u0E47\u0E19\u0E43\u0E2B\u0E21\u0E48\n        </ion-button>\n      </div>\n    </div>\n  </div>\n\n  <!-- Preview Overlay -->\n  <div class=\"preview-overlay\" *ngIf=\"showPreviewOverlay\">\n    <div class=\"preview-header\">\n      <div class=\"preview-title\">{{ isCancelMode ? '\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E01\u0E48\u0E2D\u0E19\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01' : '\u0E15\u0E23\u0E27\u0E08\u0E2A\u0E2D\u0E1A\u0E40\u0E2D\u0E01\u0E2A\u0E32\u0E23\u0E01\u0E48\u0E2D\u0E19\u0E25\u0E07\u0E19\u0E32\u0E21' }}</div>\n      <div class=\"preview-actions\">\n        <ion-button fill=\"clear\" color=\"dark\" (click)=\"backToEdit()\">\n          <svg-icon slot=\"start\" name=\"arrow-back-outline\"></svg-icon>\n          \u0E01\u0E25\u0E31\u0E1A\u0E44\u0E1B\u0E41\u0E01\u0E49\u0E44\u0E02\n        </ion-button>\n        <ion-button color=\"success\" (click)=\"confirmSave()\">\n          <svg-icon slot=\"start\" name=\"checkmark-done-outline\"></svg-icon>\n          {{ isCancelMode ? '\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E01\u0E32\u0E23\u0E1A\u0E31\u0E19\u0E17\u0E36\u0E01' : '\u0E22\u0E37\u0E19\u0E22\u0E31\u0E19\u0E41\u0E25\u0E30\u0E25\u0E07\u0E19\u0E32\u0E21' }}\n        </ion-button>\n      </div>\n    </div>\n    <div class=\"preview-scroll-area\">\n    <div class=\"preview-body\">\n      <div class=\"preview-filter-bar\" *ngIf=\"previewIsFiltered || isLoadingAllPreview\">\n        <svg-icon name=\"information-circle-outline\"></svg-icon>\n        <span>\u0E41\u0E2A\u0E14\u0E07\u0E40\u0E09\u0E1E\u0E32\u0E30\u0E2B\u0E19\u0E49\u0E32\u0E17\u0E35\u0E48\u0E21\u0E35\u0E01\u0E32\u0E23\u0E41\u0E01\u0E49\u0E44\u0E02 ({{ previewPages.length }} / {{ previewTotalPages }} \u0E2B\u0E19\u0E49\u0E32)</span>\n        <ion-button fill=\"clear\" size=\"small\" (click)=\"loadAllPreviewPages()\" [disabled]=\"isLoadingAllPreview\">\n          <ion-spinner *ngIf=\"isLoadingAllPreview\" name=\"crescent\" slot=\"start\"></ion-spinner>\n          <span *ngIf=\"!isLoadingAllPreview\">\u0E41\u0E2A\u0E14\u0E07\u0E17\u0E31\u0E49\u0E07\u0E2B\u0E21\u0E14 {{ previewTotalPages }} \u0E2B\u0E19\u0E49\u0E32</span>\n          <span *ngIf=\"isLoadingAllPreview\">\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14...</span>\n        </ion-button>\n      </div>\n      <div class=\"preview-pages\" *ngIf=\"previewPages.length > 0\">\n        <img *ngFor=\"let page of previewPages; let i = index\" [src]=\"page\" [alt]=\"'Page ' + (i + 1)\"\n          class=\"preview-page-img\">\n      </div>\n      <div *ngIf=\"previewPages.length === 0\" class=\"preview-loading\">\n        <ion-spinner name=\"crescent\"></ion-spinner>\n        <p>\u0E01\u0E33\u0E25\u0E31\u0E07\u0E42\u0E2B\u0E25\u0E14 Preview...</p>\n      </div>\n    </div>\n    </div>\n  </div>\n\n  <!-- Custom Context Menu -->\n  <div class=\"custom-context-menu\" *ngIf=\"contextMenu.show\" [style.left.px]=\"contextMenu.x\" [style.top.px]=\"contextMenu.y\">\n    <button class=\"menu-btn\" (click)=\"contextBringToFront()\">\n      <svg-icon name=\"arrow-up-circle-outline\"></svg-icon> \u0E19\u0E33\u0E44\u0E1B\u0E44\u0E27\u0E49\u0E2B\u0E19\u0E49\u0E32\u0E2A\u0E38\u0E14 (Bring to Front)\n    </button>\n    <button class=\"menu-btn\" (click)=\"contextBringForward()\">\n      <svg-icon name=\"chevron-up-outline\"></svg-icon> \u0E19\u0E33\u0E44\u0E1B\u0E02\u0E49\u0E32\u0E07\u0E2B\u0E19\u0E49\u0E32 (Bring Forward)\n    </button>\n    <button class=\"menu-btn\" (click)=\"contextSendBackward()\">\n      <svg-icon name=\"chevron-down-outline\"></svg-icon> \u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E02\u0E49\u0E32\u0E07\u0E2B\u0E25\u0E31\u0E07 (Send Backward)\n    </button>\n    <button class=\"menu-btn\" (click)=\"contextSendToBack()\">\n      <svg-icon name=\"arrow-down-circle-outline\"></svg-icon> \u0E2A\u0E48\u0E07\u0E44\u0E1B\u0E44\u0E27\u0E49\u0E2B\u0E25\u0E31\u0E07\u0E2A\u0E38\u0E14 (Send to Back)\n    </button>\n    <div class=\"menu-divider\"></div>\n    <button class=\"menu-btn danger-btn\" (click)=\"deleteContextMenuTarget()\">\n      <svg-icon name=\"trash-outline\"></svg-icon> \u0E25\u0E1A (Delete)\n    </button>\n  </div>\n\n</ion-content>",
                    styles: ["@charset \"UTF-8\";:host{display:block;height:100%}.annotator-content{--background: #f1f5f9;height:100%;overflow:hidden;position:relative}.annotator-content::part(scroll){display:flex;flex-direction:column;height:100%;overflow:hidden}ion-header{box-shadow:0 2px 8px #0000000d}ion-header ion-toolbar{--background: #fff;--color: #1e293b;--padding-top: 8px;--padding-bottom: 8px}.annotator-layout{display:flex;height:100%;width:100%;min-height:0;overflow:hidden;position:relative}.annotator-layout-v2{display:flex;flex-direction:column;height:100%;width:100%;min-height:0;overflow:hidden}.toolbar-row{display:flex;align-items:center;background:#f8fafc;border-bottom:1px solid #e2e8f0;padding:6px 12px;grid-gap:8px;gap:8px;flex-shrink:0}.toolbar-row--nav{background:#fff}.toolbar-row--tools{background:#f1f5f9;flex-wrap:wrap}.toolbar-group{display:flex;align-items:center;grid-gap:4px;gap:4px}.toolbar-group--zoom,.toolbar-group--pager{grid-gap:2px;gap:2px}.toolbar-group--save{margin-left:auto}.ppv-select{height:28px;padding:0 6px;border:1px solid #e2e8f0;border-radius:6px;background:#fff;color:#334155;font-size:12px;cursor:pointer;outline:none}.ppv-select:focus{border-color:#3b82f6}.toolbar-divider{width:1px;height:24px;background:#e2e8f0;margin:0 8px}.toolbar-spacer{flex:1}.toolbar-label{font-size:12px;color:#64748b;min-width:50px;text-align:center}.toolbar-btn{display:flex;align-items:center;justify-content:center;grid-gap:4px;gap:4px;background:transparent;border:1px solid transparent;border-radius:6px;padding:6px 10px;cursor:pointer;transition:all .15s ease;color:#475569;font-size:13px}.toolbar-btn svg-icon{font-size:18px}.toolbar-btn .zoom-icon{font-size:10px;margin-left:-4px}.toolbar-btn:hover:not(:disabled){background:#e2e8f0}.toolbar-btn:disabled{opacity:.4;cursor:not-allowed}.toolbar-btn.active{background:#3b82f6;color:#fff;border-color:#2563eb}.toolbar-btn--guide{background:rgba(14,165,233,.1);color:#0ea5e9;border:1px solid rgba(14,165,233,.3);padding:6px 12px}.toolbar-btn--guide:hover{background:rgba(14,165,233,.2)}.toolbar-btn--guide.active{background:#0ea5e9;color:#fff;border-color:#0284c7}.toolbar-btn--save{background:linear-gradient(135deg,#22c55e 0%,#16a34a 100%);color:#fff;padding:7px 16px;font-weight:700;font-size:14px;border-radius:8px;border:1px solid #16a34a;box-shadow:0 2px 8px #22c55e59;letter-spacing:.2px;transition:all .2s ease}.toolbar-btn--save svg-icon{font-size:17px}.toolbar-btn--save:hover:not(:disabled){background:linear-gradient(135deg,#16a34a 0%,#15803d 100%);box-shadow:0 4px 14px #22c55e80;transform:translateY(-1px)}.toolbar-btn--save:active{transform:translateY(0);box-shadow:0 2px 6px #22c55e4d}.toolbar-btn--danger{color:#ef4444}.toolbar-btn--danger:hover{background:#fee2e2}.toolbar-btn--toggle{font-size:11px;padding:4px 6px;grid-gap:2px;gap:2px}.toolbar-btn--toggle svg-icon{font-size:14px}.toolbar-btn--toggle .toggle-label{font-size:9px;font-weight:600;letter-spacing:.5px}.tool-item{display:flex;align-items:center;grid-gap:4px;gap:4px}.tool-options{display:flex;align-items:center;grid-gap:4px;gap:4px;background:#f1f5f9;padding:4px 8px;border-radius:6px;border:1px solid #e2e8f0}.tool-options button{width:24px;height:24px;border:none;background:#fff;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center}.tool-options button:hover{background:#e2e8f0}.tool-options button:disabled{opacity:.4}.tool-options button svg-icon{font-size:14px}.tool-options span{font-size:11px;min-width:24px;text-align:center;color:#64748b}.color-dots{display:flex;grid-gap:4px;gap:4px;margin-left:4px}.color-dot{width:16px;height:16px;border-radius:50%;border:2px solid transparent;cursor:pointer;transition:all .15s ease;position:relative;overflow:hidden}.color-dot:hover{transform:scale(1.1)}.color-dot.active{border-color:#1e293b;box-shadow:0 0 0 2px #fff,0 0 0 4px currentColor}.color-dot--custom{box-shadow:0 0 0 1px #cbd5e1}.color-dot--custom input[type=color]{position:absolute;top:-10px;left:-10px;width:40px;height:40px;cursor:pointer;opacity:0}.color-dot--custom:hover{box-shadow:0 0 0 1.5px #94a3b8}.insert-page-tool{position:relative}.insert-page-tool .insert-badge-icon{font-size:11px!important;margin-left:-6px;margin-top:-8px;color:#22c55e}.insert-page-dropdown{position:absolute;top:calc(100% + 4px);right:0;z-index:500}.insert-page-backdrop{position:fixed;inset:0;z-index:499}.insert-page-menu{position:relative;z-index:500;background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:8px;box-shadow:0 6px 24px #00000024;min-width:220px;display:flex;flex-direction:column;grid-gap:4px;gap:4px}.insert-page-title{font-size:11px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;padding:2px 6px 6px;border-bottom:1px solid #f1f5f9;margin-bottom:2px}.insert-page-btn{display:flex;align-items:center;grid-gap:10px;gap:10px;width:100%;padding:9px 12px;border:1px solid transparent;border-radius:7px;background:transparent;cursor:pointer;color:#334155;font-size:13px;text-align:left;transition:all .15s}.insert-page-btn small{color:#94a3b8;font-size:11px}.insert-page-btn svg-icon{font-size:16px;color:#3b82f6;flex-shrink:0}.insert-page-btn:hover:not(:disabled){background:#eff6ff;border-color:#bfdbfe;color:#1e40af}.insert-page-btn:hover:not(:disabled) svg-icon{color:#1d4ed8}.insert-page-btn:active:not(:disabled){background:#dbeafe}.insert-page-btn:disabled{opacity:.35;cursor:not-allowed}.insert-page-btn--danger svg-icon{color:#ef4444}.insert-page-btn--danger:hover:not(:disabled){background:#fff1f2;border-color:#fecaca;color:#b91c1c}.insert-page-btn--danger:hover:not(:disabled) svg-icon{color:#dc2626}.insert-page-btn--danger:active:not(:disabled){background:#fee2e2}.insert-page-btn--undo svg-icon{color:#f59e0b}.insert-page-btn--undo:hover:not(:disabled){background:#fffbeb;border-color:#fde68a;color:#92400e}.insert-page-btn--undo:hover:not(:disabled) svg-icon{color:#d97706}.insert-page-btn--undo:active:not(:disabled){background:#fef3c7}.insert-orient-row{display:flex;align-items:center;grid-gap:8px;gap:8px;padding:4px 6px 8px}.insert-orient-label{font-size:12px;color:#64748b;white-space:nowrap;flex-shrink:0}.insert-orient-group{display:flex;grid-gap:4px;gap:4px;flex:1}.insert-orient-btn{display:flex;align-items:center;grid-gap:5px;gap:5px;flex:1;justify-content:center;padding:6px 8px;border:1.5px solid #e2e8f0;border-radius:7px;background:#f8fafc;cursor:pointer;font-size:12px;color:#475569;transition:all .15s}.insert-orient-btn svg-icon{font-size:15px}.insert-orient-btn:hover{background:#f1f5f9;border-color:#cbd5e1}.insert-orient-btn.active{background:#eff6ff;border-color:#3b82f6;color:#1e40af;font-weight:600}.insert-orient-btn.active svg-icon{color:#3b82f6}.insert-page-title--danger{color:#ef4444!important;background:#fff1f2;border-radius:5px;padding:3px 6px 6px!important}.insert-menu-divider{height:1px;background:#f1f5f9;margin:2px 0 4px}.shape-tool-item{position:relative;display:flex;align-items:flex-start;grid-gap:4px;gap:4px;flex-wrap:nowrap}.shape-chevron{font-size:10px!important;margin-left:-2px;opacity:.7}.mark-tool-item{position:relative;display:flex;align-items:flex-start}.mark-toolbar-btn{display:flex!important;flex-direction:row!important;align-items:center!important;grid-gap:4px!important;gap:4px!important;padding:0 8px!important;min-width:unset!important}.mark-btn-label{font-size:11px;font-weight:600;white-space:nowrap;letter-spacing:-.01em}.mark-chevron{font-size:10px!important;opacity:.7}.mark-popup{position:absolute;top:calc(100% + 6px);left:0;z-index:300;background:#fff;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 6px 24px #00000024;padding:12px 14px;min-width:210px;display:flex;flex-direction:column;grid-gap:8px;gap:8px}.mark-popup-section-label{font-size:11px;font-weight:600;color:#64748b;letter-spacing:.02em}.mark-popup-divider{height:1px;background:#f1f5f9;margin:0}.mark-quick-row{display:flex;grid-gap:8px;gap:8px;align-items:center}.mark-quick-btn{width:44px;height:44px;border:1.5px solid #e2e8f0;border-radius:8px;background:#f8fafc;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#1e293b;padding:0;transition:background .12s,border-color .12s}.mark-quick-btn:hover{background:#e2e8f0}.mark-quick-btn.active{background:#dbeafe;border-color:#3b82f6;color:#1d4ed8}.mark-form-list{display:flex;flex-direction:column;grid-gap:2px;gap:2px}.mark-form-row-btn{display:flex;align-items:center;grid-gap:10px;gap:10px;width:100%;padding:7px 8px;border:none;border-radius:7px;background:transparent;cursor:pointer;color:#1e293b;font-size:13.5px;text-align:left;transition:background .1s}.mark-form-row-btn:hover{background:#f1f5f9}.mark-form-row-btn.active{background:#dbeafe;color:#1d4ed8}.mark-form-row-icon{width:24px;height:24px;display:flex;align-items:center;justify-content:center;flex-shrink:0}.mark-form-row-icon--text{font-size:14px;font-weight:700;color:inherit}.mark-controls-row{display:flex;align-items:center;grid-gap:4px;gap:4px}.mark-controls-row button{width:24px;height:24px;border:1px solid #e2e8f0;border-radius:4px;background:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center}.mark-controls-row button:hover{background:#e2e8f0}.mark-controls-row button:disabled{opacity:.4;cursor:default}.mark-size-val{min-width:22px;text-align:center;font-size:12px;font-weight:500}.mark-cancel-btn{width:100%;display:flex;align-items:center;justify-content:center;grid-gap:6px;gap:6px;padding:7px 0;border:none;border-radius:6px;background:#f1f5f9;color:#64748b;font-size:13px;font-weight:500;cursor:pointer;transition:background .15s,color .15s}.mark-cancel-btn svg-icon{font-size:16px}.mark-cancel-btn:hover{background:#fee2e2;color:#ef4444}.shape-dropdown{position:absolute;top:calc(100% + 4px);left:0;z-index:300;display:flex;flex-direction:column;grid-gap:2px;gap:2px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:6px;box-shadow:0 4px 16px #0000001f;min-width:46px}.shape-dropdown .shape-dd-btn{display:flex;align-items:center;justify-content:center;width:34px;height:34px;border:1px solid transparent;border-radius:6px;background:transparent;cursor:pointer;color:#475569;transition:all .15s}.shape-dropdown .shape-dd-btn svg-icon{font-size:18px}.shape-dropdown .shape-dd-btn:hover{background:#f1f5f9;color:#1e293b}.shape-dropdown .shape-dd-btn.active{background:#3b82f6;color:#fff;border-color:#2563eb}.shape-options-panel{display:flex;align-items:center;grid-gap:8px;gap:8px;flex-wrap:wrap;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:5px 10px;margin-left:2px}.shape-opt-group{display:flex;align-items:center;grid-gap:5px;gap:5px}.shape-opt-label{font-size:10px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:.4px;white-space:nowrap}.sopt-divider{width:1px;height:30px;background:#e2e8f0;flex-shrink:0}.sopt-btn{display:flex;align-items:center;justify-content:center;width:22px;height:22px;border:1px solid #e2e8f0;border-radius:4px;background:#fff;cursor:pointer;color:#475569;transition:background .12s}.sopt-btn svg-icon{font-size:13px}.sopt-btn:hover:not(:disabled){background:#e2e8f0}.sopt-btn:disabled{opacity:.35;cursor:not-allowed}.sopt-val{font-size:11px;font-weight:600;color:#475569;min-width:18px;text-align:center}.sopt-fill-toggle{display:flex;align-items:center;justify-content:center;width:26px;height:26px;border:1px solid #e2e8f0;border-radius:5px;background:#fff;cursor:pointer;color:#94a3b8;transition:all .15s}.sopt-fill-toggle svg-icon{font-size:15px}.sopt-fill-toggle:hover{background:#f1f5f9;color:#475569}.sopt-fill-toggle.active{background:#3b82f6;color:#fff;border-color:#2563eb}.mac-color-grid{display:grid;grid-template-columns:repeat(8,16px);grid-gap:2px;gap:2px;transition:opacity .15s}.mac-color-grid.disabled{opacity:.3;pointer-events:none}.mac-swatch{width:16px;height:16px;border-radius:3px;border:1.5px solid rgba(0,0,0,.18);cursor:pointer;transition:transform .1s,box-shadow .1s;flex-shrink:0}.mac-swatch:hover{transform:scale(1.25);z-index:2;box-shadow:0 2px 6px #0003}.mac-swatch.active{transform:scale(1.15);box-shadow:0 0 0 2px #fff,0 0 0 3.5px #3b82f6;z-index:3}.mac-swatch--current{width:22px;height:22px;border-radius:4px;border:2px solid #cbd5e1;cursor:default;pointer-events:none}.mac-swatch--current:hover{transform:none}.mac-custom-color{display:flex;align-items:center;grid-gap:3px;gap:3px;transition:opacity .15s}.mac-custom-color.disabled{opacity:.3;pointer-events:none}.mac-custom-color input[type=color]{width:22px;height:22px;border:2px solid #cbd5e1;border-radius:4px;padding:1px;cursor:pointer;background:none}.mac-custom-color input[type=color]::-webkit-color-swatch-wrapper{padding:0}.mac-custom-color input[type=color]::-webkit-color-swatch{border:none;border-radius:2px}@media (max-width: 767px){.shape-options-panel{padding:4px 6px;grid-gap:5px;gap:5px}.mac-color-grid{grid-template-columns:repeat(8,13px)}.mac-color-grid .mac-swatch{width:13px;height:13px}}.main-area{display:flex;flex:1;min-height:0;overflow:hidden}.thumbnails-sidebar{width:148px;min-width:148px;background:#1a2232;display:flex;flex-direction:column;overflow:visible;position:relative;z-index:10}.thumb-list{flex:1;overflow-y:auto;overflow-x:visible;display:flex;flex-direction:column;align-items:center;padding:8px 0 16px;grid-gap:0;gap:0;scrollbar-width:thin;scrollbar-color:#334155 #1a2232}.thumb-list::-webkit-scrollbar{width:5px}.thumb-list::-webkit-scrollbar-track{background:#1a2232}.thumb-list::-webkit-scrollbar-thumb{background:#334155;border-radius:3px}.thumb-card-wrap{width:120px;display:flex;flex-direction:column;border-radius:10px;overflow:hidden;box-shadow:0 3px 12px #0000004d;flex-shrink:0;cursor:grab;transition:opacity .15s,transform .15s;position:relative}.thumb-card-wrap--dragging{opacity:.4;cursor:grabbing}.thumb-card-wrap--drop-top:before,.thumb-card-wrap--drop-bot:after{content:\"\";position:absolute;left:0;right:0;height:3px;background:#3b82f6;border-radius:2px;z-index:10}.thumb-card-wrap--drop-top:before{top:-6px}.thumb-card-wrap--drop-bot:after{bottom:-6px}.thumb-card{width:120px;background:#243044;border-radius:0;overflow:hidden;cursor:pointer;border:2.5px solid transparent;border-bottom:none;transition:border-color .15s}.thumb-card-wrap:hover>.thumb-card{border-color:#63b3ed66}.thumb-card-wrap:has(.thumb-card.active)>.thumb-card{border-color:#3b82f6}.thumb-card.active{border-color:#3b82f6}.thumb-card__img-wrap{padding:6px 6px 0;overflow:hidden;border-radius:8px 8px 0 0}.thumb-card__img-wrap img{width:100%;border-radius:5px;display:block;box-shadow:0 2px 8px #0006}.thumb-card__label{display:block;text-align:center;color:#94a3b8;font-size:11px;font-weight:500;padding:4px 0 3px}.thumb-card__actions{display:flex;align-items:center;justify-content:space-around;padding:5px 4px;background:#0f172a;border-top:1px solid #334155;border-radius:0 0 8px 8px}.thumb-action-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;border:1px solid #334155;border-radius:6px;background:#1e293b;color:#94a3b8;cursor:pointer;transition:all .15s;flex-shrink:0}.thumb-action-btn svg-icon{font-size:15px}.thumb-action-btn:hover:not(:disabled){background:#334155;color:#e2e8f0;border-color:#475569}.thumb-action-btn:disabled{opacity:.25;cursor:not-allowed}.thumb-action-btn--danger{color:#f87171;border-color:#7f1d1d;background:#1c0a0a}.thumb-action-btn--danger:hover:not(:disabled){background:#450a0a;border-color:#ef4444;color:#fca5a5}.thumb-insert-row{display:flex;align-items:center;justify-content:center;width:100%;padding:6px 0;position:relative;flex-shrink:0}.thumb-insert-slot{position:relative;display:flex;align-items:center;justify-content:center}.thumb-add-btn{width:32px;height:32px;border-radius:50%;border:2px solid #3b82f6;background:#1e40af;color:#93c5fd;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s;box-shadow:0 2px 8px #3b82f666}.thumb-add-btn svg-icon{font-size:18px;font-weight:700}.thumb-add-btn:hover{background:#2563eb;color:#fff;transform:scale(1.1);box-shadow:0 4px 14px #3b82f680}.thumb-add-btn:active{transform:scale(.95)}.thumb-insert-dropdown,.thumb-insert-overlay{position:fixed;left:158px;z-index:2000;transform:translateY(-50%)}.thumb-insert-backdrop{position:fixed;inset:0;z-index:698}.thumb-insert-menu{position:relative;z-index:699;background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:8px;box-shadow:0 8px 32px #0000002e;min-width:210px;display:flex;flex-direction:column;grid-gap:2px;gap:2px}.thumb-insert-menu:before{content:\"\";position:absolute;left:-8px;top:50%;transform:translateY(-50%);border:8px solid transparent;border-right-color:#fff;border-left:none}.thumb-insert-opt{display:flex;align-items:center;grid-gap:10px;gap:10px;width:100%;padding:10px 14px;border:1px solid transparent;border-radius:8px;background:transparent;cursor:pointer;color:#1e293b;font-size:14px;font-family:inherit;text-align:left;transition:all .15s}.thumb-insert-opt svg-icon{font-size:18px;color:#3b82f6;flex-shrink:0}.thumb-insert-opt:hover{background:#eff6ff;border-color:#bfdbfe;color:#1e40af}.thumb-insert-opt:hover svg-icon{color:#1d4ed8}.thumb-insert-opt:active{background:#dbeafe}.viewer-wrapper{flex:1;display:flex;flex-direction:column;min-width:0;overflow:hidden;position:relative}.viewer-container{flex:1;overflow-y:auto;overflow-x:auto;background:#f1f5f9;display:flex;flex-direction:column;align-items:center;padding:20px;grid-gap:20px;gap:20px}.page-container{position:relative;box-shadow:0 4px 12px #00000026;background:#fff;flex-shrink:0;transform-origin:center center}.page-container.flip-mode{transition:transform .18s ease}.page-container .pdf-canvas,.page-container .annot-canvas{display:block}.page-container .annot-canvas{position:absolute;top:0;left:0;touch-action:none}@media (max-width: 767px){.toolbar-row{padding:4px 8px;grid-gap:4px;gap:4px;flex-wrap:nowrap;overflow-x:auto;-webkit-overflow-scrolling:touch}.toolbar-row::-webkit-scrollbar{display:none}.toolbar-row--tools{padding:6px 8px}.toolbar-btn{padding:4px 6px}.toolbar-btn svg-icon{font-size:16px}.toolbar-btn span{display:none}.toolbar-divider{margin:0 4px}.thumbnails-sidebar{width:80px;min-width:80px;padding:8px 4px}.thumbnail-item img{max-width:64px}.tool-options{display:flex;flex-shrink:0}.hint{display:none}}@media (max-width: 480px){.thumbnails-sidebar{display:none}.toolbar-label{min-width:30px;font-size:10px}}.sidebar{width:200px;min-width:200px;background:#1e293b;color:#fff;display:flex;flex-direction:column;padding:16px;z-index:100;box-shadow:4px 0 15px #0000001a;overflow-y:auto}.sidebar__section{margin-bottom:24px}.sidebar__section--nav{background:rgba(255,255,255,.05);padding:12px;border-radius:12px;margin-bottom:20px;display:flex;flex-direction:column;grid-gap:12px;gap:12px}.sidebar__section--save{margin-top:auto;padding-top:20px;border-top:1px solid rgba(255,255,255,.1)}.sidebar__title{font-size:11px;font-weight:700;color:#fff6;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px}.sidebar__row{display:flex;grid-gap:8px;gap:8px;margin-bottom:8px}.sidebar__row--wrap{flex-wrap:wrap}.sidebar__btn{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;grid-gap:6px;gap:6px;padding:10px 4px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;color:#fffc;font-size:11px;cursor:pointer;transition:all .2s;box-shadow:0 2px 4px #0000001a}.sidebar__btn svg-icon{font-size:20px}.sidebar__btn:hover:not([disabled]){background:rgba(255,255,255,.15);color:#fff;transform:translateY(-1px);box-shadow:0 4px 8px #0003}.sidebar__btn.active{background:#3b82f6;color:#fff;border-color:#60a5fa;box-shadow:0 4px 12px #3b82f666}.sidebar__btn[disabled]{opacity:.3;cursor:not-allowed}.sidebar__btn--signature{background:rgba(139,92,246,.1);border-color:#8b5cf64d;color:#a78bfa}.sidebar__btn--signature.active,.sidebar__btn--signature:hover:not([disabled]){background:#8b5cf6;color:#fff}.sidebar__btn--date{background:rgba(16,185,129,.1);border-color:#10b9814d;color:#34d399}.sidebar__btn--date.active,.sidebar__btn--date:hover:not([disabled]){background:#10b981;color:#fff}.sidebar__btn--warning{background:rgba(239,68,68,.1);border-color:#ef44444d;color:#f87171}.sidebar__btn--warning:hover:not([disabled]){background:#ef4444;color:#fff}.sidebar__btn--save{background:#10b981;color:#fff;flex-direction:row;grid-gap:10px;gap:10px;font-size:14px;font-weight:600;padding:14px;box-shadow:0 4px 12px #10b98140}.sidebar__btn--save:hover:not([disabled]){background:#059669;box-shadow:0 6px 18px #10b98166}.sidebar__btn--small{flex:0 0 calc(50% - 4px);padding:8px}.sidebar__picker{display:flex;align-items:center;grid-gap:8px;gap:8px;padding:6px 8px;margin-bottom:6px;border-radius:6px;background:rgba(255,255,255,.05)}.sidebar__picker label{font-size:11px;color:#fff9;min-width:60px}.sidebar__picker input[type=color]{width:24px;height:24px;border:2px solid rgba(255,255,255,.2);border-radius:4px;cursor:pointer;padding:0}.sidebar__picker input[type=range]{flex:1;max-width:50px}.sidebar__picker span{font-size:11px;color:#ffffffb3;min-width:20px;text-align:right}.main-content{flex:1;display:flex;flex-direction:column;height:100%;min-height:0;overflow:hidden;background:#cbd5e1}.topbar-desktop{display:flex;align-items:center;justify-content:center;padding:8px 20px;background:#fff;border-bottom:1px solid #e2e8f0;box-shadow:0 2px 4px #00000005;min-height:56px}.topbar-desktop__tools{display:flex;align-items:center;grid-gap:12px;gap:12px}.topbar-desktop__tool-btn{display:flex;align-items:center;grid-gap:6px;gap:6px;padding:8px 14px;border:none;border-radius:8px;background:#fff;color:#475569;font-size:13px;font-weight:500;cursor:pointer;transition:all .15s ease;box-shadow:0 2px 5px #00000014}.topbar-desktop__tool-btn svg-icon{font-size:18px}.topbar-desktop__tool-btn:hover:not([disabled]){background:#f1f5f9;color:#1e293b;transform:translateY(-1px);box-shadow:0 4px 10px #0000001f}.topbar-desktop__tool-btn.active{background:#3b82f6;color:#fff}.topbar-desktop__tool-btn[disabled]{opacity:.4;cursor:not-allowed}.topbar-desktop .tool-option{display:flex;align-items:center;grid-gap:8px;gap:8px;background:#fff;padding:2px 8px;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 2px 5px #0000000d}.topbar-desktop .tool-option .size-controls{display:flex;align-items:center;grid-gap:4px;gap:4px;padding-left:8px;border-left:1px solid #e2e8f0}.topbar-desktop .tool-option .size-controls button{background:none;border:none;padding:4px;cursor:pointer;color:#64748b;display:flex;align-items:center}.topbar-desktop .tool-option .size-controls button:hover:not([disabled]){color:#3b82f6}.topbar-desktop .tool-option .size-controls button[disabled]{opacity:.3}.topbar-desktop .tool-option .size-controls .size-val{font-size:12px;font-weight:700;min-width:20px;text-align:center}.topbar-desktop .tool-option .size-controls .format-btn{background:none;border:none;border-radius:4px;padding:4px;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#64748b;transition:all .2s}.topbar-desktop .tool-option .size-controls .format-btn:hover{background:#f1f5f9;color:#1e293b}.topbar-desktop .tool-option .size-controls .format-btn.active{color:#3b82f6;background:#eff6ff}.topbar-desktop .tool-option .size-controls .format-btn--text{font-family:serif;font-size:16px}.topbar-desktop .tool-option .size-controls .format-btn--text span{display:block;width:18px;text-align:center}.topbar-desktop .tool-option .size-controls .format-btn svg-icon{font-size:18px}.topbar-desktop .tool-option .size-controls .color-palette{display:flex;align-items:center;grid-gap:6px;gap:6px;margin-left:8px}.topbar-desktop .tool-option .size-controls .color-palette .color-dot{width:16px;height:16px;border-radius:50%;cursor:pointer;border:2px solid #e2e8f0;transition:transform .2s}.topbar-desktop .tool-option .size-controls .color-palette .color-dot:hover{transform:scale(1.2)}.topbar-desktop .tool-option .size-controls .color-palette .color-dot.active{border-color:#3b82f6;transform:scale(1.1)}.topbar-desktop .tool-option .size-controls .color-palette .color-dot.blue{background:#0000FF}.topbar-desktop .tool-option .size-controls .color-palette .color-dot.red{background:#FF0000}.topbar-desktop .tool-option .size-controls .color-palette .color-dot.black{background:#000000}.topbar-desktop .tool-option .size-controls .color-palette .color-dot.green{background:#008000}.topbar-desktop__divider{width:1px;height:24px;background:#e2e8f0;margin:0 4px}.topbar-desktop__divider--small{height:16px;opacity:.6}.topbar-desktop .save-btn{background:#10b981;color:#fff;border:none;padding:8px 18px;border-radius:8px;font-weight:600;display:flex;align-items:center;grid-gap:8px;gap:8px;cursor:pointer;box-shadow:0 2px 4px #10b98133;margin-left:20px}.topbar-desktop .save-btn:hover{background:#059669}.topbar-pager,.topbar-zoom{display:flex;align-items:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:2px 6px;grid-gap:8px;gap:8px;height:38px}.topbar-pager__btn,.topbar-zoom__btn{background:transparent;border:none;padding:6px;cursor:pointer;color:#64748b;display:flex;align-items:center;border-radius:4px;transition:all .2s}.topbar-pager__btn:hover:not([disabled]),.topbar-zoom__btn:hover:not([disabled]){background:#f1f5f9;color:#3b82f6}.topbar-pager__btn[disabled],.topbar-zoom__btn[disabled]{opacity:.3;cursor:not-allowed}.topbar-pager__btn svg-icon,.topbar-zoom__btn svg-icon{font-size:16px}.topbar-pager__info,.topbar-pager__val,.topbar-zoom__info,.topbar-zoom__val{font-size:13px;font-weight:700;color:#475569;min-width:45px;text-align:center;-webkit-user-select:none;user-select:none}.topbar-zoom .fit-btn{font-size:11px;font-weight:700;text-transform:uppercase;color:#3b82f6;background:transparent;border:none;padding:4px 10px;cursor:pointer;letter-spacing:.5px}.topbar-zoom .fit-btn:hover{color:#2563eb;text-decoration:underline}.viewer-container{flex:1;overflow:auto!important;position:relative;padding:40px 20px;background:#cbd5e1;scrollbar-width:thin;-webkit-overflow-scrolling:touch;touch-action:auto;text-align:center}.page-container{position:relative;display:inline-block;margin-bottom:30px;background:#fff;box-shadow:0 10px 30px #00000026;text-align:left}.page-container.single-page{margin-bottom:0}.pdf-canvas{display:block}.annot-canvas{position:absolute;top:0;left:0;z-index:10;touch-action:auto;pointer-events:none}.annot-canvas.tools-active{pointer-events:auto;touch-action:none!important;-webkit-touch-callout:none!important;-webkit-user-select:none!important;user-select:none!important}.text-box{position:absolute;pointer-events:auto;border-radius:2px;border:1.5px dashed transparent;background:transparent;display:flex;flex-direction:column;z-index:20;min-width:30px;min-height:20px;box-sizing:border-box;cursor:move;padding:3px;overflow:visible}.text-box:hover{border-color:#93c5fd}.text-box.active{border:2px dashed #3b82f6;background:transparent}.text-box textarea{width:100%;height:100%;border:none;background:transparent;padding:0 3px;resize:none;outline:none;font-family:inherit;font-size:inherit;font-weight:inherit;font-style:inherit;text-align:inherit;color:inherit;overflow:hidden;display:block;line-height:inherit;letter-spacing:inherit;box-sizing:border-box;cursor:text}.text-box .tb-handle{position:absolute;background:#1a73e8;border:2px solid #fff;border-radius:50%;cursor:ew-resize;z-index:27;display:none;box-shadow:0 1px 3px #00000040}.text-box .tb-handle--left{width:12px;height:12px;left:-6px;top:50%;transform:translateY(-50%)}.text-box .tb-handle--right{width:12px;height:12px;right:-6px;top:50%;transform:translateY(-50%)}.text-box .tb-handle--br{width:14px;height:14px;right:-7px;bottom:-7px;border-radius:3px;cursor:se-resize;background:#3b82f6}.text-box.active .tb-handle{display:block}.tb-floating-bar{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translate(-50%);display:flex;align-items:center;grid-gap:2px;gap:2px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 4px 16px #00000024;padding:4px 8px;white-space:nowrap;z-index:200;cursor:default;pointer-events:all}.tb-floating-bar.tb-bar--below{bottom:auto;top:calc(100% + 6px)}.tb-bar-btn{display:flex;align-items:center;justify-content:center;width:28px;height:28px;border:none;border-radius:6px;background:transparent;color:#475569;font-size:14px;cursor:pointer;padding:0;transition:background .12s;flex-shrink:0}.tb-bar-btn:hover:not(:disabled){background:#f1f5f9}.tb-bar-btn:disabled{opacity:.35;cursor:not-allowed}.tb-bar-btn--active{background:#dbeafe;color:#2563eb}.tb-bar-btn--italic{font-style:italic}.tb-bar-btn--delete{color:#ef4444}.tb-bar-btn--delete:hover{background:#fee2e2}.tb-bar-btn b{font-size:15px;font-weight:700;line-height:1}.tb-bar-btn i{font-size:15px;font-style:italic;line-height:1}.tb-bar-btn svg-icon{font-size:15px}.tb-bar-btn svg{display:block}.tb-bar-sep{width:1px;height:20px;background:#e2e8f0;margin:0 3px;flex-shrink:0}.tb-bar-val{min-width:24px;text-align:center;font-size:13px;font-weight:600;color:#334155}.tb-bar-select{height:28px;padding:0 6px;border:1px solid #e2e8f0;border-radius:6px;background:#f8fafc;color:#334155;font-size:12px;cursor:pointer;outline:none;max-width:130px;-webkit-user-select:auto;user-select:auto;touch-action:auto}.tb-bar-select:focus{border-color:#3b82f6}.tb-bar-input{width:44px;height:28px;padding:0 4px;border:1px solid #e2e8f0;border-radius:6px;background:#f8fafc;color:#334155;font-size:12px;text-align:center;outline:none;-webkit-user-select:text;user-select:text;touch-action:auto;cursor:text}.tb-bar-input:focus{border-color:#3b82f6;background:#fff}.tb-bar-input--rot{width:36px}.tb-bar-input--ls{width:40px}.tb-bar-input::-webkit-outer-spin-button,.tb-bar-input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}.tb-bar-input{-moz-appearance:textfield}.tb-bar-rot-icon{font-size:11px;color:#94a3b8;margin-left:-2px}.tb-bar-label-icon{font-size:14px;color:#94a3b8;margin-right:2px}.tb-bar-btn--step{width:24px}.tb-bar-btn--step svg{opacity:.7}.tb-bar-btn--step:hover:not(:disabled) svg{opacity:1}.tb-bar-lbl{display:flex;align-items:center;font-size:11px;font-weight:700;color:#64748b;letter-spacing:.5px;padding:0 2px;flex-shrink:0}.tb-bar-lbl svg{display:block;color:#64748b}.tb-ls-wrap{position:relative;flex-shrink:0}.tb-ls-trigger{display:flex;align-items:center;grid-gap:3px;gap:3px;height:28px;padding:0 7px;border:1.5px solid #cbd5e1;border-radius:6px;background:#fff;color:#334155;font-size:13px;font-weight:600;cursor:pointer;white-space:nowrap}.tb-ls-trigger:hover{border-color:#94a3b8}.tb-ls-trigger svg{color:#94a3b8;flex-shrink:0}.tb-ls-drop{position:absolute;top:calc(100% + 4px);left:50%;transform:translate(-50%);background:#3d4556;border-radius:12px;padding:6px 0;min-width:90px;box-shadow:0 6px 24px #00000047;z-index:400}.tb-ls-opt{display:flex;align-items:center;justify-content:center;grid-gap:4px;gap:4px;width:100%;padding:7px 16px;background:none;border:none;color:#f1f5f9;font-size:14px;font-weight:500;cursor:pointer;border-radius:8px;margin:0 4px;width:calc(100% - 8px);box-sizing:border-box}.tb-ls-opt:hover{background:rgba(255,255,255,.12)}.tb-ls-opt--checked{font-weight:700}.tb-ls-opt svg-icon{font-size:14px;color:#f1f5f9;flex-shrink:0}.tb-ls-spacer{width:14px;flex-shrink:0}.tb-bar-stepper{display:flex;align-items:center;height:28px;border:1.5px solid #cbd5e1;border-radius:6px;overflow:hidden;background:#fff;flex-shrink:0}.tb-bar-stepper-val{min-width:34px;padding:0 6px 0 8px;font-size:13px;font-weight:600;color:#334155;line-height:28px;white-space:nowrap}.tb-bar-stepper-arrows{display:flex;flex-direction:column;border-left:1.5px solid #cbd5e1;height:100%}.tb-bar-stepper-up,.tb-bar-stepper-dn{flex:1;display:flex;align-items:center;justify-content:center;padding:0 4px;background:#f8fafc;border:none;cursor:pointer;color:#475569;line-height:1}.tb-bar-stepper-up:hover:not(:disabled),.tb-bar-stepper-dn:hover:not(:disabled){background:#e2e8f0;color:#1e293b}.tb-bar-stepper-up:disabled,.tb-bar-stepper-dn:disabled{opacity:.35;cursor:default}.tb-bar-stepper-up svg,.tb-bar-stepper-dn svg{display:block}.tb-bar-stepper-up{border-bottom:1px solid #e2e8f0}.tb-bar-color{position:relative;width:24px;height:24px;border-radius:5px;border:2px solid #fff;box-shadow:0 0 0 1px #e2e8f0;cursor:pointer;overflow:hidden;flex-shrink:0}.tb-bar-color input[type=color]{position:absolute;inset:-4px;width:calc(100% + 8px);height:calc(100% + 8px);opacity:0;cursor:pointer;border:none;padding:0}.image-stamp,.signature-stamp{position:absolute;pointer-events:auto;cursor:move;border:1px dashed transparent;z-index:20;touch-action:none}.image-stamp:hover,.signature-stamp:hover{border-color:#3b82f6}.image-stamp:hover .remove-btn,.signature-stamp:hover .remove-btn{opacity:1}.image-stamp img,.signature-stamp img{width:100%;height:100%;display:block;-webkit-user-select:none;user-select:none;pointer-events:none}.image-stamp.mark-stamp-active{outline:2px solid #3b82f6;outline-offset:2px;border-color:#3b82f6}.image-stamp.mark-stamp-active .resize-handle{opacity:1}.image-stamp.mark-stamp-active .remove-btn{opacity:1}.image-stamp .mark-options-bar{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translate(-50%);background:#1e293b;border:1px solid #334155;border-radius:8px;display:flex;align-items:center;grid-gap:1px;gap:1px;padding:3px 5px;z-index:50;white-space:nowrap;box-shadow:0 4px 14px #00000073;pointer-events:auto}.image-stamp .mark-options-bar .pff-opt-btn{width:24px;height:24px;border:none;background:transparent;color:#e2e8f0;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;padding:0;flex-shrink:0}.image-stamp .mark-options-bar .pff-opt-btn:hover{background:rgba(255,255,255,.1)}.image-stamp .mark-options-bar .pff-opt-btn.pff-opt-delete{color:#f87171}.image-stamp .mark-options-bar .pff-opt-btn.pff-opt-delete:hover{background:rgba(239,68,68,.2)}.image-stamp .mark-options-bar .pff-opt-btn[disabled]{opacity:.3;cursor:not-allowed;pointer-events:none}.image-stamp .mark-options-bar .pff-opt-val{font-size:11px;color:#e2e8f0;min-width:22px;text-align:center;font-weight:600;line-height:1}.image-stamp .mark-options-bar .pff-opt-label{font-size:11px;color:#94a3b8;margin:0 2px;display:flex;align-items:center}.image-stamp .mark-options-bar .pff-opt-label svg-icon{font-size:13px}.image-stamp .mark-options-bar .pff-opt-sep{width:1px;height:16px;background:#334155;margin:0 3px;flex-shrink:0}.shape-stamp{position:absolute;pointer-events:auto;cursor:move;border:1px dashed transparent;z-index:20;touch-action:none;overflow:visible}.shape-stamp svg{display:block;width:100%;height:100%;overflow:visible;pointer-events:none;-webkit-user-select:none;user-select:none}.shape-stamp:hover{border-color:#3b82f699}.shape-stamp:hover .remove-btn{opacity:1}.shape-stamp:hover .resize-handle{opacity:1}.signature-stamp img{mix-blend-mode:multiply}.signature-stamp .digital-id-label{position:absolute;left:100%;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;grid-gap:0;gap:0;pointer-events:none;white-space:nowrap;margin-left:6px}.signature-stamp .digital-id-label span{font-size:8px;color:#555;font-family:\"Courier New\",monospace;letter-spacing:.3px;line-height:1.4}.signature-stamp .remove-btn{position:absolute;top:-10px;left:-10px;width:20px;height:20px;background:#ef4444;color:#fff;border:none;border-radius:50%;font-size:10px;display:flex;align-items:center;justify-content:center;cursor:pointer;opacity:0;transition:opacity .2s;z-index:26}.pdf-form-field{position:absolute;pointer-events:auto;cursor:move;box-sizing:border-box;touch-action:none;z-index:20}.pdf-form-field.pff-mark{border:1.5px solid #3b82f6;border-radius:3px;background:transparent;min-width:10px;min-height:10px}.pdf-form-field.pff-text{border:1.5px solid #3b82f6;border-radius:3px;background:rgba(219,234,254,.25);min-width:40px;min-height:14px}.pdf-form-field.pff-checkbox{border:1.5px solid #3b82f6;border-radius:3px;background:rgba(219,234,254,.2);min-width:14px;min-height:14px}.pdf-form-field.pff-radio{border:1.5px solid #3b82f6;border-radius:50%;background:rgba(219,234,254,.2);min-width:14px;min-height:14px}.pdf-form-field:hover{border-color:#1d4ed8}.pdf-form-field:hover .remove-btn{opacity:1}.pdf-form-field .pff-inner{width:100%;height:100%;display:flex;align-items:center;justify-content:center;pointer-events:none}.pdf-form-field .pff-text-hint{font-size:10px;color:#3b82f6;font-weight:600;opacity:.8;-webkit-user-select:none;user-select:none}.pdf-form-field .remove-btn{position:absolute;top:-8px;right:-8px;width:16px;height:16px;background:#ef4444;color:#fff;border:none;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:10px;opacity:0;transition:opacity .15s;z-index:30;pointer-events:auto}.pdf-form-field .resize-handle{opacity:0}.pdf-form-field:hover .resize-handle{opacity:1}.pdf-form-field.pff-no-border{border-color:transparent!important;background:rgba(219,234,254,.08)}.pdf-form-field.pff-active{outline:2px solid #3b82f6;outline-offset:1px}.pdf-form-field.pff-active .pff-resize-handle{opacity:1}.pdf-form-field:hover .pff-resize-handle{opacity:1}.pdf-form-field .pff-resize-handle{position:absolute;width:8px;height:8px;background:#3b82f6;border:1.5px solid #fff;border-radius:50%;z-index:25;touch-action:none;opacity:0;transition:opacity .15s}.pdf-form-field .pff-resize-handle.rh-nw{top:-4px;left:-4px;cursor:nw-resize}.pdf-form-field .pff-resize-handle.rh-n{top:-4px;left:calc(50% - 4px);cursor:n-resize}.pdf-form-field .pff-resize-handle.rh-ne{top:-4px;right:-4px;cursor:ne-resize}.pdf-form-field .pff-resize-handle.rh-e{top:calc(50% - 4px);right:-4px;cursor:e-resize}.pdf-form-field .pff-resize-handle.rh-se{bottom:-4px;right:-4px;cursor:se-resize}.pdf-form-field .pff-resize-handle.rh-s{bottom:-4px;left:calc(50% - 4px);cursor:s-resize}.pdf-form-field .pff-resize-handle.rh-sw{bottom:-4px;left:-4px;cursor:sw-resize}.pdf-form-field .pff-resize-handle.rh-w{top:calc(50% - 4px);left:-4px;cursor:w-resize}.pdf-form-field .pff-options-bar{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translate(-50%);background:#1e293b;border:1px solid #334155;border-radius:8px;display:flex;align-items:center;grid-gap:1px;gap:1px;padding:3px 5px;z-index:50;white-space:nowrap;box-shadow:0 4px 14px #00000073;pointer-events:auto}.pdf-form-field .pff-options-bar .pff-opt-btn{width:24px;height:24px;border:none;background:transparent;color:#e2e8f0;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;padding:0;flex-shrink:0}.pdf-form-field .pff-options-bar .pff-opt-btn:hover{background:rgba(255,255,255,.1)}.pdf-form-field .pff-options-bar .pff-opt-btn.pff-opt-active{background:rgba(59,130,246,.3);color:#60a5fa}.pdf-form-field .pff-options-bar .pff-opt-btn.pff-opt-delete{color:#f87171}.pdf-form-field .pff-options-bar .pff-opt-btn.pff-opt-delete:hover{background:rgba(239,68,68,.2)}.pdf-form-field .pff-options-bar .pff-opt-btn[disabled]{opacity:.3;cursor:not-allowed;pointer-events:none}.pdf-form-field .pff-options-bar .pff-opt-val{font-size:11px;color:#e2e8f0;min-width:22px;text-align:center;font-weight:600;line-height:1}.pdf-form-field .pff-options-bar .pff-opt-label{font-size:11px;color:#94a3b8;margin:0 2px;font-style:italic;font-weight:700;display:flex;align-items:center}.pdf-form-field .pff-options-bar .pff-opt-label svg-icon{font-size:13px}.pdf-form-field .pff-options-bar .pff-opt-sep{width:1px;height:16px;background:#334155;margin:0 3px;flex-shrink:0}.date-stamp{position:absolute;pointer-events:auto;cursor:move;padding:4px 8px;background:rgba(255,255,255,.8);border:1px dashed #ccc;border-radius:4px;white-space:nowrap;font-family:\"THSarabunNew\",sans-serif;z-index:20;touch-action:none}.date-stamp:hover{border-color:#3b82f6}.date-stamp:hover .remove-btn{opacity:1}.date-stamp .remove-btn{position:absolute;top:-8px;right:-8px;width:16px;height:16px;background:#ef4444;color:#fff;border:none;border-radius:50%;font-size:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;opacity:0;transition:opacity .2s}.resize-handle{position:absolute;width:10px;height:10px;background:#3b82f6;border:1px solid #fff;border-radius:50%;z-index:22;touch-action:none;display:none}.resize-handle.rh-nw{top:-5px;left:-5px;cursor:nw-resize}.resize-handle.rh-n{top:-5px;left:calc(50% - 5px);cursor:n-resize}.resize-handle.rh-ne{top:-5px;right:-5px;cursor:ne-resize}.resize-handle.rh-e{top:calc(50% - 5px);right:-5px;cursor:e-resize}.resize-handle.rh-se{bottom:-5px;right:-5px;cursor:se-resize}.resize-handle.rh-s{bottom:-5px;left:calc(50% - 5px);cursor:s-resize}.resize-handle.rh-sw{bottom:-5px;left:-5px;cursor:sw-resize}.resize-handle.rh-w{top:calc(50% - 5px);left:-5px;cursor:w-resize}.image-stamp:hover .resize-handle,.signature-stamp:hover .resize-handle,.shape-stamp:hover .resize-handle{display:block}@media (max-width: 991px){.topbar-desktop__tools{display:none}}@media (max-width: 767px){.annotator-layout{flex-direction:column}.sidebar{width:100%;height:auto;max-height:140px;min-width:0;order:2;flex-direction:row;flex-wrap:wrap;overflow-x:auto;overflow-y:auto;padding:8px 12px;grid-gap:8px;gap:8px;scrollbar-width:none;-ms-overflow-style:none;justify-content:center;align-items:flex-start}.sidebar::-webkit-scrollbar{display:none}.sidebar__section{margin-bottom:0;flex-shrink:0;display:flex;flex-direction:row;justify-content:center;align-items:center}.sidebar__section--nav,.sidebar__section--save,.sidebar__section .sidebar__title{display:none}.sidebar__row{margin-bottom:0;grid-gap:6px;gap:6px;display:flex;flex-wrap:wrap;justify-content:center}.sidebar__btn{width:48px;height:48px;flex:none;font-size:9px;padding:4px}.sidebar__btn svg-icon{font-size:20px}.sidebar__btn span{display:none}.topbar-desktop{display:flex;padding:8px 12px}.topbar-desktop .save-btn,.topbar-desktop .doc-title{display:none}.topbar-desktop .topbar-desktop__left{display:none}.topbar-desktop .topbar-desktop__center{margin:0 auto}.viewer{padding:10px}}.mobile-pager{display:none}@media (max-width: 767px){.mobile-pager{display:flex;position:absolute;top:60px;right:16px;z-index:10;background:rgba(0,0,0,.6);color:#fff;padding:4px 12px;border-radius:20px;font-size:12px;backdrop-filter:blur(4px)}}.loading-overlay{position:fixed;inset:0;z-index:20003;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6);backdrop-filter:blur(4px)}.loading-overlay .loading-content{background:#fff;padding:32px 48px;border-radius:16px;text-align:center}.loading-overlay .loading-content ion-spinner{--color: #3b82f6;width:48px;height:48px}.loading-overlay .loading-content .loading-msg{margin-top:16px;font-size:14px;color:#334155}.loading-overlay .loading-content--progress{min-width:300px;padding:28px 32px}.loading-overlay .loading-content--progress .save-progress-icon{display:flex;align-items:center;justify-content:center;grid-gap:10px;gap:10px;margin-bottom:16px}.loading-overlay .loading-content--progress .save-progress-icon svg-icon{font-size:36px;color:#3b82f6}.loading-overlay .loading-content--progress .save-progress-icon .save-progress-pct{font-size:32px;font-weight:800;color:#1e293b;letter-spacing:-1px;line-height:1;min-width:64px;text-align:left}.loading-overlay .loading-content--progress .save-progress-bar-track{width:100%;height:10px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin-bottom:14px}.loading-overlay .loading-content--progress .save-progress-bar-track .save-progress-bar-fill{height:100%;background:linear-gradient(90deg,#3b82f6 0%,#06b6d4 100%);border-radius:99px;transition:width .3s ease,background .5s ease}.loading-overlay .loading-content--progress .save-progress-bar-track .save-progress-bar-fill--preview{background:linear-gradient(90deg,#06b6d4 0%,#22c55e 100%)}.loading-overlay .loading-content--progress .save-progress-bar-track .save-progress-bar-fill--serializing{background:linear-gradient(90deg,#3b82f6 0%,#8b5cf6 50%,#3b82f6 100%);background-size:200% 100%;animation:shimmerBar 1.5s linear infinite}.loading-overlay .loading-content--progress .save-progress-phases{display:flex;justify-content:space-between;grid-gap:8px;gap:8px;margin-bottom:12px}.loading-overlay .loading-content--progress .save-progress-phases span{display:flex;align-items:center;grid-gap:4px;gap:4px;font-size:11.5px;color:#94a3b8;transition:color .3s}.loading-overlay .loading-content--progress .save-progress-phases span svg-icon{font-size:13px}.loading-overlay .loading-content--progress .save-progress-phases span.active{color:#3b82f6;font-weight:600}.loading-overlay .loading-content--progress .loading-msg{font-size:13px;color:#64748b;margin-top:4px}.signature-modal,.signature-picker-modal{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center}.signature-modal__backdrop,.signature-picker-modal__backdrop{position:absolute;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(4px)}.signature-modal__content,.signature-picker-modal__content{position:relative;background:#fff;padding:28px 36px;border-radius:20px;box-shadow:0 24px 60px #00000040;text-align:center;width:95%;max-width:500px}@media (max-width: 500px){.signature-modal__content,.signature-picker-modal__content{padding:20px}}.signature-modal__content h3,.signature-picker-modal__content h3{margin:0 0 8px;font-size:22px;font-weight:600;color:#1e293b}.signature-modal__hint,.signature-picker-modal__hint{margin:0 0 20px;font-size:14px;color:#64748b}.signature-modal__canvas,.signature-picker-modal__canvas{display:block;width:100%;height:auto;aspect-ratio:2/1;border:2px solid #e2e8f0;border-radius:12px;background:#fff;cursor:crosshair;touch-action:none}.signature-modal__canvas--preview,.signature-picker-modal__canvas--preview{cursor:default;pointer-events:none}.signature-modal__type-opts,.signature-picker-modal__type-opts{margin-bottom:16px}.signature-modal__type-top,.signature-picker-modal__type-top{display:flex;align-items:center;grid-gap:12px;gap:12px;margin-bottom:12px}.signature-modal__type-input,.signature-picker-modal__type-input{flex:1;padding:10px 14px;font-size:16px;font-family:\"THSarabunNew\",sans-serif;border:2px solid #e2e8f0;border-radius:10px;outline:none;box-sizing:border-box;text-align:center}.signature-modal__type-input:focus,.signature-picker-modal__type-input:focus{border-color:#3b82f6}.signature-modal__type-color,.signature-picker-modal__type-color{display:flex;align-items:center;grid-gap:6px;gap:6px;flex-shrink:0}.signature-modal__type-fonts,.signature-picker-modal__type-fonts{display:flex;grid-gap:8px;gap:8px;overflow-x:auto;padding-bottom:4px}.signature-modal__actions,.signature-picker-modal__actions{display:flex;grid-gap:12px;gap:12px;justify-content:center;margin-top:24px;flex-wrap:wrap}.signature-modal__pen-options,.signature-picker-modal__pen-options{display:flex;align-items:center;justify-content:center;grid-gap:20px;gap:20px;margin-bottom:16px;padding:8px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0}.signature-modal__pen-options .pen-option-group,.signature-picker-modal__pen-options .pen-option-group{display:flex;align-items:center;grid-gap:8px;gap:8px}.signature-modal__pen-options .pen-option-label,.signature-picker-modal__pen-options .pen-option-label{font-size:13px;color:#64748b;font-weight:500}.signature-modal__pen-options .pen-size-btn,.signature-picker-modal__pen-options .pen-size-btn{width:28px;height:28px;border:1px solid #e2e8f0;background:#fff;border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .15s}.signature-modal__pen-options .pen-size-btn:hover:not(:disabled),.signature-picker-modal__pen-options .pen-size-btn:hover:not(:disabled){background:#e2e8f0}.signature-modal__pen-options .pen-size-btn:disabled,.signature-picker-modal__pen-options .pen-size-btn:disabled{opacity:.4;cursor:not-allowed}.signature-modal__pen-options .pen-size-btn svg-icon,.signature-picker-modal__pen-options .pen-size-btn svg-icon{font-size:14px}.signature-modal__pen-options .pen-size-val,.signature-picker-modal__pen-options .pen-size-val{font-size:13px;font-weight:600;min-width:28px;text-align:center;color:#334155}.sig-mode-tabs{display:flex;grid-gap:4px;gap:4px;margin-bottom:12px;background:#f1f5f9;border-radius:10px;padding:4px}.sig-mode-tab{flex:1;display:flex;align-items:center;justify-content:center;grid-gap:6px;gap:6px;padding:8px 12px;border:none;border-radius:8px;background:transparent;color:#64748b;font-size:14px;font-weight:500;cursor:pointer;transition:all .15s}.sig-mode-tab svg-icon{font-size:16px}.sig-mode-tab.active{background:#fff;color:#1e293b;box-shadow:0 1px 3px #0000001a}.type-font-btn{flex-shrink:0;padding:8px 18px;border:2px solid #e2e8f0;border-radius:10px;background:#fff;font-size:18px;line-height:1.3;cursor:pointer;transition:all .15s;color:#1e293b;white-space:nowrap}.type-font-btn:hover{border-color:#93c5fd;background:#f0f9ff}.type-font-btn.active{border-color:#3b82f6;background:#eff6ff;color:#1d4ed8}.signature-picker-modal__list{flex:1;overflow-y:auto;max-height:40vh;padding:4px 0;margin:16px 0}.signature-item{display:flex;align-items:center;grid-gap:14px;gap:14px;padding:12px 14px;margin-bottom:8px;border:2px solid #e2e8f0;border-radius:12px;cursor:pointer;transition:all .15s}.signature-item:hover{border-color:#3b82f6;background:#f8fafc;transform:translate(4px)}.signature-item img{width:100px;height:50px;object-fit:contain;background:#fff;border-radius:6px;border:1px solid #e2e8f0}.signature-item__info{flex:1;display:flex;flex-direction:column;grid-gap:4px;gap:4px;text-align:left}.signature-item__name{font-size:14px;font-weight:500;color:#1e293b}.signature-item__badge{display:inline-block;padding:2px 8px;font-size:11px;font-weight:600;color:#3b82f6;background:#eff6ff;border-radius:10px;width:-moz-fit-content;width:fit-content}.signature-item__actions{display:flex;grid-gap:6px;gap:6px}.signature-item__btn{width:32px;height:32px;border:none;border-radius:8px;background:#f1f5f9;color:#64748b;display:flex;align-items:center;justify-content:center}.signature-item__btn:hover{background:#e2e8f0;color:#334155}.signature-item__btn.active{background:#fef3c7;color:#f59e0b}.signature-item__btn--delete:hover{background:#fee2e2;color:#ef4444}.hint{background:#f8fafc;padding:10px 20px;font-size:11px;color:#64748b;border-top:1px solid #e2e8f0}.preview-overlay{position:fixed;top:0;left:0;width:100%;height:100dvh;background:rgba(0,0,0,.7);backdrop-filter:blur(8px);z-index:20001;display:flex;flex-direction:column;overflow:hidden;animation:fadeIn .3s ease-out}.preview-overlay .preview-header{flex-shrink:0;position:relative;background:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 12px #0000001f;z-index:20002}.preview-overlay .preview-header .preview-title{font-size:1.1rem;font-weight:700;color:#1f2937;display:flex;align-items:center;grid-gap:8px;gap:8px}.preview-overlay .preview-header .preview-title:before{content:\"\";display:inline-block;width:4px;height:20px;background:linear-gradient(180deg,#22c55e,#16a34a);border-radius:2px}.preview-overlay .preview-header .preview-actions{display:flex;grid-gap:10px;gap:10px;align-items:center}.preview-overlay .preview-header .preview-actions ion-button[fill=clear]{--color: #64748b;font-weight:500;font-size:14px}.preview-overlay .preview-header .preview-actions ion-button[color=success]{--background: linear-gradient(135deg, #22c55e 0%, #15803d 100%);--background-activated: #15803d;--background-hover: #16a34a;--color: #fff;--border-radius: 10px;--padding-start: 22px;--padding-end: 22px;--padding-top: 12px;--padding-bottom: 12px;--box-shadow: 0 4px 16px rgba(34, 197, 94, .45);font-weight:700;font-size:15px;letter-spacing:.3px;animation:confirmPulse 2.4s ease-in-out infinite}.preview-overlay .preview-scroll-area{flex:1;overflow-y:auto;overflow-x:hidden}.preview-overlay .preview-body{min-height:100%;padding:20px;display:flex;flex-direction:column;align-items:center}.preview-overlay .preview-body .preview-filter-bar{display:flex;align-items:center;grid-gap:8px;gap:8px;background:rgba(255,193,7,.15);border:1px solid rgba(255,193,7,.4);border-radius:8px;padding:8px 14px;margin-bottom:12px;width:100%;max-width:1100px;color:#ffe082;font-size:13px}.preview-overlay .preview-body .preview-filter-bar svg-icon{font-size:18px;flex-shrink:0}.preview-overlay .preview-body .preview-filter-bar span{flex:1}.preview-overlay .preview-body .preview-filter-bar ion-button{--color: #ffe082;--border-color: rgba(255, 193, 7, .5);border:1px solid rgba(255,193,7,.5);border-radius:6px;flex-shrink:0}.preview-overlay .preview-body iframe{width:100%;height:100%;max-width:1100px;background:white;border-radius:8px;box-shadow:0 10px 25px #0000004d}.preview-overlay .preview-body .preview-pages{display:flex;flex-direction:column;grid-gap:16px;gap:16px;max-width:1100px;width:100%}.preview-overlay .preview-body .preview-page-img{width:100%;background:white;border-radius:8px;box-shadow:0 4px 12px #00000026}.preview-overlay .preview-body .preview-loading{display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;grid-gap:16px;gap:16px}.preview-overlay .preview-body .preview-loading ion-spinner{--color: white;width:48px;height:48px}.preview-overlay .preview-body .preview-loading p{font-size:16px;margin:0}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes shimmerBar{0%{background-position:200% 0}to{background-position:-200% 0}}@keyframes confirmPulse{0%,to{box-shadow:0 4px 16px #22c55e73}50%{box-shadow:0 4px 24px #22c55ebf,0 0 0 4px #22c55e26}}::ng-deep .textLayer{position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;opacity:1;line-height:1;z-index:5;--scale-factor: 1}::ng-deep .textLayer>span,::ng-deep .textLayer>br{color:transparent!important;position:absolute;white-space:pre;cursor:text;transform-origin:0% 0%}::ng-deep .textLayer ::selection{background:rgba(59,130,246,.3);color:transparent!important}.annot-history-drawer,.user-guide-drawer{position:absolute;top:0;right:0;bottom:0;left:0;z-index:999;pointer-events:none}.annot-history-drawer.open,.user-guide-drawer.open{pointer-events:auto}.annot-history-drawer__backdrop,.user-guide-drawer__backdrop{position:absolute;inset:0;background:rgba(0,0,0,0);transition:background .3s}.annot-history-drawer.open .annot-history-drawer__backdrop,.user-guide-drawer.open .annot-history-drawer__backdrop,.annot-history-drawer.open .user-guide-drawer__backdrop,.user-guide-drawer.open .user-guide-drawer__backdrop{background:rgba(0,0,0,.45)}.annot-history-drawer__panel,.user-guide-drawer__panel{position:absolute;top:0;right:0;bottom:0;width:min(340px,92vw);background:#1e293b;border-left:1px solid rgba(255,255,255,.08);display:flex;flex-direction:column;transform:translate(100%);transition:transform .3s cubic-bezier(.4,0,.2,1);box-shadow:-6px 0 28px #00000059}.annot-history-drawer.open .annot-history-drawer__panel,.user-guide-drawer.open .annot-history-drawer__panel,.annot-history-drawer.open .user-guide-drawer__panel,.user-guide-drawer.open .user-guide-drawer__panel{transform:translate(0)}.annot-history-drawer__header,.user-guide-drawer__header{display:flex;align-items:center;justify-content:space-between;padding:14px 16px 12px;border-bottom:1px solid rgba(255,255,255,.07);font-size:14px;font-weight:700;color:#e8eaf6}.annot-history-drawer__header svg-icon,.user-guide-drawer__header svg-icon{margin-right:6px;color:#6c8ef5;vertical-align:-2px}.annot-history-drawer__header button,.user-guide-drawer__header button{background:none;border:none;color:#8892b0;cursor:pointer;font-size:20px;display:flex;align-items:center}.annot-history-drawer__header button:hover,.user-guide-drawer__header button:hover{color:#e8eaf6}.annot-history-drawer__loading,.user-guide-drawer__loading{display:flex;align-items:center;justify-content:center;padding:40px;color:#8892b0}.annot-history-drawer__loading ion-spinner,.user-guide-drawer__loading ion-spinner{--color: #6c8ef5}.annot-history-list{flex:1;overflow-y:auto;padding:6px 0;scrollbar-width:thin;scrollbar-color:#334155 #1e293b}.annot-history-list::-webkit-scrollbar{width:5px}.annot-history-list::-webkit-scrollbar-track{background:#1e293b}.annot-history-list::-webkit-scrollbar-thumb{background:#334155;border-radius:3px}.annot-history-entry{display:flex;align-items:flex-start;grid-gap:11px;gap:11px;padding:9px 14px;border-bottom:1px solid rgba(255,255,255,.04);transition:background .12s}.annot-history-entry:last-child{border-bottom:none}.annot-history-entry:hover{background:rgba(255,255,255,.03)}.annot-history-entry__icon{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:15px;background:rgba(108,142,245,.15);color:#6c8ef5}.annot-history-entry__icon.hi-sign{background:rgba(74,222,128,.15);color:#4ade80}.annot-history-entry__icon.hi-save{background:rgba(251,191,36,.15);color:#fbbf24}.annot-history-entry__icon.hi-page_delete{background:rgba(255,77,109,.15);color:#ff4d6d}.annot-history-entry__icon.hi-page_insert{background:rgba(94,234,212,.15);color:#5eead4}.annot-history-entry__icon.hi-upload{background:rgba(167,139,250,.15);color:#a78bfa}.annot-history-entry__icon.hi-draw{background:rgba(251,113,133,.15);color:#fb7185}.annot-history-entry__icon.hi-highlight{background:rgba(251,191,36,.15);color:#fbbf24}.annot-history-entry__icon.hi-text{background:rgba(147,197,253,.15);color:#93c5fd}.annot-history-entry__body{flex:1;min-width:0}.annot-history-entry__title{font-size:13px;font-weight:600;color:#e8eaf6;display:flex;align-items:center;grid-gap:6px;gap:6px}.annot-history-entry__page{font-size:11px;background:rgba(108,142,245,.15);color:#6c8ef5;padding:1px 6px;border-radius:10px;font-weight:400}.annot-history-entry__user{font-size:12px;color:#8892b0;margin-top:2px}.annot-history-entry__time{font-size:11px;color:#8892b08c;margin-top:1px}.annot-history-empty{display:flex;flex-direction:column;align-items:center;padding:56px 24px;color:#8892b0;grid-gap:10px;gap:10px}.annot-history-empty svg-icon{font-size:36px;opacity:.4}.annot-history-empty p{font-size:13px;margin:0}.custom-context-backdrop{position:fixed;inset:0;z-index:99998;cursor:pointer;touch-action:none}.custom-context-menu{position:fixed;z-index:99999;background:rgba(255,255,255,.85);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border:1px solid rgba(0,0,0,.1);border-radius:8px;box-shadow:0 4px 16px #00000026;padding:4px;min-width:220px;display:flex;flex-direction:column}.custom-context-menu .menu-btn{display:flex;align-items:center;grid-gap:8px;gap:8px;width:100%;padding:8px 12px;border:none;background:transparent;cursor:pointer;font-size:13px;color:#334155;border-radius:4px;text-align:left;transition:background .1s}.custom-context-menu .menu-btn svg-icon{font-size:16px;color:#64748b}.custom-context-menu .menu-btn:hover{background:#3b82f6;color:#fff}.custom-context-menu .menu-btn:hover svg-icon{color:#fff}.custom-context-menu .menu-btn.danger-btn:hover{background:#ef4444;color:#fff}.custom-context-menu .menu-btn.danger-btn:hover svg-icon{color:#fff}.custom-context-menu .menu-divider{height:1px;background:rgba(0,0,0,.08);margin:4px 0}.user-guide-content-area{flex:1;overflow-y:auto;padding:20px;background:#0f172a}.guide-view-mode{display:flex;flex-direction:column;grid-gap:24px;gap:24px}.guide-banner{display:flex;grid-gap:12px;gap:12px;background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.2);border-radius:8px;padding:12px 14px;color:#eff6ff;font-size:13px;line-height:1.5}.guide-banner svg-icon{font-size:24px;color:#60a5fa;flex-shrink:0}.guide-banner code{background:rgba(255,255,255,.1);padding:2px 6px;border-radius:4px;font-size:11px;color:#93c5fd}.guide-section__title{display:flex;align-items:center;grid-gap:8px;gap:8px;font-size:15px;font-weight:600;color:#f8fafc;margin:0 0 12px}.guide-section__title svg-icon{font-size:18px}.guide-list{display:flex;flex-direction:column;grid-gap:12px;gap:12px}.guide-item{display:flex;grid-gap:10px;gap:10px;align-items:flex-start;background:rgba(255,255,255,.03);padding:12px;border-radius:8px;border:1px solid rgba(255,255,255,.05)}.guide-item__icon{font-size:16px;color:#94a3b8;margin-top:2px;flex-shrink:0}.guide-item__text{font-size:13px;line-height:1.5;color:#cbd5e1}.guide-item__text strong{color:#f8fafc;font-weight:600}.guide-item__text code{background:rgba(0,0,0,.3);padding:2px 5px;border-radius:4px;font-size:11px;color:#cbd5e1;border:1px solid rgba(255,255,255,.1)}.guide-step{width:20px;height:20px;border-radius:50%;background:#334155;color:#fff;font-size:11px;font-weight:bold;display:flex;align-items:center;justify-content:center;flex-shrink:0}.guide-raw-content{white-space:pre-wrap;color:#94a3b8;font-size:13px;line-height:1.6;background:rgba(0,0,0,.2);padding:12px;border-radius:8px;border:1px solid rgba(255,255,255,.05)}.guide-edit-btn{width:100%;padding:10px;background:rgba(108,142,245,.1);color:#818cf8;border:1px solid rgba(129,140,248,.3);border-radius:8px;cursor:pointer;font-weight:500;transition:all .2s;display:flex;align-items:center;justify-content:center;grid-gap:8px;gap:8px}.guide-edit-btn:hover{background:rgba(108,142,245,.15);border-color:#818cf880}.guide-dot-demo{display:inline-block;width:10px;height:10px;background:#1a73e8;border:2px solid #fff;border-radius:50%;vertical-align:middle;box-shadow:0 1px 3px #0000004d}.guide-shortcuts-grid{display:grid;grid-template-columns:1fr 1fr;grid-gap:10px;gap:10px}.guide-shortcut-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:12px 14px;display:flex;flex-direction:column;grid-gap:6px;gap:6px}.guide-shortcut-card__keys{display:flex;align-items:center;grid-gap:4px;gap:4px}.guide-shortcut-card__keys kbd{background:#1e293b;border:1px solid #334155;border-bottom:2px solid #475569;border-radius:5px;padding:3px 7px;font-size:11px;font-family:monospace;color:#e2e8f0;line-height:1.4}.guide-shortcut-card__keys span{color:#64748b;font-size:12px}.guide-shortcut-card__label{font-size:12px;color:#94a3b8;line-height:1.3}.guide-protip{display:flex;grid-gap:12px;gap:12px;background:linear-gradient(135deg,rgba(251,191,36,.08) 0%,rgba(245,158,11,.05) 100%);border:1px solid rgba(251,191,36,.2);border-radius:10px;padding:14px}.guide-protip__icon svg-icon{font-size:22px;color:#fbbf24;flex-shrink:0}.guide-protip__title{font-size:13px;font-weight:700;color:#fde68a;margin-bottom:8px;letter-spacing:.3px}.guide-protip__list{margin:0;padding-left:16px;display:flex;flex-direction:column;grid-gap:6px;gap:6px}.guide-protip__list li{font-size:12.5px;color:#cbd5e1;line-height:1.5}.guide-protip__list li code{background:rgba(0,0,0,.25);padding:1px 5px;border-radius:4px;font-size:11px;color:#fde68a;border:1px solid rgba(251,191,36,.2)}.stamp-place-banner{display:flex;align-items:center;justify-content:space-between;padding:10px 20px;background:#1d4ed8;color:#fff;font-size:14px;font-weight:500;z-index:200;flex-shrink:0}.stamp-place-banner svg-icon{vertical-align:-2px;margin-right:6px}.stamp-place-banner button{display:flex;align-items:center;grid-gap:4px;gap:4px;padding:6px 12px;border:1px solid rgba(255,255,255,.4);border-radius:8px;background:transparent;color:#fff;font-size:13px;cursor:pointer}.stamp-place-banner button:hover{background:rgba(255,255,255,.15)}.stamp-place-mode{cursor:crosshair!important}.stamp-place-mode *{pointer-events:none}.stamp-ghost-img{position:absolute;pointer-events:none;opacity:.7;transform:translate(-50%,-50%);z-index:300;height:auto}.stamp-name-row{display:flex;align-items:center;grid-gap:5px;gap:5px;cursor:pointer;border-radius:5px;padding:2px 4px;margin:-2px -4px;transition:background .15s}.stamp-name-row:hover{background:#f1f5f9}.stamp-edit-icon{font-size:12px;color:#94a3b8;flex-shrink:0;opacity:0;transition:opacity .15s}.stamp-name-row:hover .stamp-edit-icon{opacity:1}.stamp-name-input{width:100%;padding:3px 8px;font-size:14px;font-weight:500;border:2px solid #3b82f6;border-radius:6px;outline:none;box-sizing:border-box;color:#1e293b}.stamp-gen-form{display:flex;flex-direction:column;grid-gap:12px;gap:12px;margin-bottom:20px}.stamp-gen-row{display:flex;flex-direction:column;grid-gap:4px;gap:4px;text-align:left}.stamp-gen-row label{font-size:12px;color:#64748b;font-weight:500}.stamp-gen-select,.stamp-gen-input{width:100%;padding:9px 12px;font-size:14px;border:1px solid #e2e8f0;border-radius:8px;outline:none;box-sizing:border-box;background:#f8fafc;color:#0f172a}.stamp-gen-select:focus,.stamp-gen-input:focus{border-color:#3b82f6;background:#fff}.stamp-gen-colors{display:flex;align-items:center;grid-gap:10px;gap:10px}.stamp-gen-colors span{font-size:13px;color:#64748b}.flip-tool-item{position:relative}.flip-panel{position:absolute;top:calc(100% + 6px);right:0;width:280px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 10px 30px #0000001f;z-index:1000;overflow:hidden}.flip-panel__header{background:#f8fafc;padding:10px 14px;font-size:13px;font-weight:600;color:#1e293b;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;grid-gap:6px;gap:6px}.flip-panel__close{margin-left:auto;background:none;border:none;cursor:pointer;font-size:15px;color:#64748b}.flip-panel__close:hover{color:#ef4444}.flip-panel__body{padding:12px 14px;display:flex;flex-direction:column;grid-gap:12px;gap:12px}.flip-scope{display:flex;grid-gap:6px;gap:6px}.flip-scope label{flex:1;display:flex;align-items:center;justify-content:center;grid-gap:4px;gap:4px;padding:6px 8px;font-size:11px;font-weight:500;color:#64748b;background:#f1f5f9;border:2px solid transparent;border-radius:6px;cursor:pointer;transition:all .15s}.flip-scope label.active{background:#eff6ff;border-color:#3b82f6;color:#1d4ed8}.flip-current-label{font-size:12px;color:#64748b;text-align:center}.flip-current-label strong{color:#3b82f6;font-size:14px}.flip-angle-btns{display:flex;grid-gap:6px;gap:6px}.flip-btn{flex:1;padding:8px 0;font-size:13px;font-weight:600;color:#475569;background:#f1f5f9;border:2px solid transparent;border-radius:6px;cursor:pointer;transition:all .15s}.flip-btn:hover{background:#e2e8f0}.flip-btn.active{background:#3b82f6;color:#fff;border-color:#2563eb}.flip-rotate-btns{display:flex;grid-gap:8px;gap:8px}.flip-action-btn{flex:1;display:flex;align-items:center;justify-content:center;grid-gap:4px;gap:4px;padding:8px 10px;font-size:12px;font-weight:500;color:#475569;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;transition:all .15s}.flip-action-btn:hover{background:#e2e8f0;color:#1e293b}.flip-action-btn svg-icon{font-size:16px}.wm-tool-item{position:relative}.wm-panel{position:absolute;top:calc(100% + 6px);right:0;width:320px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 10px 30px #0000001f;z-index:1000;display:flex;flex-direction:column;overflow:hidden}.wm-panel__header{background:#f8fafc;padding:12px 16px;font-size:14px;font-weight:600;color:#1e293b;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;grid-gap:8px;gap:8px}.wm-panel__close{margin-left:auto;background:none;border:none;cursor:pointer;font-size:16px;color:#64748b}.wm-panel__close:hover{color:#ef4444}.wm-panel__body{padding:12px 16px;display:flex;flex-direction:column;grid-gap:10px;gap:10px;max-height:60vh;overflow-y:auto}.wm-panel__footer{padding:10px 16px;background:#f8fafc;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;grid-gap:8px;gap:8px}.wm-row{display:flex;align-items:center;grid-gap:8px;gap:8px}.wm-row>label{font-size:12px;font-weight:500;color:#475569;min-width:70px;white-space:nowrap}.wm-section-title{font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;margin-top:6px;padding-bottom:4px;border-bottom:1px solid #e2e8f0}.wm-input{flex:1;border:1px solid #cbd5e1;border-radius:6px;padding:6px 10px;font-size:13px;color:#1e293b;background:#fff;outline:none}.wm-input:focus{border-color:#3b82f6;box-shadow:0 0 0 2px #3b82f61a}.wm-input--sm{max-width:70px}.wm-input--xs{max-width:55px}.wm-slider{flex:1;accent-color:#3b82f6;cursor:pointer}.wm-val{font-size:12px;font-weight:600;color:#3b82f6;min-width:36px;text-align:right}.wm-color-wrap{position:relative;width:36px;height:28px;border-radius:6px;overflow:hidden;cursor:pointer;border:2px solid #e2e8f0}.wm-color-wrap .wm-color-swatch{width:100%;height:100%}.wm-color-wrap input[type=color]{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%}.wm-radio-group{display:flex;grid-gap:12px;gap:12px}.wm-radio-group label{font-size:12px;color:#475569;display:flex;align-items:center;grid-gap:4px;gap:4px;cursor:pointer}.wm-radio-group label input[type=radio]{accent-color:#3b82f6}.wm-spacing-group{display:flex;align-items:center;grid-gap:6px;gap:6px}.wm-spacing-group span{font-size:12px;font-weight:600;color:#64748b}.wm-file-input{font-size:12px;color:#475569}.wm-img-preview{margin-top:6px;border:1px solid #e2e8f0;border-radius:6px;padding:4px;max-height:80px;overflow:hidden}.wm-img-preview img{max-width:100%;max-height:70px;object-fit:contain}.wm-btn{display:flex;align-items:center;grid-gap:4px;gap:4px;padding:6px 14px;border-radius:6px;border:none;cursor:pointer;font-size:13px;font-weight:500;transition:all .15s}.wm-btn--apply{background:#3b82f6;color:#fff}.wm-btn--apply:hover{background:#2563eb}.wm-btn--cancel{background:#f1f5f9;color:#64748b}.wm-btn--cancel:hover{background:#e2e8f0;color:#475569}.wm-btn svg-icon{font-size:16px}.wm-preview-overlay{position:absolute;inset:0;pointer-events:none;z-index:5;overflow:hidden}.wm-preview-content{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none}.wm-text-center{white-space:nowrap;font-weight:600;-webkit-user-select:none;user-select:none}.wm-text-tiled{position:absolute;inset:-200%;display:flex;flex-wrap:wrap;align-content:center;justify-content:center;grid-gap:40px 60px;gap:40px 60px;font-weight:600;-webkit-user-select:none;user-select:none;white-space:nowrap}.wm-preview-img{max-width:40%;max-height:40%;object-fit:contain}.pn-tool-item{position:relative}.pn-panel{position:absolute;top:calc(100% + 6px);right:0;width:300px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 10px 30px #0000001f;z-index:1000;overflow:hidden}.pn-panel__header{background:#f8fafc;padding:10px 14px;font-size:13px;font-weight:600;color:#1e293b;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;grid-gap:6px;gap:6px}.pn-panel__close{margin-left:auto;background:none;border:none;cursor:pointer;font-size:15px;color:#64748b}.pn-panel__close:hover{color:#ef4444}.pn-panel__body{padding:12px 14px;display:flex;flex-direction:column;grid-gap:10px;gap:10px}.pn-panel__footer{padding:10px 14px;background:#f8fafc;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;grid-gap:8px;gap:8px}.pn-section-title{font-size:11px;font-weight:600;color:#94a3b8;text-transform:uppercase;margin-top:2px}.pn-format-btns{display:flex;grid-gap:6px;gap:6px}.pn-format-btn{flex:1;padding:7px 10px;font-size:12px;font-weight:600;color:#475569;background:#f1f5f9;border:2px solid transparent;border-radius:8px;cursor:pointer;transition:all .15s;text-align:center}.pn-format-btn:hover{background:#e2e8f0}.pn-format-btn.active{background:#eff6ff;border-color:#3b82f6;color:#1d4ed8}.pn-pos-grid{display:grid;grid-template-columns:repeat(3,1fr);grid-gap:4px;gap:4px}.pn-pos-btn{display:flex;align-items:center;justify-content:center;grid-gap:2px;gap:2px;padding:5px 4px;font-size:10px;font-weight:500;color:#64748b;background:#f1f5f9;border:2px solid transparent;border-radius:6px;cursor:pointer;transition:all .15s}.pn-pos-btn:hover{background:#e2e8f0}.pn-pos-btn.active{background:#3b82f6;color:#fff;border-color:#2563eb}.pn-pos-btn svg-icon{font-size:12px}.pn-row{display:flex;align-items:center;grid-gap:8px;gap:8px}.pn-row>label{font-size:12px;font-weight:500;color:#475569;min-width:40px}.pn-checkbox{display:flex;align-items:center;grid-gap:6px;gap:6px;font-size:12px;color:#475569;cursor:pointer}.pn-checkbox input[type=checkbox]{accent-color:#3b82f6}.pn-input{flex:1;border:1px solid #cbd5e1;border-radius:6px;padding:5px 8px;font-size:12px;color:#1e293b;background:#fff;outline:none}.pn-input:focus{border-color:#3b82f6}.pn-input--sm{max-width:60px}.pn-preview-box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 12px;font-size:12px;color:#64748b;text-align:center}.pn-preview-box strong{font-weight:600}.pn-preview{pointer-events:none;z-index:6;font-weight:500}.deskew-panel{position:absolute;top:10px;left:50%;transform:translate(-50%);background:#fff;border:1px solid #e2e8f0;border-radius:8px;box-shadow:0 10px 25px #0000001a;z-index:1000;width:380px;max-width:calc(100% - 24px);display:flex;flex-direction:column;overflow:hidden}.deskew-panel__header{background:#f8fafc;padding:10px 16px;font-size:14px;font-weight:600;color:#1e293b;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;grid-gap:8px;gap:8px}.deskew-panel__body{padding:16px;display:flex;align-items:center;grid-gap:12px;gap:12px}.deskew-panel__footer{padding:10px 16px;background:#f8fafc;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center}.deskew-slider-container{flex:1;display:flex;flex-direction:column;align-items:center}.deskew-angle{font-size:14px;font-weight:600;margin-bottom:6px;color:#3b82f6}.deskew-slider{width:100%;accent-color:#3b82f6}.deskew-slider-ticks{width:100%;display:flex;justify-content:space-between;font-size:10px;color:#64748b;margin-top:4px}.page-container.deskew-mode{transition:transform .1s linear;box-shadow:0 0 0 3px #3b82f6,0 20px 40px #0003!important;z-index:10;pointer-events:none}.input-item.input-item--off{opacity:.5}\n"]
                },] }
    ];
    PdfAnnotatorModalComponent.ctorParameters = function () { return [
        { type: angular.ModalController },
        { type: i1.HttpClient },
        { type: i0.NgZone },
        { type: angular.ToastController },
        { type: angular.AlertController },
        { type: i0.ChangeDetectorRef },
        { type: platformBrowser.DomSanitizer },
        { type: PdfManagerService },
        { type: undefined, decorators: [{ type: i0.Optional }, { type: i0.Inject, args: [PDF_ANNOTATOR_CONFIG,] }] }
    ]; };
    PdfAnnotatorModalComponent.propDecorators = {
        pdfUrl: [{ type: i0.Input }],
        fileName: [{ type: i0.Input }],
        canManageGuide: [{ type: i0.Input }],
        pdfCanvases: [{ type: i0.ViewChildren, args: ['pdfCanvas',] }],
        annotCanvases: [{ type: i0.ViewChildren, args: ['annotCanvas',] }],
        fileInputRef: [{ type: i0.ViewChild, args: ['fileInput', { static: false },] }],
        stampFileInputRef: [{ type: i0.ViewChild, args: ['stampFileInput', { static: false },] }],
        viewerContainerRef: [{ type: i0.ViewChild, args: ['viewerContainer', { static: false },] }],
        signatureCanvasRef: [{ type: i0.ViewChild, args: ['signatureCanvas', { static: false },] }],
        userId: [{ type: i0.Input }],
        userName: [{ type: i0.Input }],
        documentId: [{ type: i0.Input }],
        detailId: [{ type: i0.Input }],
        edocId: [{ type: i0.Input }],
        isCancelMode: [{ type: i0.Input }],
        signatureFileInputRef: [{ type: i0.ViewChild, args: ['signatureFileInput', { static: false },] }],
        thumbFileInputRef: [{ type: i0.ViewChild, args: ['thumbFileInput', { static: false },] }],
        closed: [{ type: i0.Output }],
        saved: [{ type: i0.Output }],
        loadError: [{ type: i0.Output }],
        onDocumentPointerDown: [{ type: i0.HostListener, args: ['document:pointerdown', ['$event'],] }],
        handleKeyboard: [{ type: i0.HostListener, args: ['window:keydown', ['$event'],] }]
    };

    // AUTO-GENERATED from ionicons (do not hand-edit). Inner SVG markup per icon name.
    var ICON_PATHS = {
        'add': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 112v288M400 256H112"/>',
        'add-circle-outline': '<path d="M448 256c0-106-86-192-192-192S64 150 64 256s86 192 192 192 192-86 192-192z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 176v160M336 256H176"/>',
        'add-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 112v288M400 256H112"/>',
        'archive-outline': '<path d="M80 152v256a40.12 40.12 0 0040 40h272a40.12 40.12 0 0040-40V152" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><rect x="48" y="64" width="416" height="80" rx="28" ry="28" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M320 304l-64 64-64-64M256 345.89V224"/>',
        'arrow-back-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M244 400L100 256l144-144M120 256h292"/>',
        'arrow-down-circle-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M176 262.62L256 342l80-79.38M256 330.97V170"/><path d="M256 64C150 64 64 150 64 256s86 192 192 192 192-86 192-192S362 64 256 64z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/>',
        'arrow-down-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M112 268l144 144 144-144M256 392V100"/>',
        'arrow-forward-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M268 112l144 144-144 144M392 256H100"/>',
        'arrow-redo': '<path d="M58.79 439.13A16 16 0 0148 424c0-73.1 14.68-131.56 43.65-173.77 35-51 90.21-78.46 164.35-81.87V88a16 16 0 0127.05-11.57l176 168a16 16 0 010 23.14l-176 168A16 16 0 01256 424v-79.77c-45 1.36-79 8.65-106.07 22.64-29.25 15.12-50.46 37.71-73.32 67a16 16 0 01-17.82 5.28z"/>',
        'arrow-undo': '<path d="M448 440a16 16 0 01-12.61-6.15c-22.86-29.27-44.07-51.86-73.32-67C335 352.88 301 345.59 256 344.23V424a16 16 0 01-27 11.57l-176-168a16 16 0 010-23.14l176-168A16 16 0 01256 88v80.36c74.14 3.41 129.38 30.91 164.35 81.87C449.32 292.44 464 350.9 464 424a16 16 0 01-16 16z"/>',
        'arrow-undo-outline': '<path d="M240 424v-96c116.4 0 159.39 33.76 208 96 0-119.23-39.57-240-208-240V88L64 256z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/>',
        'arrow-up-circle-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M176 249.38L256 170l80 79.38M256 181.03V342"/><path d="M448 256c0-106-86-192-192-192S64 150 64 256s86 192 192 192 192-86 192-192z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/>',
        'arrow-up-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M112 244l144-144 144 144M256 120v292"/>',
        'ban-outline': '<circle cx="256" cy="256" r="208" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32" d="M108.92 108.92l294.16 294.16"/>',
        'book': '<path d="M202.24 74C166.11 56.75 115.61 48.3 48 48a31.36 31.36 0 00-17.92 5.33A32 32 0 0016 79.9V366c0 19.34 13.76 33.93 32 33.93 71.07 0 142.36 6.64 185.06 47a4.11 4.11 0 006.94-3V106.82a15.89 15.89 0 00-5.46-12A143 143 0 00202.24 74zM481.92 53.3A31.33 31.33 0 00464 48c-67.61.3-118.11 8.71-154.24 26a143.31 143.31 0 00-32.31 20.78 15.93 15.93 0 00-5.45 12v337.13a3.93 3.93 0 006.68 2.81c25.67-25.5 70.72-46.82 185.36-46.81a32 32 0 0032-32v-288a32 32 0 00-14.12-26.61z"/>',
        'book-outline': '<path d="M256 160c16-63.16 76.43-95.41 208-96a15.94 15.94 0 0116 16v288a16 16 0 01-16 16c-128 0-177.45 25.81-208 64-30.37-38-80-64-208-64-9.88 0-16-8.05-16-17.93V80a15.94 15.94 0 0116-16c131.57.59 192 32.84 208 96zM256 160v288" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'brush': '<path d="M233.15 360.11a15.7 15.7 0 01-4.92-.77 16 16 0 01-10.92-13c-2.15-15-19.95-32.46-36.62-35.85a16 16 0 01-8.69-26.33l211.09-235.1c.19-.22.39-.43.59-.63a56.57 56.57 0 0179.89 0 56.51 56.51 0 01.11 79.78l-219 227a16 16 0 01-11.53 4.9zM119.89 480.11c-32.14 0-65.45-16.89-84.85-43a16 16 0 0112.85-25.54c5.34 0 20-4.87 20-20.57 0-39.07 31.4-70.86 70-70.86s70 31.79 70 70.86c0 49.12-39.48 89.11-88 89.11z"/>',
        'bulb': '<path d="M288 464h-64a16 16 0 000 32h64a16 16 0 000-32zM304 416h-96a16 16 0 000 32h96a16 16 0 000-32zM369.42 62.69C339.35 32.58 299.07 16 256 16A159.62 159.62 0 0096 176c0 46.62 17.87 90.23 49 119.64l4.36 4.09C167.37 316.57 192 339.64 192 360v24a16 16 0 0016 16h24a8 8 0 008-8V274.82a8 8 0 00-5.13-7.47A130.73 130.73 0 01208.71 253a16 16 0 1118.58-26c7.4 5.24 21.65 13 28.71 13s21.31-7.78 28.73-13a16 16 0 0118.56 26 130.73 130.73 0 01-26.16 14.32 8 8 0 00-5.13 7.47V392a8 8 0 008 8h24a16 16 0 0016-16v-24c0-19.88 24.36-42.93 42.15-59.77l4.91-4.66C399.08 265 416 223.61 416 176a159.16 159.16 0 00-46.58-113.31z"/>',
        'business-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M176 416v64M80 32h192a32 32 0 0132 32v412a4 4 0 01-4 4H48h0V64a32 32 0 0132-32zM320 192h112a32 32 0 0132 32v256h0-160 0V208a16 16 0 0116-16z"/><path d="M98.08 431.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM98.08 351.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM98.08 271.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM98.08 191.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM98.08 111.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM178.08 351.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM178.08 271.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM178.08 191.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM178.08 111.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM258.08 431.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM258.08 351.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM258.08 271.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79z"/><ellipse cx="256" cy="176" rx="15.95" ry="16.03" transform="rotate(-45 255.99 175.996)"/><path d="M258.08 111.87a16 16 0 1113.79-13.79 16 16 0 01-13.79 13.79zM400 400a16 16 0 1016 16 16 16 0 00-16-16zM400 320a16 16 0 1016 16 16 16 0 00-16-16zM400 240a16 16 0 1016 16 16 16 0 00-16-16zM336 400a16 16 0 1016 16 16 16 0 00-16-16zM336 320a16 16 0 1016 16 16 16 0 00-16-16zM336 240a16 16 0 1016 16 16 16 0 00-16-16z"/>',
        'calendar': '<path d="M480 128a64 64 0 00-64-64h-16V48.45c0-8.61-6.62-16-15.23-16.43A16 16 0 00368 48v16H144V48.45c0-8.61-6.62-16-15.23-16.43A16 16 0 00112 48v16H96a64 64 0 00-64 64v12a4 4 0 004 4h440a4 4 0 004-4zM32 416a64 64 0 0064 64h320a64 64 0 0064-64V179a3 3 0 00-3-3H35a3 3 0 00-3 3zm344-208a24 24 0 11-24 24 24 24 0 0124-24zm0 80a24 24 0 11-24 24 24 24 0 0124-24zm-80-80a24 24 0 11-24 24 24 24 0 0124-24zm0 80a24 24 0 11-24 24 24 24 0 0124-24zm0 80a24 24 0 11-24 24 24 24 0 0124-24zm-80-80a24 24 0 11-24 24 24 24 0 0124-24zm0 80a24 24 0 11-24 24 24 24 0 0124-24zm-80-80a24 24 0 11-24 24 24 24 0 0124-24zm0 80a24 24 0 11-24 24 24 24 0 0124-24z"/>',
        'calendar-outline': '<rect fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" x="48" y="80" width="416" height="384" rx="48"/><circle cx="296" cy="232" r="24"/><circle cx="376" cy="232" r="24"/><circle cx="296" cy="312" r="24"/><circle cx="376" cy="312" r="24"/><circle cx="136" cy="312" r="24"/><circle cx="216" cy="312" r="24"/><circle cx="136" cy="392" r="24"/><circle cx="216" cy="392" r="24"/><circle cx="296" cy="392" r="24"/><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" stroke-linecap="round" d="M128 48v32M384 48v32"/><path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" d="M464 160H48"/>',
        'checkmark': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M416 128L192 384l-96-96"/>',
        'checkmark-done-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M464 128L240 384l-96-96M144 384l-96-96M368 128L232 284"/>',
        'checkmark-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M416 128L192 384l-96-96"/>',
        'chevron-back': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M328 112L184 256l144 144"/>',
        'chevron-down-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M112 184l144 144 144-144"/>',
        'chevron-forward': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M184 112l144 144-144 144"/>',
        'chevron-up-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M112 328l144-144 144 144"/>',
        'close': '<path d="M289.94 256l95-95A24 24 0 00351 127l-95 95-95-95a24 24 0 00-34 34l95 95-95 95a24 24 0 1034 34l95-95 95 95a24 24 0 0034-34z"/>',
        'close-circle-outline': '<path d="M448 256c0-106-86-192-192-192S64 150 64 256s86 192 192 192 192-86 192-192z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M320 320L192 192M192 320l128-128"/>',
        'close-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M368 368L144 144M368 144L144 368"/>',
        'cloud-upload': '<path d="M473.66 210c-14-10.38-31.2-18-49.36-22.11a16.11 16.11 0 01-12.19-12.22c-7.8-34.75-24.59-64.55-49.27-87.13C334.15 62.25 296.21 47.79 256 47.79c-35.35 0-68 11.08-94.37 32.05a150.07 150.07 0 00-42.06 53 16 16 0 01-11.31 8.87c-26.75 5.4-50.9 16.87-69.34 33.12C13.46 197.33 0 227.24 0 261.39c0 34.52 14.49 66 40.79 88.76 25.12 21.69 58.94 33.64 95.21 33.64h104V230.42l-36.69 36.69a16 16 0 01-23.16-.56c-5.8-6.37-5.24-16.3.85-22.39l63.69-63.68a16 16 0 0122.62 0L331 244.14c6.28 6.29 6.64 16.6.39 22.91a16 16 0 01-22.68.06L272 230.42v153.37h124c31.34 0 59.91-8.8 80.45-24.77 23.26-18.1 35.55-44 35.55-74.83 0-29.94-13.26-55.61-38.34-74.19zM240 448.21a16 16 0 1032 0v-64.42h-32z"/>',
        'cloud-upload-outline': '<path d="M320 367.79h76c55 0 100-29.21 100-83.6s-53-81.47-96-83.6c-8.89-85.06-71-136.8-144-136.8-69 0-113.44 45.79-128 91.2-60 5.7-112 43.88-112 106.4s54 106.4 120 106.4h56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M320 255.79l-64-64-64 64M256 448.21V207.79"/>',
        'color-fill': '<path d="M416 480c-35.29 0-64-29.11-64-64.88 0-33.29 28.67-65.4 44.08-82.64 1.87-2.1 3.49-3.91 4.68-5.31a19.94 19.94 0 0130.55 0c1.13 1.31 2.63 3 4.36 4.93 15.5 17.3 44.33 49.51 44.33 83.05 0 35.74-28.71 64.85-64 64.85zM398.23 276.64L166.89 47.22a52.1 52.1 0 00-73.6 0l-4.51 4.51a53.2 53.2 0 00-15.89 37.33A51.66 51.66 0 0088.14 126l41.51 41.5L45 252a44.52 44.52 0 00-13 32 42.81 42.81 0 0013.5 30.84l131.24 126a44 44 0 0061.08-.18l124.11-120.28a15.6 15.6 0 018.23-4.29 69.21 69.21 0 0111.93-.86h.3a22.53 22.53 0 0015.84-38.59zM152.29 144.85l-41.53-41.52a20 20 0 010-28.34l5.16-5.15a20.07 20.07 0 0128.39 0L186 111.21z"/>',
        'color-fill-outline': '<path d="M419.1 337.45a3.94 3.94 0 00-6.1 0c-10.5 12.4-45 46.55-45 77.66 0 27 21.5 48.89 48 48.89h0c26.5 0 48-22 48-48.89 0-31.11-34.3-65.26-44.9-77.66zM387 287.9L155.61 58.36a36 36 0 00-51 0l-5.15 5.15a36 36 0 000 51l52.89 52.89 57-57L56.33 263.2a28 28 0 00.3 40l131.2 126a28.05 28.05 0 0038.9-.1c37.8-36.6 118.3-114.5 126.7-122.9 5.8-5.8 18.2-7.1 28.7-7.1h.3a6.53 6.53 0 004.57-11.2z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/>',
        'color-filter-outline': '<circle cx="256" cy="184" r="120" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><circle cx="344" cy="328" r="120" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><circle cx="168" cy="328" r="120" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/>',
        'color-palette': '<path d="M441 336.2l-.06-.05c-9.93-9.18-22.78-11.34-32.16-12.92l-.69-.12c-9.05-1.49-10.48-2.5-14.58-6.17-2.44-2.17-5.35-5.65-5.35-9.94s2.91-7.77 5.34-9.94l30.28-26.87c25.92-22.91 40.2-53.66 40.2-86.59s-14.25-63.68-40.2-86.6c-35.89-31.59-85-49-138.37-49C223.72 48 162 71.37 116 112.11c-43.87 38.77-68 90.71-68 146.24s24.16 107.47 68 146.23c21.75 19.24 47.49 34.18 76.52 44.42a266.17 266.17 0 0086.87 15h1.81c61 0 119.09-20.57 159.39-56.4 9.7-8.56 15.15-20.83 15.34-34.56.21-14.17-5.37-27.95-14.93-36.84zM112 208a32 32 0 1132 32 32 32 0 01-32-32zm40 135a32 32 0 1132-32 32 32 0 01-32 32zm40-199a32 32 0 1132 32 32 32 0 01-32-32zm64 271a48 48 0 1148-48 48 48 0 01-48 48zm72-239a32 32 0 1132-32 32 32 0 01-32 32z"/>',
        'contract-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M304 416V304h112M314.2 314.23L432 432M208 96v112H96M197.8 197.77L80 80M416 208H304V96M314.23 197.8L432 80M96 304h112v112M197.77 314.2L80 432"/>',
        'create': '<path d="M459.94 53.25a16.06 16.06 0 00-23.22-.56L424.35 65a8 8 0 000 11.31l11.34 11.32a8 8 0 0011.34 0l12.06-12c6.1-6.09 6.67-16.01.85-22.38zM399.34 90L218.82 270.2a9 9 0 00-2.31 3.93L208.16 299a3.91 3.91 0 004.86 4.86l24.85-8.35a9 9 0 003.93-2.31L422 112.66a9 9 0 000-12.66l-9.95-10a9 9 0 00-12.71 0z"/><path d="M386.34 193.66L264.45 315.79A41.08 41.08 0 01247.58 326l-25.9 8.67a35.92 35.92 0 01-44.33-44.33l8.67-25.9a41.08 41.08 0 0110.19-16.87l122.13-121.91a8 8 0 00-5.65-13.66H104a56 56 0 00-56 56v240a56 56 0 0056 56h240a56 56 0 0056-56V199.31a8 8 0 00-13.66-5.65z"/>',
        'create-outline': '<path d="M384 224v184a40 40 0 01-40 40H104a40 40 0 01-40-40V168a40 40 0 0140-40h167.48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M459.94 53.25a16.06 16.06 0 00-23.22-.56L424.35 65a8 8 0 000 11.31l11.34 11.32a8 8 0 0011.34 0l12.06-12c6.1-6.09 6.67-16.01.85-22.38zM399.34 90L218.82 270.2a9 9 0 00-2.31 3.93L208.16 299a3.91 3.91 0 004.86 4.86l24.85-8.35a9 9 0 003.93-2.31L422 112.66a9 9 0 000-12.66l-9.95-10a9 9 0 00-12.71 0z"/>',
        'cut-outline': '<circle cx="104" cy="152" r="56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><circle cx="104" cy="360" r="56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M157 175l-11 15 37 15s3.46-6.42 7-10z" fill="none" stroke="currentColor" stroke-linecap="square" stroke-miterlimit="10" stroke-width="32"/><path d="M154.17 334.43L460 162c-2.5-6.7-28-12-64-4-29.12 6.47-121.16 29.05-159.16 56.05C205.85 236.06 227 272 192 298c-25.61 19-44.43 22.82-44.43 22.82zM344.47 278.24L295 306.67c14.23 6.74 65.54 33.27 117 36.33 14.92.89 30 .39 39-6z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32"/><circle cx="256" cy="240" r="32" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/>',
        'document-outline': '<path d="M416 221.25V416a48 48 0 01-48 48H144a48 48 0 01-48-48V96a48 48 0 0148-48h98.75a32 32 0 0122.62 9.37l141.26 141.26a32 32 0 019.37 22.62z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path d="M256 56v120a32 32 0 0032 32h120" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'document-text-outline': '<path d="M416 221.25V416a48 48 0 01-48 48H144a48 48 0 01-48-48V96a48 48 0 0148-48h98.75a32 32 0 0122.62 9.37l141.26 141.26a32 32 0 019.37 22.62z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path d="M256 56v120a32 32 0 0032 32h120M176 288h160M176 368h160" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'documents': '<path d="M298.39 248a4 4 0 002.86-6.8l-78.4-79.72a4 4 0 00-6.85 2.81V236a12 12 0 0012 12z"/><path d="M197 267a43.67 43.67 0 01-13-31v-92h-72a64.19 64.19 0 00-64 64v224a64 64 0 0064 64h144a64 64 0 0064-64V280h-92a43.61 43.61 0 01-31-13zM372 120h70.39a4 4 0 002.86-6.8l-78.4-79.72a4 4 0 00-6.85 2.81V108a12 12 0 0012 12z"/><path d="M372 152a44.34 44.34 0 01-44-44V16H220a60.07 60.07 0 00-60 60v36h42.12A40.81 40.81 0 01231 124.14l109.16 111a41.11 41.11 0 0111.83 29V400h53.05c32.51 0 58.95-26.92 58.95-60V152z"/>',
        'documents-outline': '<path d="M336 264.13V436c0 24.3-19.05 44-42.95 44H107c-23.95 0-43-19.7-43-44V172a44.26 44.26 0 0144-44h94.12a24.55 24.55 0 0117.49 7.36l109.15 111a25.4 25.4 0 017.24 17.77z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path d="M200 128v108a28.34 28.34 0 0028 28h108" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M176 128V76a44.26 44.26 0 0144-44h94a24.83 24.83 0 0117.61 7.36l109.15 111A25.09 25.09 0 01448 168v172c0 24.3-19.05 44-42.95 44H344" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><path d="M312 32v108a28.34 28.34 0 0028 28h108" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'ellipse-outline': '<circle cx="256" cy="256" r="192" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'finger-print': '<path d="M63.28 202a15.29 15.29 0 01-7.7-2 14.84 14.84 0 01-5.52-20.46C69.34 147.36 128 72.25 256 72.25c55.47 0 104.12 14.57 144.53 43.29 33.26 23.57 51.9 50.25 60.78 63.1a14.79 14.79 0 01-4 20.79 15.52 15.52 0 01-21.24-4C420 172.32 371 102 256 102c-112.25 0-163 64.71-179.53 92.46A15 15 0 0163.28 202z"/><path d="M320.49 496a15.31 15.31 0 01-3.79-.43c-92.85-23-127.52-115.82-128.93-119.68l-.22-.85c-.76-2.68-19.39-66.33 9.21-103.61 13.11-17 33.05-25.72 59.38-25.72 24.48 0 42.14 7.61 54.28 23.36 10 12.86 14 28.72 17.87 44 8.13 31.82 14 48.53 47.79 50.25 14.84.75 24.59-7.93 30.12-15.32 14.95-20.15 17.55-53 6.28-82C398 228.57 346.61 158 256 158c-38.68 0-74.22 12.43-102.72 35.79-23.59 19.35-42.28 46.67-51.28 74.75-16.69 52.28 5.2 134.46 5.41 135.21A14.83 14.83 0 0196.54 422a15.39 15.39 0 01-18.74-10.6c-1-3.75-24.38-91.4-5.1-151.82 21-65.47 85.81-131.47 183.33-131.47 45.07 0 87.65 15.32 123.19 44.25 27.52 22.5 50 52.72 61.76 82.93 14.95 38.57 10.94 81.86-10.19 110.14-14.08 18.86-34.13 28.72-56.34 27.65-57.86-2.9-68.26-43.29-75.84-72.75-7.8-30.22-12.79-44.79-42.58-44.79-16.36 0-27.85 4.5-35 13.82-9.75 12.75-10.51 32.68-9.43 47.14a152.44 152.44 0 005.1 29.79c2.38 6 33.37 82 107.59 100.39a14.88 14.88 0 0111 18.11 15.36 15.36 0 01-14.8 11.21z"/><path d="M201.31 489.14a15.5 15.5 0 01-11.16-4.71c-37.16-39-58.18-82.61-66.09-137.14V347c-4.44-36.1 2.06-87.21 33.91-122.35 23.51-25.93 56.56-39.11 98.06-39.11 49.08 0 87.65 22.82 111.7 65.89 17.45 31.29 20.91 62.47 21 63.75a15.07 15.07 0 01-13.65 16.4 15.26 15.26 0 01-16.79-13.29A154 154 0 00340.43 265c-18.64-32.89-47-49.61-84.51-49.61-32.4 0-57.75 9.75-75.19 29-25.14 27.75-30 70.5-26.55 98.78 6.93 48.22 25.46 86.58 58.18 120.86a14.7 14.7 0 01-.76 21.11 15.44 15.44 0 01-10.29 4z"/><path d="M372.5 446.18c-32.5 0-60.13-9-82.24-26.89-44.42-35.79-49.4-94.08-49.62-96.54a15.27 15.27 0 0130.45-2.36c.11.86 4.55 48.54 38.79 76 20.26 16.18 47.34 22.6 80.71 18.85a15.2 15.2 0 0116.91 13.18 14.92 14.92 0 01-13.44 16.5 187 187 0 01-21.56 1.26zM398.18 48.79C385.5 40.54 340.54 16 256 16c-88.74 0-133.81 27.11-143.78 34a11.59 11.59 0 00-1.84 1.4.36.36 0 01-.22.1 14.87 14.87 0 00-5.09 11.15 15.06 15.06 0 0015.31 14.85 15.56 15.56 0 008.88-2.79c.43-.32 39.22-28.82 126.77-28.82S382.58 74.29 383 74.5a15.25 15.25 0 009.21 3 15.06 15.06 0 0015.29-14.89 14.9 14.9 0 00-9.32-13.82z"/>',
        'image': '<path d="M416 64H96a64.07 64.07 0 00-64 64v256a64.07 64.07 0 0064 64h320a64.07 64.07 0 0064-64V128a64.07 64.07 0 00-64-64zm-80 64a48 48 0 11-48 48 48.05 48.05 0 0148-48zM96 416a32 32 0 01-32-32v-67.63l94.84-84.3a48.06 48.06 0 0165.8 1.9l64.95 64.81L172.37 416zm352-32a32 32 0 01-32 32H217.63l121.42-121.42a47.72 47.72 0 0161.64-.16L448 333.84z"/>',
        'image-outline': '<rect x="48" y="80" width="416" height="352" rx="48" ry="48" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><circle cx="336" cy="176" r="32" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path d="M304 335.79l-90.66-90.49a32 32 0 00-43.87-1.3L48 352M224 432l123.34-123.34a32 32 0 0143.11-2L464 368" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'images-outline': '<path d="M432 112V96a48.14 48.14 0 00-48-48H64a48.14 48.14 0 00-48 48v256a48.14 48.14 0 0048 48h16" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><rect x="96" y="128" width="400" height="336" rx="45.99" ry="45.99" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/><ellipse cx="372.92" cy="219.64" rx="30.77" ry="30.55" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path d="M342.15 372.17L255 285.78a30.93 30.93 0 00-42.18-1.21L96 387.64M265.23 464l118.59-117.73a31 31 0 0141.46-1.87L496 402.91" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'information-circle-outline': '<path d="M248 64C146.39 64 64 146.39 64 248s82.39 184 184 184 184-82.39 184-184S349.61 64 248 64z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M220 220h32v116"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32" d="M208 340h88"/><path d="M248 130a26 26 0 1026 26 26 26 0 00-26-26z"/>',
        'keypad': '<path d="M256 400a48 48 0 1048 48 48 48 0 00-48-48zM256 272a48 48 0 1048 48 48 48 0 00-48-48zM256 144a48 48 0 1048 48 48 48 0 00-48-48zM256 16a48 48 0 1048 48 48 48 0 00-48-48zM384 272a48 48 0 1048 48 48 48 0 00-48-48zM384 144a48 48 0 1048 48 48 48 0 00-48-48zM384 16a48 48 0 1048 48 48 48 0 00-48-48zM128 272a48 48 0 1048 48 48 48 0 00-48-48zM128 144a48 48 0 1048 48 48 48 0 00-48-48zM128 16a48 48 0 1048 48 48 48 0 00-48-48z"/>',
        'layers-outline': '<path d="M434.8 137.65l-149.36-68.1c-16.19-7.4-42.69-7.4-58.88 0L77.3 137.65c-17.6 8-17.6 21.09 0 29.09l148 67.5c16.89 7.7 44.69 7.7 61.58 0l148-67.5c17.52-8 17.52-21.1-.08-29.09zM160 308.52l-82.7 37.11c-17.6 8-17.6 21.1 0 29.1l148 67.5c16.89 7.69 44.69 7.69 61.58 0l148-67.5c17.6-8 17.6-21.1 0-29.1l-79.94-38.47" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M160 204.48l-82.8 37.16c-17.6 8-17.6 21.1 0 29.1l148 67.49c16.89 7.7 44.69 7.7 61.58 0l148-67.49c17.7-8 17.7-21.1.1-29.1L352 204.48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'list-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M160 144h288M160 256h288M160 368h288"/><circle cx="80" cy="144" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><circle cx="80" cy="256" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><circle cx="80" cy="368" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'megaphone': '<path d="M48 176v.66a17.38 17.38 0 01-4.2 11.23v.05C38.4 194.32 32 205.74 32 224c0 16.55 5.3 28.23 11.68 35.91A19 19 0 0148 272a32 32 0 0032 32h8a8 8 0 008-8V152a8 8 0 00-8-8h-8a32 32 0 00-32 32zM452.18 186.55l-.93-.17a4 4 0 01-3.25-3.93V62c0-12.64-8.39-24-20.89-28.32-11.92-4.11-24.34-.76-31.68 8.53a431.18 431.18 0 01-51.31 51.69c-23.63 20-46.24 34.25-67 42.31a8 8 0 00-5.15 7.47V299a16 16 0 009.69 14.69c19.34 8.29 40.24 21.83 62 40.28a433.74 433.74 0 0151.68 52.16 26.22 26.22 0 0021.1 9.87 33.07 33.07 0 0010.44-1.74C439.71 410 448 399.05 448 386.4V265.53a4 4 0 013.33-3.94l.85-.14C461.8 258.84 480 247.67 480 224s-18.2-34.84-27.82-37.45zM240 320V152a8 8 0 00-8-8h-96a8 8 0 00-8 8v304a24 24 0 0024 24h52.45a32.66 32.66 0 0025.93-12.45 31.65 31.65 0 005.21-29.05c-1.62-5.18-3.63-11-5.77-17.19-7.91-22.9-18.34-37.07-21.12-69.32A32 32 0 00240 320z"/>',
        'move-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M176 112l80-80 80 80M255.98 32l.02 448M176 400l80 80 80-80M400 176l80 80-80 80M112 176l-80 80 80 80M32 256h448"/>',
        'open-outline': '<path d="M384 224v184a40 40 0 01-40 40H104a40 40 0 01-40-40V168a40 40 0 0140-40h167.48M336 64h112v112M224 288L440 72" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'options-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M368 128h80M64 128h240M368 384h80M64 384h240M208 256h240M64 256h80"/><circle cx="336" cy="128" r="32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><circle cx="176" cy="256" r="32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><circle cx="336" cy="384" r="32" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'pencil-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M364.13 125.25L87 403l-23 45 44.99-23 277.76-277.13-22.62-22.62zM420.69 68.69l-22.62 22.62 22.62 22.63 22.62-22.63a16 16 0 000-22.62h0a16 16 0 00-22.62 0z"/>',
        'phone-landscape-outline': '<rect x="128" y="16" width="256" height="480" rx="48" ry="48" transform="rotate(-90 256 256)" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M16 336v-24a8 8 0 018-8h0a16 16 0 0016-16v-64a16 16 0 00-16-16h0a8 8 0 01-8-8v-24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'phone-portrait-outline': '<rect x="128" y="16" width="256" height="480" rx="48" ry="48" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path d="M176 16h24a8 8 0 018 8h0a16 16 0 0016 16h64a16 16 0 0016-16h0a8 8 0 018-8h24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'play-skip-back': '<path d="M112 64a16 16 0 0116 16v136.43L360.77 77.11a35.13 35.13 0 0135.77-.44c12 6.8 19.46 20 19.46 34.33v290c0 14.37-7.46 27.53-19.46 34.33a35.14 35.14 0 01-35.77-.45L128 295.57V432a16 16 0 01-32 0V80a16 16 0 0116-16z"/>',
        'play-skip-forward': '<path d="M400 64a16 16 0 00-16 16v136.43L151.23 77.11a35.13 35.13 0 00-35.77-.44C103.46 83.47 96 96.63 96 111v290c0 14.37 7.46 27.53 19.46 34.33a35.14 35.14 0 0035.77-.45L384 295.57V432a16 16 0 0032 0V80a16 16 0 00-16-16z"/>',
        'refresh': '<path d="M320 146s24.36-12-64-12a160 160 0 10160 160" fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 58l80 80-80 80"/>',
        'refresh-outline': '<path d="M320 146s24.36-12-64-12a160 160 0 10160 160" fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 58l80 80-80 80"/>',
        'remove': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M400 256H112"/>',
        'remove-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M400 256H112"/>',
        'resize': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M304 96h112v112M405.77 106.2L111.98 400.02M208 416H96V304"/>',
        'resize-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M304 96h112v112M405.77 106.2L111.98 400.02M208 416H96V304"/>',
        'return-up-back-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M112 160l-64 64 64 64"/><path d="M64 224h294c58.76 0 106 49.33 106 108v20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'return-up-forward-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M400 160l64 64-64 64"/><path d="M448 224H154c-58.76 0-106 49.33-106 108v20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'rocket': '<path d="M328.85 156.79a26.69 26.69 0 1018.88 7.81 26.6 26.6 0 00-18.88-7.81z"/><path d="M477.44 50.06a.29.29 0 010-.09 20.4 20.4 0 00-15.13-15.3c-29.8-7.27-76.68.48-128.63 21.28-52.36 21-101.42 52-134.58 85.22A320.7 320.7 0 00169.55 175c-22.33-1-42 2.18-58.57 9.41-57.74 25.41-74.23 90.44-78.62 117.14a25 25 0 0027.19 29h.13l64.32-7.02c.08.82.17 1.57.24 2.26a34.36 34.36 0 009.9 20.72l31.39 31.41a34.27 34.27 0 0020.71 9.91l2.15.23-7 64.24v.13A25 25 0 00206 480a25.25 25.25 0 004.15-.34C237 475.34 302 459.05 327.34 401c7.17-16.46 10.34-36.05 9.45-58.34a314.78 314.78 0 0033.95-29.55c33.43-33.26 64.53-81.92 85.31-133.52 20.69-51.36 28.48-98.59 21.39-129.53zM370.38 224.94a58.77 58.77 0 110-83.07 58.3 58.3 0 010 83.07z"/><path d="M161.93 386.44a16 16 0 00-11 2.67c-6.39 4.37-12.81 8.69-19.29 12.9-13.11 8.52-28.79-6.44-21-20l12.15-21a16 16 0 00-15.16-24.91A61.25 61.25 0 0072 353.56c-3.66 3.67-14.79 14.81-20.78 57.26A357.94 357.94 0 0048 447.59 16 16 0 0064 464h.4a359.87 359.87 0 0036.8-3.2c42.47-6 53.61-17.14 57.27-20.8a60.49 60.49 0 0017.39-35.74 16 16 0 00-13.93-17.82z"/>',
        'save-outline': '<path d="M380.93 57.37A32 32 0 00358.3 48H94.22A46.21 46.21 0 0048 94.22v323.56A46.21 46.21 0 0094.22 464h323.56A46.36 46.36 0 00464 417.78V153.7a32 32 0 00-9.37-22.63zM256 416a64 64 0 1164-64 63.92 63.92 0 01-64 64zm48-224H112a16 16 0 01-16-16v-64a16 16 0 0116-16h192a16 16 0 0116 16v64a16 16 0 01-16 16z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'search-outline': '<path d="M221.09 64a157.09 157.09 0 10157.09 157.09A157.1 157.1 0 00221.09 64z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32" d="M338.29 338.29L448 448"/>',
        'shapes': '<path d="M336 336H32a16 16 0 01-14-23.81l152-272a16 16 0 0127.94 0l152 272A16 16 0 01336 336z"/><path d="M336 160a161.07 161.07 0 00-32.57 3.32l74.47 133.27A48 48 0 01336 368H183.33A160 160 0 10336 160z"/>',
        'shapes-outline': '<path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32" d="M336 320H32L184 48l152 272zM265.32 194.51A144 144 0 11192 320"/>',
        'shield-checkmark': '<path d="M479.07 111.36a16 16 0 00-13.15-14.74c-86.5-15.52-122.61-26.74-203.33-63.2a16 16 0 00-13.18 0C168.69 69.88 132.58 81.1 46.08 96.62a16 16 0 00-13.15 14.74c-3.85 61.11 4.36 118.05 24.43 169.24A349.47 349.47 0 00129 393.11c53.47 56.73 110.24 81.37 121.07 85.73a16 16 0 0012 0c10.83-4.36 67.6-29 121.07-85.73a349.47 349.47 0 0071.5-112.51c20.07-51.19 28.28-108.13 24.43-169.24zm-131 75.11l-110.8 128a16 16 0 01-11.41 5.53h-.66a16 16 0 01-11.2-4.57l-49.2-48.2a16 16 0 1122.4-22.86l37 36.29 99.7-115.13a16 16 0 0124.2 20.94z"/>',
        'shield-checkmark-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M336 176L225.2 304 176 255.8"/><path d="M463.1 112.37C373.68 96.33 336.71 84.45 256 48c-80.71 36.45-117.68 48.33-207.1 64.37C32.7 369.13 240.58 457.79 256 464c15.42-6.21 223.3-94.87 207.1-351.63z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'square': '<path d="M416 464H96a48.05 48.05 0 01-48-48V96a48.05 48.05 0 0148-48h320a48.05 48.05 0 0148 48v320a48.05 48.05 0 01-48 48z"/>',
        'square-outline': '<path d="M416 448H96a32.09 32.09 0 01-32-32V96a32.09 32.09 0 0132-32h320a32.09 32.09 0 0132 32v320a32.09 32.09 0 01-32 32z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'star': '<path d="M394 480a16 16 0 01-9.39-3L256 383.76 127.39 477a16 16 0 01-24.55-18.08L153 310.35 23 221.2a16 16 0 019-29.2h160.38l48.4-148.95a16 16 0 0130.44 0l48.4 149H480a16 16 0 019.05 29.2L359 310.35l50.13 148.53A16 16 0 01394 480z"/>',
        'swap-horizontal-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M304 48l112 112-112 112M398.87 160H96M208 464L96 352l112-112M114 352h302"/>',
        'sync-outline': '<path d="M434.67 285.59v-29.8c0-98.73-80.24-178.79-179.2-178.79a179 179 0 00-140.14 67.36m-38.53 82v29.8C76.8 355 157 435 256 435a180.45 180.45 0 00140-66.92" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M32 256l44-44 46 44M480 256l-44 44-46-44"/>',
        'text': '<path d="M292.6 407.78l-120-320a22 22 0 00-41.2 0l-120 320a22 22 0 0041.2 15.44l36.16-96.42a2 2 0 011.87-1.3h122.74a2 2 0 011.87 1.3l36.16 96.42a22 22 0 0041.2-15.44zm-185.84-129l43.37-115.65a2 2 0 013.74 0l43.37 115.67a2 2 0 01-1.87 2.7h-86.74a2 2 0 01-1.87-2.7zM400.77 169.5c-41.72-.3-79.08 23.87-95 61.4a22 22 0 0040.5 17.2c8.88-20.89 29.77-34.44 53.32-34.6 32.32-.22 58.41 26.5 58.41 58.85a1.5 1.5 0 01-1.45 1.5c-21.92.61-47.92 2.07-71.12 4.8-54.75 6.44-87.43 36.29-87.43 79.85 0 23.19 8.76 44 24.67 58.68C337.6 430.93 358 438.5 380 438.5c31 0 57.69-8 77.94-23.22h.06a22 22 0 1044 .19v-143c0-56.18-45-102.56-101.23-102.97zM380 394.5c-17.53 0-38-9.43-38-36 0-10.67 3.83-18.14 12.43-24.23 8.37-5.93 21.2-10.16 36.14-11.92 21.12-2.49 44.82-3.86 65.14-4.47a2 2 0 012 2.1C455 370.1 429.46 394.5 380 394.5z"/>',
        'text-outline': '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M32 415.5l120-320 120 320M230 303.5H74M326 239.5c12.19-28.69 41-48 74-48h0c46 0 80 32 80 80v144"/><path d="M320 358.5c0 36 26.86 58 60 58 54 0 100-27 100-106v-15c-20 0-58 1-92 5-32.77 3.86-68 19-68 58z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'time-outline': '<path d="M256 64C150 64 64 150 64 256s86 192 192 192 192-86 192-192S362 64 256 64z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 128v144h96"/>',
        'trash': '<path d="M296 64h-80a7.91 7.91 0 00-8 8v24h96V72a7.91 7.91 0 00-8-8z" fill="none"/><path d="M432 96h-96V72a40 40 0 00-40-40h-80a40 40 0 00-40 40v24H80a16 16 0 000 32h17l19 304.92c1.42 26.85 22 47.08 48 47.08h184c26.13 0 46.3-19.78 48-47l19-305h17a16 16 0 000-32zM192.57 416H192a16 16 0 01-16-15.43l-8-224a16 16 0 1132-1.14l8 224A16 16 0 01192.57 416zM272 400a16 16 0 01-32 0V176a16 16 0 0132 0zm32-304h-96V72a7.91 7.91 0 018-8h80a7.91 7.91 0 018 8zm32 304.57A16 16 0 01320 416h-.58A16 16 0 01304 399.43l8-224a16 16 0 1132 1.14z"/>',
        'trash-outline': '<path d="M112 112l20 320c.95 18.49 14.4 32 32 32h184c17.67 0 30.87-13.51 32-32l20-320" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="32" d="M80 112h352"/><path d="M192 112V72h0a23.93 23.93 0 0124-24h80a23.93 23.93 0 0124 24h0v40M256 176v224M184 176l8 224M328 176l-8 224" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
        'water-outline': '<path d="M400 320c0 88.37-55.63 144-144 144s-144-55.63-144-144c0-94.83 103.23-222.85 134.89-259.88a12 12 0 0118.23 0C296.77 97.15 400 225.17 400 320z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"/><path d="M344 328a72 72 0 01-72 72" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"/>',
    };

    /**
     * Self-contained inline-SVG icon (replaces <ion-icon>).
     * Renders ionicons artwork as pure inline SVG so the library does not depend on
     * the ion-icon web component / ionicons being registered by the host app.
     * Sizes to 1em and inherits `currentColor` just like <ion-icon>.
     */
    var SvgIconComponent = /** @class */ (function () {
        function SvgIconComponent(sanitizer) {
            this.sanitizer = sanitizer;
            this.html = '';
        }
        Object.defineProperty(SvgIconComponent.prototype, "name", {
            set: function (value) {
                var inner = (value && ICON_PATHS[value]) || '';
                // Inline sizing on the <svg> itself so it never falls back to the 300x150
                // default, regardless of view-encapsulation / ::ng-deep support.
                this.html = this.sanitizer.bypassSecurityTrustHtml("<svg viewBox=\"0 0 512 512\" fill=\"currentColor\" xmlns=\"http://www.w3.org/2000/svg\" " +
                    ("style=\"width:1em;height:1em;display:block\">" + inner + "</svg>"));
            },
            enumerable: false,
            configurable: true
        });
        return SvgIconComponent;
    }());
    SvgIconComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'svg-icon',
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    template: "<span class=\"svg-icon__inner\" [innerHTML]=\"html\"></span>",
                    styles: ["\n    :host {\n      display: inline-flex;\n      align-items: center;\n      justify-content: center;\n      width: 1em;\n      height: 1em;\n      line-height: 1;\n      vertical-align: -0.125em;\n    }\n    .svg-icon__inner { display: inline-flex; width: 1em; height: 1em; }\n    :host ::ng-deep svg { width: 1em; height: 1em; display: block; }\n  "]
                },] }
    ];
    SvgIconComponent.ctorParameters = function () { return [
        { type: platformBrowser.DomSanitizer }
    ]; };
    SvgIconComponent.propDecorators = {
        name: [{ type: i0.Input }]
    };

    // HttpClient must be provided by the host application:
    //   Angular 15+:  provideHttpClient()  in app.config.ts
    //   Angular 12-14: HttpClientModule    in AppModule imports
    var PdfAnnotatorModule = /** @class */ (function () {
        function PdfAnnotatorModule() {
        }
        PdfAnnotatorModule.forRoot = function (config) {
            return {
                ngModule: PdfAnnotatorModule,
                providers: [
                    { provide: PDF_ANNOTATOR_CONFIG, useValue: config },
                    PdfManagerService
                ]
            };
        };
        return PdfAnnotatorModule;
    }());
    PdfAnnotatorModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [PdfAnnotatorModalComponent, SvgIconComponent],
                    imports: [common.CommonModule, forms.FormsModule, angular.IonicModule],
                    exports: [PdfAnnotatorModalComponent],
                    providers: [common.DatePipe, PdfManagerService],
                    schemas: [i0.CUSTOM_ELEMENTS_SCHEMA]
                },] }
    ];

    /*
     * Public API Surface of pdf-annotator
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.PDF_ANNOTATOR_CONFIG = PDF_ANNOTATOR_CONFIG;
    exports.PdfAnnotatorModalComponent = PdfAnnotatorModalComponent;
    exports.PdfAnnotatorModule = PdfAnnotatorModule;
    exports.PdfManagerService = PdfManagerService;
    exports["ɵa"] = SvgIconComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=pdf-annotator.umd.js.map
